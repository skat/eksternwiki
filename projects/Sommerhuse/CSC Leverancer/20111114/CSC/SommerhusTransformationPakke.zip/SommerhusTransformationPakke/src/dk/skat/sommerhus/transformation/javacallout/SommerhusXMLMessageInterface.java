package dk.skat.sommerhus.transformation.javacallout;

import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * This interface serves one purpose, to make it possible to
 * typecast different message processors into one and the
 * same type.
 */
interface SommerhusXMLMessageInterface
{
	/**
	 * Process input stream
	 *
	 * <p>To avoid performanceloss due to creating message objects
	 * this method must reset all fields before processing the message
	 * </p>
	 *
	 * @param fis The stream to process
	 * @param fos The stream to write to
	 */
  public void readFromFile(FileInputStream fis, FileOutputStream fos) throws Exception;

	/**
	 * Process output stream
	 *
	 * @param fos The stream to process
	 */
	public void writeToFile(FileOutputStream fos) throws Exception;
}