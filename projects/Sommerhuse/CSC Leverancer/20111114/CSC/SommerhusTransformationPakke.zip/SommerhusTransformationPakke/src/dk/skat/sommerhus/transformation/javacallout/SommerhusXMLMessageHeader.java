package dk.skat.sommerhus.transformation.javacallout;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Vector;
import java.nio.channels.FileChannel;

/**
 * Not used - here for completeness
 *
 * @author Ren� Hjortskov Nielsen, SKAT
 * @version 0.1
 */
public class SommerhusXMLMessageHeader extends SommerhusXMLMessageBase implements SommerhusXMLMessageInterface
{

  /**
   * Constructor
   *
   * @param debug True if logging to system out should be supported
   */
	public SommerhusXMLMessageHeader(boolean debug) {
		this.debug = debug;
	}

	/**
	 * Produce
	 */
  public void readFromFile(FileInputStream fis, FileOutputStream fos)
		throws Exception
	{
		if (debug) System.out.println("+SommerhusXMLMessageHeader");
		// Reset message
		if (message!=null) { message.clear(); } else {
			message = new Vector();
			// Make room for message declaration
			// Needed when body assigns values to header, the index might be different from 0
			//byte[] b = new byte[0];
			//message.addElement(b);
		}

		if (debug) System.out.println("-SommerhusXMLMessageHeader");
  }

}
