package dk.skat.sommerhus.transformation.javacallout;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Vector;

/**
 * <p>Implements Sommerhusudlejning envelope footer structure. Input is read from a filestream and written to a filestream</p>
 *
 * @author Ren� Hjortskov Nielsen, SKAT
 * @version 0.1
 */
public class SommerhusXMLEnvelopeFooter extends SommerhusXMLMessageBase implements SommerhusXMLMessageInterface
{
	private Vector message = new Vector();

	public SommerhusXMLEnvelopeFooter(boolean debug) {
		this.debug = debug;
	}

	/**
	 * <P>Produce </base64></fase2.1:MeddelelsesIndhold></fase2.1:IndholdValg></fase2.1:UdlejningFritidEjendomAngivelseFilOpret_I></p>
	 *
	 */
  public void readFromFile(FileInputStream fis, FileOutputStream fos)
		throws Exception
	{
		if (debug) System.out.println("+SommerhusXMLEnvelopeFooter");
		// Reset message
		if (message!=null) { message.clear(); } else { message = new Vector(); }

    message.addElement(getBytesFromString("</base64></fase2.1:MeddelelseIndhold></fase2.1:IndholdValg></fase2.1:UdlejningFritidEjendomAngivelseFilOpret_I>"));

		if (debug) System.out.println("-SommerhusXMLEnvelopeFooter");
  }

  public void writeToFile(FileOutputStream fos)
		throws Exception
	{
		//if (debug) System.out.println("+writeToFile elements="+message.size());
  	for (int i=0; i<message.size();i++) {
  	  byte[] b = new byte[1];
  	  if (message.elementAt(i) instanceof byte[])
			  b = ((byte[])message.elementAt(i));
  	  else if (message.elementAt(i) instanceof Byte)
  	    b[0] = ((Byte)message.elementAt(i)).byteValue();
  	  else
  	    throw new Exception("Unhandled object attempted to be written! "+(message.elementAt(i)));
			//if (debug) System.out.println(new String(b,"UTF-8"));
	    fos.write(b);
		  fos.flush();
		}
		message.clear();
		//if (debug) System.out.println("-writeToFile");
  }
}