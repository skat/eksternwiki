package dk.skat.sommerhus.transformation.javacallout;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Vector;
import java.nio.channels.FileChannel;

/**
 * <p>Implements Sommerhus message structure. Input is read from a filestream and written to a filestream</p>
 * <p><pre>
 * Individnavn:
 * Filnr.:
 * Individnr:
 * Individst�rrelse 32 (min/max tegn)
 * Dataforkortelse	L�ngde i bytes	Repr�sentation	Bem�rkninger
 * CVR-nr.	         8	            N	              For udlejningsbureauet
 * KALENDER�R	       4	            N	              Kalender�ret indberetningen vedr�rer
 * KOMMUNEKODE	     3	            N	              Kode for den kommune, hvor fritidsboligen ligger. Hvis fritidsboligen ligger i udlandet angives 999 som kommunekode
 * L�BENUMMER	       6	            N	              For fritidsboligen
 * LEJEBEL�B	      11	            N	              Bruttolejeindt�gt i hele kroner
 *
 * </pre></p>
 * @author Ren� Hjortskov Nielsen, SKAT
 * @version 0.1
 */
public class SommerhusXMLMessage extends SommerhusXMLMessageBase implements SommerhusXMLMessageInterface
{
  private long len = -1;

	public SommerhusXMLMessage(boolean debug, long len) {
		this.debug = debug;
		this.len = len;
	}

	/**
	 * Read data
   *
	 */
  public void readFromFile(FileInputStream fis, FileOutputStream fos)
		throws Exception
	{
		//if (debug) System.out.println("+readFromFile");
		// Reset message
		if (message!=null) { message.clear(); } else { message = new Vector(); }

    // Ignore first line, which is a text header
    readUntilFieldBytes(fis,0,0,82);
    readUntilFieldBytes(fis,0,0,82);
    readUntilFieldBytes(fis,0,0,82);
    readUntilFieldBytes(fis,0,0,82);
    readUntilFieldBytes(fis,0,0,82);
    readLinefeed(fis);

		// Create message...
    FileChannel fc = fis.getChannel();
    while (fc.position()<len) {
      message.addElement(getBytesFromString("<fase2.1:Angivelse><fase2.1:Angiver><fase2.1:VirksomhedCVRNummer>"));
  		message.addElement(readBytes(fis,0,8,1,null));  // CVRNR
  		message.addElement(getBytesFromString("</fase2.1:VirksomhedCVRNummer></fase2.1:Angiver><fase2.1:EjendomUdlejningIndkomst�r>"));
  		message.addElement(readBytes(fis,0,4,1,null));  // �R
  		message.addElement(getBytesFromString("</fase2.1:EjendomUdlejningIndkomst�r><fase2.1:EjendomOplysninger><fase2.1:KommuneNummer>"));
  		message.addElement(readUntilFieldBytes(fis,0,0,3));  // KOMMUNEKODE
  		message.addElement(getBytesFromString("</fase2.1:KommuneNummer><fase2.1:EjendomNummer>"));
  		message.addElement(readUntilFieldBytes(fis,0,0,6));  // L�BENUMMER
  		message.addElement(getBytesFromString("</fase2.1:EjendomNummer></fase2.1:EjendomOplysninger><fase2.1:EjendomUdlejningBruttoLejeIndt�gtBel�b>"));
  		message.addElement(readUntilFieldBytes(fis,0,0,11)); // LEJEBEL�B
  		message.addElement(getBytesFromString("</fase2.1:EjendomUdlejningBruttoLejeIndt�gtBel�b></fase2.1:Angivelse>"));
      // Discard LF
      readLinefeed(fis);
      writeToFile(fos);
    }
		//if (debug) System.out.println("-readFromFile");
  }
}