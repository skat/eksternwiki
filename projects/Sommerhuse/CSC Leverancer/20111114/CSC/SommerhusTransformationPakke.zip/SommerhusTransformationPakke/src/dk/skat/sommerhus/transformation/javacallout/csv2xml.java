package dk.skat.sommerhus.transformation.javacallout;

import java.util.zip.GZIPOutputStream;
import java.util.Date;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.channels.FileChannel;

import java.net.URL;
import java.net.URLClassLoader;
import java.io.UnsupportedEncodingException;

/**
 * <p>This POJO is intended to be in the portal and the application server.</p>
 *
 * <p>A message is uploaded in the portal and stored on disk. The fixed csv format is given to this class
 * either as a absolute filename or the csv string to parse. A new file pointer or string is returned.
 *
 * The result is gziped and base 64 encoded SKAT xml.</p>
 *
 * Subversion http://versionhost.ccta.dk/svn/SKAT/products/branches/Fase1/eService/SommerhusTransformer
 *
 * @author Rene Hjortskov Nielsen, SKAT
 * @version 0.1
 */
public class csv2xml
{
  /**
   * transform from string form
   *
   * @param body64str String containing the payload to be transformed
   * @param datadir Pathlocation for temporary streams
   * @param debug Enable POJO in debug mode for extra logging
   * @return String BASE64 encoded String with an gzipped xml payload
   */
  public static String transform(String body64str, String datadir, boolean debug) {
	 	try {
	 		return new String(transform(body64str.getBytes("UTF-8"), datadir, debug),"UTF-8");
	 	} catch (Exception e) {
	 		throw new IllegalArgumentException(e);
	 	}
  }

  /**
   * transform from byte form
   *
   * @param body64 Byte array containing the payload to be transformed
   * @param datadir Pathlocation for temporary streams
   * @param debug Enable POJO in debug mode for extra logging
   * @return byte[] BASE64 encoded byte array with an gzipped xml payload
   */
  public static byte[] transform(byte[] body64, String datadir, boolean debug) {
    return null;
  }

  /**
   * Transform from a file pointer
   *
   * @param filename_csv String containing a filename pointing to the payload to be transformed
   * @param datadir Pathlocation for temporary streams
   * @param debug Enable POJO in debug mode for extra logging
   * @return String filename BASE64 encoded gzipped xml payload
   */
  public static String transformfile(String filename_csv, String datadir, boolean debug) {
	  ByteArrayOutputStream byteos = null;
	  FileInputStream fis;
	  FileOutputStream fos;
	  FileOutputStream fosEnvelope;
		long startTime = 0L;
		long endTime = 0L;
		startTime = (new Date()).getTime();

    // Filename needs to be thread safe, hence add milliseconds to filename
    String filename = datadir + System.currentTimeMillis();
    try {
      Thread tmpThread = new Thread();
      filename = datadir + "Sommerhus_csv2xml_" + tmpThread.getName() + "_" + System.currentTimeMillis();
      if (debug) System.out.println("Using prefix for file: "+ filename);
    } catch (Exception e) {
      // NOP
    }

		String filename_base64 = filename+".xml.gz.base64";
		String filename_zip = filename+".xml.gz";
		String filename_xml = filename+".xml";
		String filename_skatxml = filename+"_skat.xml";
		try {
	    // loop while data in body
	    fos = new FileOutputStream(filename_xml);
	    File f = new File(filename_csv);
	    long flen = f.length()-1L;
	    fis = new FileInputStream(f);
	    FileChannel fc = fis.getChannel();

	    fosEnvelope = new FileOutputStream(filename_skatxml);
	    if (debug) System.out.println("Free memory step 1: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" Analyse SKAT Envelope header");
	    SommerhusXMLEnvelopeHeader xmlenvelopeheader = new SommerhusXMLEnvelopeHeader(debug);
	    xmlenvelopeheader.readFromFile(fis,fosEnvelope);
	    xmlenvelopeheader.writeToFile(fosEnvelope);

/*
	    if (debug) System.out.println("Free memory step 1: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" Analyse STARTINDIVID");
	    SommerhusXMLMessageHeader xmlheader = new SommerhusXMLMessageHeader(debug, xmlfooter.getBrugernummer(), rowCount, afgiver, indsender);
	    xmlheader.readFromFile(fis,fos);
	    xmlheader.writeToFile(fos);
	    xmlheader = null;
*/
	    SommerhusXMLMessageInterface xmlmessage = (SommerhusXMLMessageInterface)new SommerhusXMLMessage(debug,flen);
  	  if (xmlmessage==null)
  	    throw new Exception("Message parser failed to instantiate");
	    if (debug) System.out.println("Free memory step 2: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" Analyse INDIVID");
	    xmlmessage.readFromFile(fis,fos);
		  xmlmessage = null;

/*
	    if (debug) System.out.println("Free memory step 3: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" Analyse SLUTINDIVID");
	    SommerhusXMLMessageFooter xmlfooter = new SommerhusXMLMessageFooter(debug);
	    xmlfooter.readFromFile(fis,fos);
		  xmlfooter.writeToFile(fos);
*/
//	    xmlfooter = null;
	    fis.close();
	    fos.close();

	    if (debug) System.out.println("Free memory step 3: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" gzip the outputted stream");
	    fis = new FileInputStream(filename_xml);
	    fos = new FileOutputStream(filename_zip);
	    GZIPOutputStream zip = new GZIPOutputStream(fos);
	    int i = 0;
	    byte[] buf = new byte[1024*1024];
      int len;
      while ((len = fis.read(buf)) > 0) {
        zip.write(buf, 0, len);
      }
	    fis.close();
	    zip.finish();
	    fos.close();

	    if (debug) System.out.println("Free memory step 4: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" base64 encode the gzip archieve");
	    f = new File(filename_zip);
	    flen = f.length();
	    fis = new FileInputStream(f);
	    byteos = new ByteArrayOutputStream((int)flen);
      Base64 base64 = new Base64();
      base64.encode(fis, byteos);
	    fis.close();

	    if (debug) System.out.println("Free memory step 5: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" Combine SKAT Envelope and base64 data");
      fosEnvelope.write(byteos.toByteArray());
      fosEnvelope.flush();

	    if (debug) System.out.println("Free memory step 6: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" SKAT Envelope footer");
	    SommerhusXMLEnvelopeFooter xmlenvelopefooter = new SommerhusXMLEnvelopeFooter(debug);
	    xmlenvelopefooter.readFromFile(fis,fosEnvelope);
		  xmlenvelopefooter.writeToFile(fosEnvelope);
		  fosEnvelope.close();
      xmlenvelopefooter = null;
      xmlenvelopeheader = null;

//+++ debug
			if (debug) {
				fos = new FileOutputStream(filename_base64);
				fos.write(byteos.toByteArray());
				fos.flush();
				fos.close();
			}
//---
      byteos = null;

  		if (debug) {
  		  endTime = (new Date()).getTime();
  		  System.out.println("Elasped ms "+(endTime-startTime));
  		}

  		// In production we remove temporary files
  	  if (!debug) {
  	  	removeFile(filename_csv);
  	  	removeFile(filename_xml);
  	  	removeFile(filename_base64);
  	  	removeFile(filename_zip);
  	  }
		} catch(Exception e) {
		  String errstr = "Error in message ["+filename_csv+"]:"+e+"\n";
		  StackTraceElement[] ste = e.getStackTrace();
		  for (int i=0; i<ste.length; i++) {
		    errstr += ste[i].toString()+"\n";
		  }
	 	  //System.out.println(""+errstr);
      throw new IllegalArgumentException(errstr);
 		}

    return filename_skatxml;
  }

  private static void removeFile(String filename) {
    try {
      File f =new File(filename);
      if (f.exists())
        f.delete();
    } catch (Exception e) {
      // NOP
    }
  }

  private static void printClasspath()
  {
    try {
      //Get the System Classloader
      ClassLoader sysClassLoader = ClassLoader.getSystemClassLoader();
      //Get the URLs
      URL[] urls = ((URLClassLoader)sysClassLoader).getURLs();
      for(int i=0; i< urls.length; i++) {
        System.out.println(urls[i].getFile());
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}