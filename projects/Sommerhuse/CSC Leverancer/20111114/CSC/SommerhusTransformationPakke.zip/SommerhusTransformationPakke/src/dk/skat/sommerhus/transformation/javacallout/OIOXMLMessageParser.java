package dk.skat.sommerhus.transformation.javacallout;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.ext.LexicalHandler;

import javax.xml.transform.Source;
import javax.xml.transform.URIResolver;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.*;

import java.io.File;
import java.nio.channels.FileChannel;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Hashtable;
import java.util.Date;
import java.util.Enumeration;
import java.util.zip.GZIPOutputStream;

/**
 * <p>Implements OIOXML SAX messages parser and XSLT transformer.
 * Input is read from a filestream and written to an filestream</p>
 *
 * Logic has been implemented to optimize which xml blocks to process.
 * This applies to xml substructures and implies the need to copy the
 * message level wrapped namespaces to the individual blocks chosen for
 * processing
 *
 * @author Ren� Hjortskov Nielsen, SKAT
 * @version 0.6
 */
public class OIOXMLMessageParser extends DefaultHandler2 implements URIResolver
{
  private FileInputStream fis;
  private FileOutputStream fos;
  private FileOutputStream fosSKAT;
  private String filename_xml;
  private String filename_zip;

  // Transformation goverment
  private Hashtable allowedOIOTransforms;
  private Hashtable allowedSKATTransforms;
  private final String prefix = "hsws:";
  private final String hoprefix = "kontekst:";
  private String elementProcessingDone = "";
  private String elementNameSpaces = "";
  private TransformerFactory sf;
  private Transformer t;
  private StreamResult srxml;
  private StreamResult srskatxml;
  private StreamSource ssxsl;

  // Debug info
	private boolean debug = false;
	private boolean escapeSequenceFound = false;
  private long flen = 0;
  private FileChannel fc;
  private long tidms;

  private ByteArrayOutputStream bb;

	public OIOXMLMessageParser(boolean debug, FileInputStream fis, FileOutputStream fos, FileOutputStream fosSKAT, long flen, String filename_xml, String filename_zip) {
		this.debug = debug;
		this.fis = fis; // OIO Stream
		this.fos = fos; // BASE64 stream
		this.fosSKAT = fosSKAT; // SKATXML Stream
		this.flen = flen;
		this.filename_xml = filename_xml;
		this.filename_zip = filename_zip;
		allowedOIOTransforms = new Hashtable();
		allowedSKATTransforms = new Hashtable();
    // Full message processing, which should be disabled
    // Full message processing for small messages
    // Structures for very large xml files
		allowedOIOTransforms.put(prefix+"Angivelse","");
		//allowedOIOTransforms.put(prefix+"ApplyEverything","");
		allowedSKATTransforms.put(hoprefix+"HovedOplysninger","");
	}

	public boolean parse()
	  throws Exception
	{
	  // Configure transformation
		SAXParserFactory factory = SAXParserFactory.newInstance();
    SAXParser saxParser = factory.newSAXParser();
		saxParser.setProperty("http://xml.org/sax/properties/lexical-handler",this);
		sf = TransformerFactory.newInstance();
		sf.setURIResolver(this);
    srxml = new StreamResult(fos);
    // Preload xsl stylesheets
    Enumeration enu = allowedOIOTransforms.keys();
    while (enu.hasMoreElements()) {
      String key = (String)enu.nextElement();
      if (debug) System.out.println("Preloading xsl ["+key.substring(prefix.length())+".xsl]");
      InputStream is = this.getClass().getClassLoader().getResourceAsStream(key.substring(prefix.length())+".xsl");

      // This is only necessary on MAC and Windows and can be set as a system property
      // in those case. The production system run on Linux, which does not have the issue
      // with 0x0D 0x0A
      // System.setProperty("line.separator","\n");

      ssxsl = new StreamSource(is);
  		t = sf.newTransformer(ssxsl);
  		allowedOIOTransforms.put(key,t);
    }
    enu = allowedSKATTransforms.keys();
    while (enu.hasMoreElements()) {
      String key = (String)enu.nextElement();
      if (debug) System.out.println("Preloading xsl ["+key.substring(hoprefix.length())+".xsl]");
      InputStream is = this.getClass().getClassLoader().getResourceAsStream(key.substring(hoprefix.length())+".xsl");

      // This is only necessary on MAC and Windows and can be set as a system property
      // in those case. The production system run on Linux, which does not have the issue
      // with 0x0D 0x0A
      // System.setProperty("line.separator","\n");

      ssxsl = new StreamSource(is);
  		t = sf.newTransformer(ssxsl);
  		allowedSKATTransforms.put(key,t);
    }

    // Initialize stream for write temporary result to be transformed
		bb = new ByteArrayOutputStream();

    fc = fis.getChannel();
    tidms =(new Date()).getTime();

		saxParser.parse(fis, this);
		saxParser = null;
		allowedOIOTransforms.clear();
		allowedSKATTransforms.clear();
		bb = null;
		return escapeSequenceFound;
	}

  private final String skatinterface = "UdlejningFritidEjendomAngivelseFilOpret_I";
  private final String AngivelseListe = "AngivelseListe";
  private void tmpWrite(String str, String xmlevent)
    throws Exception
  {
    if (debug) System.out.println("+"+str);
    if (xmlevent.equals("START")) {
      int pos = str.indexOf(":")+1;
      String attrStr = str;
      String matchStr = attrStr.substring(pos);
      boolean matched = false;
      if (matchStr.startsWith(skatinterface)) { attrStr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<fase2.1:UdlejningFritidEjendomAngivelseFilOpret_I xmlns:fase2.1=\"http://skat.dk/begrebsmodel/2009/01/15/\" xmlns:ctxt=\"http://skat.dk/begrebsmodel/xml/schemas/kontekst/2007/05/31/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"; matched=true; }
      else if (matchStr.startsWith(AngivelseListe)) { attrStr = "<fase2.1:IndholdValg><fase2.1:MeddelelseIndhold><base64>"; matched=true; }
      else attrStr = "";
      if (debug) System.out.println("-"+attrStr);
      if (matched) fosSKAT.write(attrStr.getBytes("UTF-8"));
    }
    if (xmlevent.equals("END")) {
      int pos = str.indexOf(":")+1;
      String matchStr = str.substring(pos);
      boolean matched = false;
      if (matchStr.startsWith(AngivelseListe)) {
        // here we need to zip and base64 encode the OIO transformed list structure
        combineSKATXMLWithOIOTransformation();
        str = "</base64></fase2.1:MeddelelseIndhold></fase2.1:IndholdValg>"; matched=true;
      }
      if (matchStr.startsWith(skatinterface)) { str = "</fase2.1:UdlejningFritidEjendomAngivelseFilOpret_I>"; matched=true; }
      if (debug) System.out.println("-"+str);
      if (matched) fosSKAT.write(str.getBytes("UTF-8"));
    }
    bb.write(str.getBytes("UTF-8"));
  }

	public void startElement(String uri, String localName, String qName, Attributes attributes)
    throws SAXException
  {
    if (debug) System.out.println("startElement uri="+uri+" local="+localName+" qname="+qName);
    try {
      if (debug) {
        long tidmsnow = (new Date()).getTime();
        if ((tidmsnow-tidms)>(long)(10000)) {//10 seconds
          tidms = tidmsnow;
          float status = (float)fc.position()/(float)flen*(float)100;
          System.out.println("Free memory (SAXParser): "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" ..."+(int)status+"%");
        }
      }

  	  String eName = localName; // element name
  		if ("".equals(eName)) eName = qName; // not namespace-aware

      // Discard data read up until this point if it is a known message block
      if (elementProcessingDone.equals("") && (allowedOIOTransforms.containsKey(eName) || allowedSKATTransforms.containsKey(eName))) {
        elementProcessingDone = eName;
        bb.reset();
        // Write next element with message wrapper namespaces
    		tmpWrite("<"+eName+" "+elementNameSpaces,"START");
      } else {
        // Write next element as is
    		tmpWrite("<"+eName,"START");
    	}

  		if (attributes != null) {
    		String tmpNS = "";
  		  for (int i = 0; i < attributes.getLength(); i++) {
  			  String aName = attributes.getLocalName(i); // Attr name
  			  if ("".equals(aName)) aName = attributes.getQName(i);
  			  tmpWrite(" "+aName+"=\""+attributes.getValue(i)+"\"","START");
  			  if (elementNameSpaces.equals("")) tmpNS += aName+"=\""+attributes.getValue(i)+"\" ";
  			}
  			if (elementNameSpaces.equals("")) elementNameSpaces = tmpNS;
  	  }
  		tmpWrite(">","");
	  } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  public void endElement(String uri, String localName, String qName)
    throws SAXException
  {
    System.out.println("endElement uri="+uri+" local="+localName+" qname="+qName);
  	try {
    	boolean blockFound = false;

		  String eName = localName; // element name
	    if ("".equals(eName)) eName = qName; // not namespace-aware
	    tmpWrite("</"+eName+">","END");

	    // XSLT process this block only if it is a known message block
	    if (elementProcessingDone.equals(eName) && allowedOIOTransforms.containsKey(eName)) {
	      if (debug) System.out.println("OIO XLST BLOCK");
	    	blockFound = true;

        ByteArrayInputStream tmpbytes = new ByteArrayInputStream(bb.toByteArray());

        StreamSource ssxml = new StreamSource(tmpbytes);
        t = (Transformer)allowedOIOTransforms.get(eName);
        t.transform(ssxml,srxml);

        tmpbytes.close();
        tmpbytes = null;
	    }
	    if (elementProcessingDone.equals(eName) && allowedSKATTransforms.containsKey(eName)) {
	      if (debug) System.out.println("SKAT XLST BLOCK");
	    	blockFound = true;
        if (debug) System.out.println("["+new String(bb.toByteArray())+"]");
        ByteArrayInputStream tmpbytes = new ByteArrayInputStream(bb.toByteArray());
        ByteArrayOutputStream tmpbytesout = new ByteArrayOutputStream();

        StreamSource ssxml = new StreamSource(tmpbytes);
        t = (Transformer)allowedSKATTransforms.get(eName);
        srskatxml = new StreamResult(tmpbytesout);
        t.transform(ssxml,srskatxml);

        // Need to replace this with nothing
        // <?xml version="1.0" encoding="UTF-8"?>
        byte[] buf = tmpbytesout.toByteArray();
        int len = buf.length;
        // Need to replace this with nothing
        // <?xml version="1.0" encoding="UTF-8"?>
        byte[] buftmp = new byte[len-40];
        for (int j=0; j<(len-40); j++)
          buftmp[j] = buf[j+40];
        buf = buftmp;
        if (debug) System.out.println(new String(buf));
        len -= 40;
        fosSKAT.write(buf, 0, len);

        tmpbytesout.close();
        tmpbytesout = null;
        tmpbytes.close();
        tmpbytes = null;
	    }

	    if (blockFound) {
	    	elementProcessingDone = "";
	    	bb.reset();
	    }
	  } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  // lexical-handler
  public void characters(char ch[], int start, int length)
    throws SAXException
  {
    try {
		  tmpWrite(String.valueOf(ch, start, length),"");
    } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  public Source resolve(String href, String base) {
   	return new StreamSource(this.getClass().getClassLoader().getResourceAsStream(href));
  }

  // Lexical handler
  public void startCDATA()
  throws SAXException
  {
    try {
  	  tmpWrite("<![CDATA[","");
  	  escapeSequenceFound = true;
    } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  public void endCDATA()
  throws SAXException
  {
    try {
      tmpWrite("]]>","");
    } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  private void combineSKATXMLWithOIOTransformation()
    throws Exception
  {
    if (debug) System.out.println("+combineSKATXMLWithOIOTransformation");
    // OIO tranformation stream is required to be done at this point
    fos.flush();
    fos.close();
    FileInputStream fisfis = null;
    if (debug) System.out.println("Free memory step 2: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" gzip the outputted stream");
    fisfis = new FileInputStream(filename_xml);
    FileOutputStream fosZIP = new FileOutputStream(filename_zip);
    GZIPOutputStream zip = new GZIPOutputStream(fosZIP);
    byte[] buf = new byte[1024*1024];
    int len;
    int i=0;
    while ((len = fisfis.read(buf)) > 0) {
      // Need to replace this with nothing
      // <?xml version="1.0" encoding="UTF-8"?>
      if (i==0) {
        byte[] buftmp = new byte[len-40];
        for (int j=0; j<(len-40); j++)
          buftmp[j] = buf[j+40];
        buf = buftmp;
        if (debug) System.out.println(new String(buf));
        len -= 40;
        i++;
      }
      zip.write(buf, 0, len);
      if (debug) System.out.println(len+" bytes gzipped");
    }
    fisfis.close();
    zip.finish();
    fosZIP.close();

    if (debug) System.out.println("Free memory step 3: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" base64 encode the transformed OIO XML");
    File f = new File(filename_zip);
    fisfis = new FileInputStream(f);
    ByteArrayOutputStream bos = new ByteArrayOutputStream((int)f.length());
    Base64 base64 = new Base64();
    base64.encode(fisfis, bos);
    fisfis.close();
    fosSKAT.write(bos.toByteArray());
    bos = null;
    if (debug) System.out.println("-combineSKATXMLWithOIOTransformation");
  }
}