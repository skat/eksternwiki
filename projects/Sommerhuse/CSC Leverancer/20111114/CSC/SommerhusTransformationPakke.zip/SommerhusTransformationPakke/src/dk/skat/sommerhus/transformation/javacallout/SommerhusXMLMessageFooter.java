package dk.skat.sommerhus.transformation.javacallout;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Vector;

/**
 * Not used, left for completeness
 *
 * @author Ren� Hjortskov Nielsen, SKAT
 * @version 0.1
 */
public class SommerhusXMLMessageFooter extends SommerhusXMLMessageBase implements SommerhusXMLMessageInterface
{
	private Vector message = new Vector();

	public SommerhusXMLMessageFooter(boolean debug) {
		this.debug = debug;
	}

	/**
	 * Produce
	 */
  public void readFromFile(FileInputStream fis, FileOutputStream fos)
		throws Exception
	{
		if (debug) System.out.println("+SommerhusXMLMessageFooter");
		// Reset message
		if (message!=null) { message.clear(); } else { message = new Vector(); }

		if (debug) System.out.println("-SommerhusXMLMessageFooter");
  }

  public void writeToFile(FileOutputStream fos)
		throws Exception
	{
		//if (debug) System.out.println("+writeToFile elements="+message.size());
  	for (int i=0; i<message.size();i++) {
  	  byte[] b = new byte[1];
  	  if (message.elementAt(i) instanceof byte[])
			  b = ((byte[])message.elementAt(i));
  	  else if (message.elementAt(i) instanceof Byte)
  	    b[0] = ((Byte)message.elementAt(i)).byteValue();
  	  else
  	    throw new Exception("Unhandled object attempted to be written! "+(message.elementAt(i)));
			//if (debug) System.out.println(new String(b,"UTF-8"));
	    fos.write(b);
		  fos.flush();
		}
		message.clear();
		//if (debug) System.out.println("-writeToFile");
  }

}