package dk.skat.sommerhus.transformation.javacallout;

import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.Date;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;

public class xml2skattest
{
  public static void main(String[] argv) {
    try {
      xml2skat.transformfile(argv[0], "./generated/test/", true);
	  } catch(Exception e) {
	  	e.printStackTrace();
	  }
  }

}