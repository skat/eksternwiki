package dk.skat.sommerhus.transformation.javacallout;

//import org.apache.commons.codec.binary.Base64InputStream;
import com.sun.mail.util.BASE64DecoderStream;
import com.sun.mail.util.BASE64EncoderStream;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Fast implementation of Base64 encode/decode
 */
public class Base64
{
  public void encode(InputStream is, OutputStream os)
    throws Exception
  {
    //Base64InputStream b64is = new Base64InputStream(is, true, -1, null);
    BASE64EncoderStream b64os = new BASE64EncoderStream(os);
    byte[] b = new byte[1024];
    int i=0;
    /*
    while ((i=b64is.read(b,0,1024))!=-1) {
      os.write(b,0,i);
    }
    b64is.close();
    */
    while ((i=is.read(b,0,1024))!=-1) {
      b64os.write(b,0,i);
    }
    b64os.flush();
    b64os.close();
  }

  public void decode(InputStream is, OutputStream os)
    throws Exception
  {
    //Base64InputStream b64is = new Base64InputStream(is, false, -1, null);
    BASE64DecoderStream b64is = new BASE64DecoderStream(is);
    byte[] b = new byte[1024];
    int i=0;
    while ((i=b64is.read(b,0,1024))!=-1) {
      os.write(b,0,i);
    }
    b64is.close();
  }

}