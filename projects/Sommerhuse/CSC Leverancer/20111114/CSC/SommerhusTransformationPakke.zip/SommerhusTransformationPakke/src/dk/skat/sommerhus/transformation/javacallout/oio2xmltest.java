package dk.skat.sommerhus.transformation.javacallout;

import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.Date;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;

public class oio2xmltest
{
  public static void main(String[] argv) {
    try {
      oio2xml.transformfile(argv[0], "./generated/test/", true);
	  } catch(Exception e) {
	  	e.printStackTrace();
	  }
  }

}