package dk.skat.sommerhus.transformation.javacallout;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.ext.LexicalHandler;

import javax.xml.transform.Source;
import javax.xml.transform.URIResolver;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.*;

import java.io.File;
import java.nio.channels.FileChannel;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Hashtable;
import java.util.Date;
import java.util.Enumeration;
import java.util.zip.GZIPInputStream;

/**
 * <p>Implements SKATXML SAX messages parser and XSLT transformer.
 * Input is read from a filestream and written to an filestream</p>
 *
 * Logic has been implemented to optimize which xml blocks to process.
 * This applies to xml substructures and implies the need to copy the
 * message level wrapped namespaces to the individual blocks chosen for
 * processing
 *
 * @author Ren� Hjortskov Nielsen, SKAT
 * @version 0.6
 */

public class XMLSKATMessageParser extends DefaultHandler2 implements URIResolver
{
  private FileInputStream fis;
  private FileOutputStream fos;
  private FileOutputStream fosSKAT;
  private String filename_xml;
  private String filename_zip;

  // Transformation goverment
  private Hashtable allowedOIOTransforms;
  private Hashtable allowedSKATTransforms;
  private final String prefix = "hsws:";
  private final String hoprefix = "ctxt:";
  private String elementProcessingDone = "";
  private String elementNameSpaces = "";
  private TransformerFactory sf;
  private Transformer t;
  private StreamResult srxml;
  private StreamResult srskatxml;
  private StreamSource ssxsl;

  // Debug info
	private boolean debug = false;
	private boolean escapeSequenceFound = false;
  private long flen = 0;
  private FileChannel fc;
  private long tidms;

  private ByteArrayOutputStream bb;

	public XMLSKATMessageParser(boolean debug, FileInputStream fis, FileOutputStream fos, long flen, String filename_xml, String filename_zip) {
		this.debug = debug;
		this.fis = fis; // OIO Stream
		this.fos = fos; // BASE64 stream
		this.flen = flen;
		this.filename_xml = filename_xml;
		this.filename_zip = filename_zip;
		allowedOIOTransforms = new Hashtable();
		allowedSKATTransforms = new Hashtable();
    // Full message processing, which should be disabled
    // Full message processing for small messages
    // Structures for very large xml files
		//allowedOIOTransforms.put(prefix+"Angivelse","");
		//allowedOIOTransforms.put(prefix+"ApplyEverything","");
		//allowedSKATTransforms.put(hoprefix+"HovedOplysninger","");
	}

	public boolean parse()
	  throws Exception
	{
	  // Configure transformation
		SAXParserFactory factory = SAXParserFactory.newInstance();
    SAXParser saxParser = factory.newSAXParser();
		saxParser.setProperty("http://xml.org/sax/properties/lexical-handler",this);
		sf = TransformerFactory.newInstance();
		sf.setURIResolver(this);
    srxml = new StreamResult(fos);
    // Preload xsl stylesheets
    Enumeration enu = allowedOIOTransforms.keys();
    while (enu.hasMoreElements()) {
      String key = (String)enu.nextElement();
      if (debug) System.out.println("Preloading xsl ["+key.substring(prefix.length())+".xsl]");
      InputStream is = this.getClass().getClassLoader().getResourceAsStream(key.substring(prefix.length())+".xsl");

      // This is only necessary on MAC and Windows and can be set as a system property
      // in those case. The production system run on Linux, which does not have the issue
      // with 0x0D 0x0A
      // System.setProperty("line.separator","\n");

      ssxsl = new StreamSource(is);
  		t = sf.newTransformer(ssxsl);
  		allowedOIOTransforms.put(key,t);
    }
    enu = allowedSKATTransforms.keys();
    while (enu.hasMoreElements()) {
      String key = (String)enu.nextElement();
      if (debug) System.out.println("Preloading xsl ["+key.substring(prefix.length())+".xsl]");
      InputStream is = this.getClass().getClassLoader().getResourceAsStream(key.substring(prefix.length())+".xsl");

      // This is only necessary on MAC and Windows and can be set as a system property
      // in those case. The production system run on Linux, which does not have the issue
      // with 0x0D 0x0A
      // System.setProperty("line.separator","\n");

      ssxsl = new StreamSource(is);
  		t = sf.newTransformer(ssxsl);
  		allowedSKATTransforms.put(key,t);
    }

    // Initialize stream for write temporary result to be transformed
		bb = new ByteArrayOutputStream();

    fc = fis.getChannel();
    tidms =(new Date()).getTime();

		saxParser.parse(fis, this);
		saxParser = null;
		allowedOIOTransforms.clear();
		allowedSKATTransforms.clear();
		bb = null;
		return escapeSequenceFound;
	}

  private boolean foundBase64 = false;
  private void tmpWrite(String str, String xmlevent)
    throws Exception
  {
    if (debug) System.out.println("+"+str);
    bb.write(str.getBytes("UTF-8"));
  }

	public void startElement(String uri, String localName, String qName, Attributes attributes)
    throws SAXException
  {
    if (debug) System.out.println("startElement uri="+uri+" local="+localName+" qname="+qName);
    try {
      if (debug) {
        long tidmsnow = (new Date()).getTime();
        if ((tidmsnow-tidms)>(long)(10000)) {//10 seconds
          tidms = tidmsnow;
          float status = (float)fc.position()/(float)flen*(float)100;
          System.out.println("Free memory (SAXParser): "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" ..."+(int)status+"%");
        }
      }

  	  String eName = localName; // element name
  		if ("".equals(eName)) eName = qName; // not namespace-aware

      int pos = eName.indexOf(":")+1;
      String str = eName;
      String matchStr = str.substring(pos);
      if (matchStr.startsWith("base64")) {
        foundBase64 = true;
        bb.reset();
        return;
      }
      if (matchStr.startsWith("MeddelelseIndhold")) {
        fos.write(("<fase2.1:Meddelelse><fase2.1:AngivelseListe>").getBytes("UTF-8"));
        return;
      }

      // Echo all data, which is not base64 encoded
   		fos.write(("<"+eName).getBytes("UTF-8"));

  		if (attributes != null) {
    		String tmpNS = "";
  		  for (int i = 0; i < attributes.getLength(); i++) {
  			  String aName = attributes.getLocalName(i); // Attr name
  			  if ("".equals(aName)) aName = attributes.getQName(i);
  			  fos.write((" "+aName+"=\""+attributes.getValue(i)+"\"").getBytes("UTF-8"));
  			  if (elementNameSpaces.equals("")) tmpNS += aName+"=\""+attributes.getValue(i)+"\" ";
  			}
  			if (elementNameSpaces.equals("")) elementNameSpaces = tmpNS;
  	  }
  	  fos.write((">").getBytes("UTF-8"));
	  } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  public void endElement(String uri, String localName, String qName)
    throws SAXException
  {
    System.out.println("endElement uri="+uri+" local="+localName+" qname="+qName);
  	try {
    	boolean blockFound = false;

		  String eName = localName; // element name
	    if ("".equals(eName)) eName = qName; // not namespace-aware

      int pos = eName.indexOf(":")+1;
      String str = eName;
      String matchStr = str.substring(pos);
      if (matchStr.startsWith("base64")) {
        foundBase64 = false;
        combineSKATXMLWithBASE64ZIP(bb);
        bb.reset();
        return;
      }
      if (matchStr.startsWith("MeddelelseIndhold")) {
        fos.write(("</fase2.1:AngivelseListe></fase2.1:Meddelelse>").getBytes("UTF-8"));
        return;
      }

      // Echo all data, which is not base64 encoded
   		fos.write(("</"+eName+">").getBytes("UTF-8"));
	  } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  // lexical-handler
  public void characters(char ch[], int start, int length)
    throws SAXException
  {
    try {
      if (!foundBase64)
		    fos.write(String.valueOf(ch, start, length).getBytes("UTF-8"));
		  else {
		    bb.write(String.valueOf(ch, start, length).getBytes("UTF-8"));
		  }
    } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  public Source resolve(String href, String base) {
   	return new StreamSource(this.getClass().getClassLoader().getResourceAsStream(href));
  }

  // Lexical handler
  public void startCDATA()
  throws SAXException
  {
    try {
  	  tmpWrite("<![CDATA[","");
  	  escapeSequenceFound = true;
    } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  public void endCDATA()
  throws SAXException
  {
    try {
      tmpWrite("]]>","");
    } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  private void combineSKATXMLWithBASE64ZIP(ByteArrayOutputStream base64bb)
    throws Exception
  {
    if (debug) System.out.println("+combineSKATXMLWithBASE64ZIP ["+new String(base64bb.toByteArray())+"]");

    if (debug) System.out.println("Free memory step 2: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" Decode BASE64");
    FileOutputStream fosfos = new FileOutputStream(filename_zip);
    ByteArrayInputStream bis = new ByteArrayInputStream(base64bb.toByteArray());
    Base64 base64 = new Base64();
    base64.decode(bis, fosfos);
    fosfos.close();
    bis.close();

    if (debug) System.out.println("Free memory step 3: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" Gunzip payload");
    GZIPInputStream zip = new GZIPInputStream(new FileInputStream(filename_zip),1024*1024);
    byte[] buf = new byte[1024*1024];
    int len;
    while ((len = zip.read(buf)) > 0) {
      fos.write(buf, 0, len);
    }
    buf = null;
    zip.close();

    if (debug) System.out.println("-combineSKATXMLWithBASE64ZIP");
  }
}