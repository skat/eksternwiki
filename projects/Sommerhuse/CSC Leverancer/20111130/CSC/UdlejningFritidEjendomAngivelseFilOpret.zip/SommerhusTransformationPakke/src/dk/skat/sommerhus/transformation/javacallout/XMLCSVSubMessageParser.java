package dk.skat.sommerhus.transformation.javacallout;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.ext.DefaultHandler2;
import org.xml.sax.ext.LexicalHandler;

import javax.xml.transform.Source;
import javax.xml.transform.URIResolver;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.*;

import java.io.File;
import java.nio.channels.FileChannel;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Hashtable;
import java.util.Date;
import java.util.Enumeration;
import java.util.zip.GZIPInputStream;

/**
 * <p>Implements SKATXML SAX messages parser and XSLT transformer.
 * Input is read from a filestream and written to an filestream</p>
 *
 * Logic has been implemented to optimize which xml blocks to process.
 * This applies to xml substructures and implies the need to copy the
 * message level wrapped namespaces to the individual blocks chosen for
 * processing
 *
 * @author Ren� Hjortskov Nielsen, SKAT
 * @version 0.6
 */
public class XMLCSVSubMessageParser extends DefaultHandler2 implements URIResolver
{
  private GZIPInputStream fis;
  private FileOutputStream fos;

  // Transformation goverment
  private Hashtable allowedTransforms;
  private final String prefix = "fase2.1:";
  private String elementProcessingDone = "";
  private String elementNameSpaces = "";
  private TransformerFactory sf;
  private Transformer t;
  private StreamResult srcsv;
  private StreamSource ssxsl;

  // Debug info
	private boolean debug = false;
	private boolean escapeSequenceFound = false;
  private long flen = 0;
  private FileChannel fc;
  private long tidms;

  private ByteArrayOutputStream bb;

	public XMLCSVSubMessageParser(boolean debug, GZIPInputStream fis, FileOutputStream fos, long flen) {
		this.debug = debug;
		this.fis = fis;
		this.fos = fos;
		this.flen = flen;
		allowedTransforms = new Hashtable();
    // Structures for very large xml files
		allowedTransforms.put(prefix+"Angivelse","");
	}

	public boolean parse()
	  throws Exception
	{
	  // Configure transformation
		SAXParserFactory factory = SAXParserFactory.newInstance();
    SAXParser saxParser = factory.newSAXParser();
		saxParser.setProperty("http://xml.org/sax/properties/lexical-handler",this);
		sf = TransformerFactory.newInstance();
		sf.setURIResolver(this);
    srcsv = new StreamResult(fos);
    // Preload xsl stylesheets
    Enumeration enu = allowedTransforms.keys();
    while (enu.hasMoreElements()) {
      String key = (String)enu.nextElement();
      if (debug) System.out.println("Preloading xsl ["+key.substring(prefix.length())+"_csv.xsl]");
      InputStream is = this.getClass().getClassLoader().getResourceAsStream(key.substring(prefix.length())+"_csv.xsl");

      // This is only necessary on MAC and Windows and can be set as a system property
      // in those case. The production system run on Linux, which does not have the issue
      // with 0x0D 0x0A
      // System.setProperty("line.separator","\n");

      ssxsl = new StreamSource(is);
  		t = sf.newTransformer(ssxsl);
  		allowedTransforms.put(key,t);
    }

    // Initialize stream for write temporary result to be transformed
		bb = new ByteArrayOutputStream();

//    fc = fis.getChannel();
//    tidms =(new Date()).getTime();

		saxParser.parse(fis, this);
		saxParser = null;
		allowedTransforms.clear();
		bb = null;
		return escapeSequenceFound;
	}

  private void tmpWrite(String str)
    throws Exception
  {
    if (debug) System.out.println("+tmpWrite "+str);
    bb.write(str.getBytes("UTF-8"));
  }

	public void startElement(String uri, String localName, String qName, Attributes attributes)
    throws SAXException
  {
    if (debug) System.out.println("+startElement");
    try {
      /*if (debug) {
        long tidmsnow = (new Date()).getTime();
        if ((tidmsnow-tidms)>(long)(10000)) {//10 seconds
          tidms = tidmsnow;
          float status = (float)fc.position()/(float)flen*(float)100;
          System.out.println("Free memory (SAXParser): "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" ..."+(int)status+"%");
        }
      }*/

  	  String eName = localName; // element name
  		if ("".equals(eName)) eName = qName; // not namespace-aware

  		if (attributes != null) {
    		String tmpNS = "";
  		  for (int i = 0; i < attributes.getLength(); i++) {
  			  String aName = attributes.getLocalName(i); // Attr name
  			  if ("".equals(aName)) aName = attributes.getQName(i);
  			  //tmpWrite(" "+aName+"=\""+attributes.getValue(i)+"\"");
  			  if (elementNameSpaces.equals("")) tmpNS += aName+"=\""+attributes.getValue(i)+"\" ";
  			}
  			if (elementNameSpaces.equals("")) elementNameSpaces = tmpNS;
  	  }

      int pos = eName.indexOf(":")+1;
      String str = eName;
      String matchStr = str.substring(pos);
      if (matchStr.startsWith("base64")) {
        bb.reset();
        return;
      }

      // Discard data read up until this point if it is a known message block
      if (debug) System.out.println("CHECK: "+(elementProcessingDone.equals("") && allowedTransforms.containsKey(eName))+" "+elementProcessingDone+" "+eName);
      if (elementProcessingDone.equals("") && allowedTransforms.containsKey(eName)) {
        elementProcessingDone = eName;
        bb.reset();
        // Write next element with message wrapper namespaces
    		tmpWrite("<"+eName+" "+elementNameSpaces);
      } else {
        // Write next element as is
    		tmpWrite("<"+eName);
    	}

  		tmpWrite(">");
	  } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
    if (debug) System.out.println("-startElement");
  }

  public void endElement(String uri, String localName, String qName)
    throws SAXException
  {
    if (debug) System.out.println("+endElement");

  	try {
    	boolean blockFound = false;
		  String eName = localName; // element name
	    if ("".equals(eName)) eName = qName; // not namespace-aware

      int pos = eName.indexOf(":")+1;
      String str = eName;
      String matchStr = str.substring(pos);
      if (matchStr.startsWith("base64")) {
        bb.reset();
        return;
      }

	    tmpWrite("</"+eName+">");

	    // XSLT process this block only if it is a known message block
	    if (elementProcessingDone.equals(eName) && allowedTransforms.containsKey(eName)) {
	    	blockFound = true;

        ByteArrayInputStream tmpbytes = new ByteArrayInputStream(bb.toByteArray());

        if (debug) System.out.println("==>"+new String (bb.toByteArray(),"UTF-8")+"<===");

        StreamSource ssxml = new StreamSource(tmpbytes);
        t = (Transformer)allowedTransforms.get(eName);
        t.transform(ssxml,srcsv);

        tmpbytes.close();
        tmpbytes = null;
	    }

	    if (blockFound) {
	    	elementProcessingDone = "";
	    	bb.reset();
	    }
	  } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
    if (debug) System.out.println("-endElement");
  }

  // lexical-handler
  public void characters(char ch[], int start, int length)
    throws SAXException
  {
    try {
		  tmpWrite(String.valueOf(ch, start, length));
    } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  public Source resolve(String href, String base) {
   	return new StreamSource(this.getClass().getClassLoader().getResourceAsStream(href));
  }

  // Lexical handler
  public void startCDATA()
  throws SAXException
  {
    try {
  	  tmpWrite("<![CDATA[");
  	  escapeSequenceFound = true;
    } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }

  public void endCDATA()
  throws SAXException
  {
    try {
      tmpWrite("]]>");
    } catch (Exception e) {
	  	throw new SAXException(e.toString());
	  }
  }
}