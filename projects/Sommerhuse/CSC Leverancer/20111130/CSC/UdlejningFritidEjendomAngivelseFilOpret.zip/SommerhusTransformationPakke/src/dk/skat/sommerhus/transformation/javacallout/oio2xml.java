package dk.skat.sommerhus.transformation.javacallout;

import java.util.zip.GZIPOutputStream;
import java.util.Date;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.channels.FileChannel;
import java.io.UnsupportedEncodingException;

/**
 * <p>This POJO is intended to be inserted into a ALSB message flow.</p>
 *
 * <p>OIO XML file pointer has to be transformed. A new file pointer is returned
 * with the result as SKAT xml.</p>
 *
 * @author Ren� Hjortskov Nielsen, SKAT
 * @version 0.1
 */
public class oio2xml
{

  /**
   * Transform
   *
   * @param body64str Payload to be transformed as a String
   * @param datadir Pathlocation for temporary stream e.g. "/tmp/"
   * @param debug Enable POJO in debug mode for extra logging
   * messages. When disabled, temporary files are deleted.
   * @return String Decoded SKAT XML file pointer
   */
  public static String transform(String body64str, String datadir, boolean debug) {
	 	try {
	 		return transform(body64str.getBytes("UTF-8"), datadir, debug);
	 	} catch (Exception e) {
	 		throw new IllegalArgumentException(e);
	 	}
  }

  /**
   * Transform
   *
   * @param body64 Byte array containing the payload to be transformed
   * @param datadir Pathlocation for temporary stream
   * @param debug Enable POJO in debug mode for extra logging
   * messages. When disabled, temporary files are deleted.
   * @return String Decoded SKAT XML file pointer
   */
  public static String transform(byte[] body64, String datadir, boolean debug) {
    // Filename needs to be thread safe, hence add millseconds to filename
    String filename = datadir + System.currentTimeMillis();
    try {
      Thread tmpThread = new Thread();
      filename = datadir + "xml2csv_" + tmpThread.getName() + "_" + System.currentTimeMillis();
      if (debug) System.out.println("Using prefix for file: "+ filename);
    } catch (Exception e) {
      // NOP
    }
		String filename_byte = filename+".xml.base64.gz.byte";
	 	try {
  	  FileOutputStream fos = new FileOutputStream(filename_byte);
  	  fos.write(body64);
  	  fos.close();
	 		return transformfile(filename_byte, datadir, debug);
	 	} catch (Exception e) {
	 		throw new IllegalArgumentException(e);
	 	} finally {
  	  if (!debug) {
  	  	removeFile(filename_byte);
  	  }
	 	}
  }

  /**
   * <p>Transform takes a filename to a file containing OIO XML
   * and decode it to SKAT xml.</p>
   *
   * @param filename_oio String containing a filename pointing to the payload to be transformed
   * @param datadir Pathlocation for temporary streams
   * @param debug Enable POJO in debug mode for extra logging
   * @return String Decoded SKAT XML file pointer
   */
  public static String transformfile(String filename_oio, String datadir, boolean debug) {
    boolean escapeSequenceFound = false;
	  byte[] byteos = new byte[0];
	  FileInputStream fis;
	  FileOutputStream fos;
	  FileOutputStream fosSKAT;
		long startTime = 0L;
		long endTime = 0L;
  	startTime = (new Date()).getTime();

    // Filename needs to be thread safe, hence add millseconds to filename
    String filename = datadir + System.currentTimeMillis();
    try {
      Thread tmpThread = new Thread();
      filename = datadir + "Sommerhus_oio2xml_" + tmpThread.getName() + "_" + System.currentTimeMillis();
      if (debug) System.out.println("Using prefix for file: "+ filename);
    } catch (Exception e) {
      // NOP
    }

		String filename_xml = filename+".xml";
		String filename_zip = filename+".xml.gz";
		String filename_base64 = filename+".xml.gz.base64";
		String filename_skatxml = filename+"_skat.xml";

		try {
	    if (debug) System.out.println("Free memory step 1: "+Runtime.getRuntime().freeMemory()+" of "+Runtime.getRuntime().totalMemory()+" Process OIO xml using a SAX parser with xlst");
	    File f = new File(filename_oio);
	    long flen = f.length();
	    fis = new FileInputStream(f);
	    fos = new FileOutputStream(filename_xml);
	    fosSKAT = new FileOutputStream(filename_skatxml);
			OIOXMLMessageParser xmlparser = new OIOXMLMessageParser(debug,fis,fos,fosSKAT,flen,filename_xml,filename_zip);
			escapeSequenceFound = xmlparser.parse();
			fis.close();
			fos.close();
			xmlparser=null;

  		if (debug) {
  		  endTime = (new Date()).getTime();
  		  System.out.println("Elasped ms "+(endTime-startTime));
  		}

  		// In production we remove temporary files
  	  if (!debug) {
  	  	removeFile(filename_zip);
  	  	removeFile(filename_base64);
  	  	removeFile(filename_xml);
  	  }

		} catch(Exception e) {
		  String errstr = "Error in message ["+filename_oio+"]:\n"+e+"\n";
		  StackTraceElement[] ste = e.getStackTrace();
		  for (int i=0; i<ste.length; i++) {
		    errstr += ste[i].toString()+"\n";
		  }
 	 	  //System.out.println(""+errstr);
      throw new IllegalArgumentException(errstr);
 		}

    return filename_skatxml;
  }

  private static void removeFile(String filename) {
    try {
      File f =new File(filename);
      if (f.exists())
        f.delete();
    } catch (Exception e) {
      // NOP
    }
  }
}