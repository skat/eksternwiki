package dk.skat.sommerhus.transformation.javacallout;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Vector;
import java.nio.channels.FileChannel;
import java.util.Hashtable;
import java.util.UUID;

/**
 * <p>Abstract message class used as a library for message processing
 * and as part of enforcing implementation of shared and individual
 * methods</p>
 *
 * @author Ren� Hjortskov Nielsen, SKAT
 * @version 0.1
 */
abstract class SommerhusXMLMessageBase
{
  protected final int CR = 0x0D;
  protected final int LF = 0x0A;
  protected final int FT = 0x3B;
  protected boolean debug = false;
  public Vector message;// Placeholder for xml message

	protected SommerhusXMLMessageBase() {
	}

  // Common SKAT XML Structures and AKFA BNF Structures

	// Common methods

	/**
	 * <p>Read len bytes from stream after skipping bytes</p>
	 *
	 * <p>Note: field_separator 0x3B is not automatically removed</p>
	 *
	 * <p>field_separator is NOT removed</p>
	 *
	 * @param fis FileInputStream
	 * @param skip Number of bytes to skip
	 * @param len Number of bytes to read
	 * @param postskip Bytes to skip in the end of a string exclusive field_separator, which is always skipped
	 * @param fieldCodeExpected bytes denoting which field is supposed to be read. If there is no match an exception is thrown
	 * @return byte[] bytes read
	 */
	protected byte[] readBytes(FileInputStream fis, int skip, int len, int postskip, byte[] fieldCodeExpected)
		throws Exception
	{
	  byte[] bb = new byte[1];
		byte[] b = new byte[len];
		// Match expected field code
	  if (fieldCodeExpected == null || fieldCodeExpected.length==0) {
		  if (skip>0) fis.skip((long)skip);
		}
		if ((fis.read(b,0,len))!=-1) {
		  while (postskip>0) {
		    bb[0] = (byte)fis.read();
		    if (debug) System.out.println("skipping ["+(new String(bb)+"]"));
		    postskip--;
		  }
		  //System.out.println(new String(b));
			return b;
	} else
		  throw new Exception("Error reading bytes from stream");
	}

	/**
	 * Read bytes from stream until field terminator value or EOL
	 *
	 * A sideeffect is that qoutes are ignored
	 *
	 * @param fis FileInputStream
	 * @param skip Bytes to skip initially
	 * @param postskip Bytes to skip in the end of a string exclusive field_separator, which is always skipped
	 * @return byte[] bytes read
	 */
	protected byte[] readUntilFieldBytes(FileInputStream fis, int skip, int postskip, int toread)
		throws Exception
	{
		Vector v = new Vector();
		if (skip>0) fis.skip((long)skip);

		int i = fis.read();
		while (i!=-1 && i!=FT && i!=CR) {
		  toread--;
      v.addElement(i);
		  i = fis.read();
		}

    if (toread<0) {
      throw new Exception("L�ste flere bytes end forventet");
    }

		i = v.size()-postskip; if (i<0) i=0;
		byte[] b = new byte[i];
		for (i=0;i<(v.size()-postskip);i++) {
			b[i] = (byte)((Integer)v.elementAt(i)).intValue();
		}
    if (debug && b.length>0) System.out.print(new String(b));
		v.clear();
		return b;
	}

	/**
	 * Returns the byte representation of a string
	 *
	 * @param str The string
	 */
	protected byte[] getBytesFromString(String str)
		throws Exception
	{
		return str.getBytes("UTF-8");
	}

  /**
   * Linefeed reader
   *
   * If a given LF byte is'nt as expected an exception is thrown
   *
	 * @param fis FileInputStream
   */
  protected void readLinefeed(FileInputStream fis)
    throws Exception
  {
	  FileChannel fc = fis.getChannel();
	  byte[] b = readBytes(fis,0,1,0,null);
    if (b[0] != LF)
      throw new Exception("Linje terminering p� position "+fc.position()+" findes ikke, fandt "+b[0]);
    //message.addElement(b);
  }

	// Individual methods
  abstract void readFromFile(FileInputStream fis,FileOutputStream fos) throws Exception;
  public void writeToFile(FileOutputStream fos)
		throws Exception
	{
		//if (debug) System.out.println("+writeToFile elements="+message.size());
  	for (int i=0; i<message.size();i++) {
  	  byte[] b = new byte[1];
  	  if (message.elementAt(i) instanceof byte[])
			  b = ((byte[])message.elementAt(i));
  	  else if (message.elementAt(i) instanceof Byte)
  	    b[0] = ((Byte)message.elementAt(i)).byteValue();
  	  else
  	    throw new Exception("Unhandled object attempted to be written! "+(message.elementAt(i)));
			//if (debug) System.out.println(new String(b,"UTF-8"));
	    fos.write(b);
		  fos.flush();
		}
		message.clear();
		//if (debug) System.out.println("-writeToFile");
  }

  protected String makeTransaktionIdentifikator()
    throws Exception
  {
    UUID id = new UUID(13,13);
    return id.randomUUID().toString();
  }

  protected String makeTransaktionsTid()
    throws Exception
  {
    return "" + new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S'Z'").format(java.util.Calendar.getInstance().getTime());
  }
}