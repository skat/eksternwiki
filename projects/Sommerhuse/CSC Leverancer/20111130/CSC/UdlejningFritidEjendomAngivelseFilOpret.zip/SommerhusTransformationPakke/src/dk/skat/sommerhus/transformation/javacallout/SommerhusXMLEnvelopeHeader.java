package dk.skat.sommerhus.transformation.javacallout;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Vector;
import java.nio.channels.FileChannel;

/**
 * <p>Implements Sommerhusudlejning envelope header structure. Input is read from a filestream and written to a filestream</p>
 *
 * @author Ren� Hjortskov Nielsen, SKAT
 * @version 0.1
 */
public class SommerhusXMLEnvelopeHeader extends SommerhusXMLMessageBase implements SommerhusXMLMessageInterface
{

  /**
   * Constructor with variables used for create the start of the AKFA xml
   *
   * @param debug True if logging to system out should be supported
   */
	public SommerhusXMLEnvelopeHeader(boolean debug) {
		this.debug = debug;
	}

	/**
	 * <p>Produce envelope header<br>
	 */
  public void readFromFile(FileInputStream fis, FileOutputStream fos)
		throws Exception
	{
		if (debug) System.out.println("+SommerhusXMLEnvelopeHeader");
		// Reset message
		if (message!=null) { message.clear(); } else { message = new Vector(); }

	  message.addElement(getBytesFromString("<fase2.1:UdlejningFritidEjendomAngivelseFilOpret_I xmlns:fase2.1=\"http://skat.dk/begrebsmodel/2009/01/15/\" xmlns:ctxt=\"http://skat.dk/begrebsmodel/xml/schemas/kontekst/2007/05/31/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"));
    message.addElement(getBytesFromString("<fase2.1:Kontekst>"));
    message.addElement(getBytesFromString("<ctxt:HovedOplysninger>"));
    message.addElement(getBytesFromString("<ctxt:TransaktionIdentifikator>"));
    message.addElement(getBytesFromString(""+makeTransaktionIdentifikator()));
    message.addElement(getBytesFromString("</ctxt:TransaktionIdentifikator>"));
    message.addElement(getBytesFromString("<ctxt:TransaktionTid>"));
    message.addElement(getBytesFromString(""+makeTransaktionsTid()));
    message.addElement(getBytesFromString("</ctxt:TransaktionTid>"));
    message.addElement(getBytesFromString("</ctxt:HovedOplysninger>"));
    message.addElement(getBytesFromString("</fase2.1:Kontekst>"));
    message.addElement(getBytesFromString("<fase2.1:IndholdValg><fase2.1:MeddelelseIndhold><base64>"));

		if (debug) System.out.println("-SommerhusXMLEnvelopeHeader");
  }

}
