﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace PostFordelerLib
{
    class Fagsystem
    {
        private string mID;
        private string mmyndighed;
        private string mtitel;
        private string mrodmappe;
        private bool msletXML;
        private string moutputtif;

        public string rodmappe
        {
            get { return mrodmappe; }
            set { mrodmappe = value; }
        }
        public string myndighed
        {
            get { return mmyndighed; }
            set { mmyndighed = value; }
        }

        public string titel
        {
            get { return mtitel; }
            set { mtitel = value; }
        }
        
        public string ID
        {
            get { return mID; }
            set { mID = value; }
        }

        public bool sletXML
        {
            get { return msletXML; }
            set { msletXML = value; }
        }
        public string outputtif
        {
            get { return moutputtif; }
            set { moutputtif = value; }
        }

        public void Load(XmlNode n)
        {
            // n peger på en konkret <System> XML node

            myndighed = Common.GetAttributeValue(n, "myndighed", "", false);
            titel = Common.GetAttributeValue(n, "titel", "", false);
            ID = Common.GetAttributeValue(n, "id", "", true);
            rodmappe = Common.GetAttributeValue(n, "rodmappe", "", false);
            if (Common.GetAttributeValue(n, "sletXML", "Nej", false).ToUpper() == "JA") sletXML = true; else sletXML = false;
            outputtif = Common.GetAttributeValue(n, "outputtif", "", false);
        }
    }
}
