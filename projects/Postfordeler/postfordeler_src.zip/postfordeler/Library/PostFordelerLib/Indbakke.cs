﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;

namespace PostFordelerLib
{
    // Repræsenterer indbakken til programmet
    public class Indbakke
    {
        public const string UndermappeLog="Log";
        public const string UndermappeStat = "Stat";
        public const string UndermappeBehandlet = "Behandlet";
        public const string UndermappeOmplaceret = "Omplaceret";
        public const string UndermappeFejlet = "Fejlet";

        // den konfiguration, der skal køres på
        public Konfiguration InKonfiguration;

        // input: max. antal filer, der skal behandles
        // output: antal filer tilbage til behandling. 
        // Behandling afsluttet når denne egenskab er nul.
        public int InOutAntalFilerTilbage;

        // option
        public bool InKopierTilFagsystemmappe;
        
        // option
        public bool InRydOpIIndbakke;

        // option
        public bool InKopierTilBehandlet;

        // option
        public bool InGemStatistik;

        // option
        public DateTime InStatistikDatoFra=DateTime.MinValue;

        // option
        public DateTime InStatistikDatoTil=DateTime.MaxValue;

        // evt. fejltekst - null betyder ok.
        public string OutFejlTekst;

        // Disse bruges til statistik opsamling:
        public SortedList<string, string> OutModtagerAdresser;
        public SortedList<string, string> OutRoutninger;
        public SortedList<string, string> OutDokumenttyper;
        public SortedList<string, string> OutDatoer;

        public SortedList<string, int> OutAntalDatoDT;
        public SortedList<string, int> OutAntalDatoMA;
        public SortedList<string, int> OutAntalDatoRO;
        
        // Disse bruges til ONLINE statistik opsamling:
        public SortedList<string, int> OutAntalDTMA;
        public SortedList<string, int> OutAntalDTRO;
        public SortedList<string, int> OutAntalROMA;
        public SortedList<string, int> OutAntalDTMARO;

        // denne bruges til at danne output i grid i konsolen.
        // tab-separerede strenge - en for hver linie i griddet.
        public ArrayList OutLoglinier;

        // opdater online statistikopsamling med "en".
        private void OpdaterOnlineStatistik(Post p, Routning r)
        {
            if (this.OutModtagerAdresser != null)
            {
                // opdater statistik
                Common.SortedListAdd(this.OutModtagerAdresser, p.HentModtagerAdresse(), "");
                Common.SortedListAdd(this.OutRoutninger, r.ID, "");
                Common.SortedListAdd(OutDokumenttyper, p.HentDokumentType(), "");
                Common.SortedListIncrementCount(this.OutAntalDTMA, p.HentDokumentType() + "," + p.HentModtagerAdresse(),1);
                Common.SortedListIncrementCount(this.OutAntalDTRO, p.HentDokumentType() + "," + r.ID,1);
                Common.SortedListIncrementCount(this.OutAntalROMA, r.ID + "," + p.HentModtagerAdresse(),1);
                Common.SortedListIncrementCount(this.OutAntalDTMARO, p.HentDokumentType() + "," + p.HentModtagerAdresse() + "," + r.ID,1);
            }
        }


        // hovedfunktion
        // behandler et stykke post
        // bruges af omplacer post funktionen samt
        // af behandling af indbakke - se nedenfor
        public string BehandlPost(Konfiguration k, Post p, Routning r, bool blnOmplacering, out string fejl)
        {
            fejl = null;

            PostFordelerLib.Routning[] routningliste = null;

            // er routning givet?
            if (r == null)
            {
                // behandl post - find routninger
                routningliste = p.FindRoutninger();
            }
            else
            {
                // routning givet
                routningliste = new Routning[1];
                routningliste[0] = r;
            }

            //opsamling af de valgte routninger til logning
            string routningslog = null;

            // gennemgå routning en for en
            foreach (PostFordelerLib.Routning rr in routningliste)
            {
                // opbyg streng af routninger til brug for log
                routningslog += rr.ID + " ";

                // opdater statistik
                OpdaterOnlineStatistik(p, rr);

                // producer output XML
                PostFordelerLib.OutputXML o = new PostFordelerLib.OutputXML();
                o.Load(k, p, false);

                o.DanOutputXML(rr);

                // option - skal der kopieres til fagsystem?
                if (this.InKopierTilFagsystemmappe)
                {
                    if (!rr.sletXML) fejl=o.GemOutputXML(rr);
                    if (fejl == null)
                    {
                        fejl = p.KopierTIF(rr);
                    }
                }

                // hvis fejl i forbindelse med kopiering til fagsystem, undlad da at slette fra indbakke
                // ...men rapporter fejlen tilbage naturligvis.
                if (fejl != null) 
                {
                    return routningslog;
                }

                // gem input i "Behandlet\YYYYMMDD" eller "Omplaceret\YYYYMMDD" eller "Fejlet\YYYYMMDD" ?

                if (this.InKopierTilBehandlet) fejl=p.GemKopiAfInput(blnOmplacering);

                // ignorer fejl fra kopieret til "Behandlet", men rapporter fejlen (medmindre sletning fra indbakke også fejler!)

                string fejl2=null;
                // slet input fra indbakke?
                if (this.InRydOpIIndbakke) fejl2=p.SletInput();

                if (fejl2 != null) 
                {
                    fejl = fejl2;
                    return routningslog;
                }
                if (fejl != null) 
                {
                    return routningslog;
                }
            }
            return routningslog;
        }

        // central funktion
        // gennemgår indbakke og behandler alle de XML-filer, den kan finde der.
        // 
        public void BehandlIndbakke()
        {
            this.OutFejlTekst = null;

            // init. af statistikobjekter
            this.OutModtagerAdresser = new SortedList<string, string>();
            this.OutRoutninger = new SortedList<string, string>();
            this.OutDokumenttyper = new SortedList<string, string>();
            this.OutAntalDTMA = new SortedList<string, int>();
            this.OutAntalDTRO = new SortedList<string, int>();
            this.OutAntalROMA = new SortedList<string, int>();
            this.OutAntalDTMARO = new SortedList<string, int>();

            this.OutLoglinier = new ArrayList();

            Konfiguration k = this.InKonfiguration;

            // find input
            string[] inputfiler = null;
            try
            {
                inputfiler = Directory.GetFiles(k.indbakkeURL, "*.xml");
            }
            catch (Exception e)
            {
                this.InOutAntalFilerTilbage = 0;
                this.OutFejlTekst = e.Message;
                return;
            }

            // er der begrænsning på behandlingen?
            if (inputfiler.Length < this.InOutAntalFilerTilbage)
                this.InOutAntalFilerTilbage = inputfiler.Length;

            // index (1...)
            int index = 1;

            // behandl XML filerne en for en.
            foreach (string inputfil in inputfiler)
            {
                // spring temp filer over.
                if (Path.GetFileName(inputfil).StartsWith("~")) continue;

                // dan og load Post objekt
                PostFordelerLib.Post p = new PostFordelerLib.Post();
                string inputfejl = p.Load(inputfil, this.InKonfiguration);

                string routningslog = null;
                string outputfejl=null;
                // ingen fejl i input?
                if (inputfejl == null)
                {
                    // behandl post - herunder find routninger - derfor null
                    // returnerer liste af de fundne routninger
                    routningslog = BehandlPost(k, p, null, false, out outputfejl);
                }
                else
                {
                    // gem evt. kopi under "fejlet..."

                    if (this.InKopierTilBehandlet) p.GemKopiAfInput(false);
                }
                // dan linie til log
                string logfejl="OK";

                if (inputfejl != null)
                    logfejl = inputfejl;
                else
                    if (outputfejl != null)
                        logfejl = outputfejl;

                string l =
                    index.ToString() + "\t" +
                    logfejl + "\t" +
                    Path.GetFileName(inputfil) + "\t" +
                    Path.GetFileName(p.TIFURL) + "\t" +
                    p.HentDokumentType() + "\t" +
                    p.HentModtagerAdresse() + "\t" +
                    routningslog;
                index++;

                // placer i log

                this.OutLoglinier.Add(l);

                // opdater antallet af XML filer, der er tilbage i behandlingen
                this.InOutAntalFilerTilbage--;
                // færdig?
                if (this.InOutAntalFilerTilbage == 0) break;
            }

            // gem opsamlet statistik (OutAntalDTMARO) i stat. fil.
            if (this.InGemStatistik) GemStatistik(k);

            // gem log
            GemLog(k);

            this.InOutAntalFilerTilbage=0;
        }

        // gem log
        private void GemLog(Konfiguration k)
        {
            // gem fil med tid som navn
            DateTime tid = DateTime.Now;

            // placer under indbakke \Log
            string mappe = k.indbakkeURL + @"\" + UndermappeLog+ @"\" + tid.ToString("yyyyMMdd") + @"\";
            if (!Directory.Exists(mappe)) Directory.CreateDirectory(mappe);

            //// dan indhold af XML fil
            //string stat = "<?xml version='1.0' encoding='utf-8'?><Statistik tid='"+tid.ToString("HHmmss")+"'>";
            //foreach (string v in this.OutAntalDTMARO.Keys)
            //{
            //    stat += "<Linie nøgle='" + v + "' antal='" + this.OutAntalDTMARO[v] + "'/>";
            //}
            //stat += "</Statistik>";

            // gem resultat
            File.WriteAllLines(mappe + "Log-" + tid.ToString("HHmmss") + ".log", (string[])this.OutLoglinier.ToArray(mappe.GetType()));
        }


        // opsamling af statistik i baggrunden (på egen tråd)
        public void OpsamlStatistik()
        {
            // init. stat. objekter
            this.OutModtagerAdresser = new SortedList<string, string>();
            this.OutRoutninger = new SortedList<string, string>();
            this.OutDokumenttyper = new SortedList<string, string>();
            this.OutDatoer= new SortedList<string, string>();
            this.OutAntalDatoDT = new SortedList<string, int>();
            this.OutAntalDatoMA = new SortedList<string, int>();
            this.OutAntalDatoRO = new SortedList<string, int>();

            string URL = this.InKonfiguration.indbakkeURL;

            // find filer
            string[] filer;
            try
            {
                filer = Directory.GetFiles(URL + @"\" + PostFordelerLib.Indbakke.UndermappeStat, "Stat*.xml", SearchOption.AllDirectories);
            }
            catch (Exception)
            {
                return;
            }

            int index = 0;
            this.InOutAntalFilerTilbage = filer.Length;

            XmlDocument stat = new XmlDocument();

            foreach (string fil in filer)
            {
                index++;

                this.InOutAntalFilerTilbage--;

                stat.Load(fil);

                XmlNode n0=stat.SelectSingleNode("/Statistik");
                string datotekst = Common.GetAttributeValue(n0, "dato", null, false);

                // hvis vi ikke kan bestemme dato kan vi lige så godt springe filen over...
                if (datotekst == null) continue;
                
                if (!datotekst.Contains("-")) datotekst=datotekst.Substring(0,4)+"-"+datotekst.Substring(4,2)+"-"+datotekst.Substring(6,2);

                DateTime dato = DateTime.Parse(datotekst);

                if ((dato < this.InStatistikDatoFra) || (dato > this.InStatistikDatoTil)) continue;

                string datoNoegle = dato.ToString("yyyy-MM-dd");
                Common.SortedListAdd(this.OutDatoer, datoNoegle, "");

                foreach (XmlNode n in stat.SelectNodes("/Statistik/Linie"))
                {
                    int antal = int.Parse(Common.GetAttributeValue(n, "antal", null, true));
                    string DT = Common.GetAttributeValue(n, "dokumenttype", null, true);
                    string MA = Common.GetAttributeValue(n, "modtageradresse", null, true);
                    string RO = Common.GetAttributeValue(n, "routning", null, true);
                    Common.SortedListAdd(this.OutModtagerAdresser, MA, "");
                    Common.SortedListAdd(this.OutRoutninger, RO, "");
                    Common.SortedListAdd(this.OutDokumenttyper, DT, "");
                    Common.SortedListIncrementCount(this.OutAntalDatoDT, datoNoegle+ "," + DT, antal);
                    Common.SortedListIncrementCount(this.OutAntalDatoMA, datoNoegle + "," + MA, antal);
                    Common.SortedListIncrementCount(this.OutAntalDatoRO, datoNoegle + "," + RO, antal);
                }
                // færdig?
                if (this.InOutAntalFilerTilbage == 0) break;
            }
        }

        // gem opsamlet statistik (OutAntalDTMARO) i stat. fil.
        private void GemStatistik(Konfiguration k)
        {
            // gem fil med tid som navn
            DateTime tid = DateTime.Now;

            // placer under indbakke \Stat
            string mappe = k.indbakkeURL + @"\" + UndermappeStat+ @"\" + tid.ToString("yyyyMMdd") + @"\";
            if (!Directory.Exists(mappe)) Directory.CreateDirectory(mappe);

            // dan indhold af XML fil
            string stat = "<?xml version='1.0' encoding='utf-8'?>\r\n";
            stat += "<Statistik dato='" + tid.ToString("yyyy-MM-dd") + "' tid='" + tid.ToString("HH:mm:ss") + "'>";
            foreach (string v in this.OutAntalDTMARO.Keys)
            {
                string DT = v.Split(',')[0];
                string MA = v.Split(',')[1];
                string RO = v.Split(',')[2];

                stat += "<Linie dokumenttype='"+DT+
                    "' modtageradresse='"+MA+
                    "' routning='"+RO+"' antal='" + this.OutAntalDTMARO[v] + "'/>";
            }
            stat += "</Statistik>";

            // gem resultat
            File.WriteAllText(mappe + "Stat-" + tid.ToString("HHmmss") + ".xml", stat);
        }
    }
}
