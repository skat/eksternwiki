﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;
using System.Windows.Forms;

namespace PostFordelerLib
{

    public class Afstemning
    {
        private Konfiguration k;
        private XmlDocument konfigurationDocument;
        private string XmlRod;
        private string XmlUndermappe;

        // Intern struktur til differencelisten
        private string[] datarow = new string[4];

        private List<string> xmlInPostBehandlet;
        private List<string> xmlInPostUBehandletFuld;
        private List<string> xmlInPostFejlet;
        private List<string> xmlOutPostBehandletFejl = new List<string>();

        private DirectoryInfo fejlfordeltmappe;

        public Afstemning(Konfiguration k) 
        {
            this.k = k;

            konfigurationDocument = k.LoadStubKonfiguration();

            // Identificer den korrekte konfiguration
            XmlNode XmlAfstemning = k.LoadAfstemning();

            // Identificer rodmappe og navn til afstmningsmappe, lav afstemningsmapp, hvis den mangler
            XmlRod = (XmlAfstemning.Attributes.GetNamedItem("rodmappe")).Value;
            XmlUndermappe = (XmlAfstemning.Attributes.GetNamedItem("undermappe")).Value;
            if (!Directory.Exists(XmlRod + @"\" + XmlUndermappe))
                Directory.CreateDirectory(XmlRod + @"\" + XmlUndermappe);

            string path = GetPath("/PostFordelerKonfiguration/Systemer/System[@id='C og I']", "rodmappe");
            path += "/" + GetPath("/PostFordelerKonfiguration/Routninger/Routning[@id='FIL_MANUEL']", "undermappe");
            fejlfordeltmappe = new DirectoryInfo(path);
        }

        public string GetPath(string xmlPath, string attribute)
        {
            XmlNode n = Common.XPathSelect(konfigurationDocument, xmlPath);
            string mappe = (n.Attributes.GetNamedItem(attribute)).Value;
            return mappe;
        }

        // Finder filer recursivt af en bestemt type (extension)        
        private List<string> FindFiler(List<string> xmlFilPathListe, DirectoryInfo currentDir, string filType, int depth)
        {
            // Vi skal kigge på alle foldere under current mappen
            DirectoryInfo[] dirInfos = currentDir.GetDirectories();

            // Vi vil aldrig tælle FIL_MANUEL fejlfordelte filer!
            if (currentDir.FullName.Equals("" + fejlfordeltmappe.FullName))
                return xmlFilPathListe;

            // Processer hver mappe under current folderen
            for (int i = 0; depth>0&&i < dirInfos.Length; i++)
            {
                xmlFilPathListe = FindFiler(xmlFilPathListe, dirInfos[i], filType, depth-1);
            }

            // For hver folder finder vi filer af typen filType
            FileInfo[] fileInfos = currentDir.GetFiles(filType);
            for (int j = 0; j < fileInfos.Length; j++)
            {
                // Gem full sti til fil
                xmlFilPathListe.Add(fileInfos[j].FullName);
            }

            return xmlFilPathListe;
        }

        // Opretter dato.xml under Afstemningsmappen, såfremt der er tale om nyt dan afstemningsklik, ellers 
        // benyttes den eksisterende
        private StreamWriter sw;
        private StreamWriter FindAfstemningsFil(string dato, bool overwrite)
        {
            string mappeAfstemning = XmlRod + @"\" + XmlUndermappe;
            string filAfstemning = mappeAfstemning + @"\" + dato.Replace("-", "_") + @".xml";

            // Case: Vi vil tilføje data til eksisterende fil
            if (overwrite && File.Exists(filAfstemning)) File.Delete(filAfstemning);
            if (!File.Exists(filAfstemning))
            {
                sw = File.CreateText(filAfstemning);
                sw.AutoFlush = true;
            }
            else
            {
                // File.OpenText(filAfstemning);
                // Dette kan ikke ske
            }
            

            if (overwrite)
            {
                sw.WriteLine("<Modtaget dato=\""+dato+"\" />");
                sw.Flush();
            }

            return sw;
        }

        // tiff filer uden en xml fil ?

        // Xml filer med exDocID=tiff fil
        public int SagerUbehandletCI(string dato, DataGridView data)
        {
            StreamWriter sw = FindAfstemningsFil(dato, true);
            int sagCount = 0;
            // Directory for C og I med fejlfordelinger og skattecentrer
            DirectoryInfo dir = new DirectoryInfo(GetPath("/PostFordelerKonfiguration/Systemer/System[@id='C og I']","rodmappe"));
            
            List<string> xmlFilPathListe = FindFiler(new List<string>(), dir, "*.xml", 10);

            List<string> xmlFilPathListeFiltered = new List<string>();
            // For hver xml fil skal vi udsøge modtagetdato og SkanningsId
            sw.WriteLine("<InPostScan type=\"ubehandlet\" >");
            foreach (string xmlFil in xmlFilPathListe) 
            {
                // Load xml in i post object
                Post p = new Post();
                p.Load(xmlFil, k);

                // Hent modtager dato og skanningsId
                string modtagetdato = p.HentInformation(Post.postinfotype.modtagerdato);

                datarow[0] = xmlFil;
                datarow[1] = modtagetdato;
                datarow[2] = p.HentInformation(Post.postinfotype.scanningID);
                
/*
                // debug kan måske bruges til validering
                if (!modtagetdato.Equals("ukendt modtagerdato"))
                {
                    data.Rows.Add(datarow);
                }
 */
                
                // Bestem om der skal tælles
                string urlTiffFile = Path.GetFullPath(xmlFil) + @"\" + Path.GetFileName(xmlFil).Replace(".xml",".tif");
                if (dato.Equals(modtagetdato.Trim()) && File.Exists(urlTiffFile))
                {
                    xmlFilPathListeFiltered.Add(xmlFil);
                    sw.WriteLine("<SkanningsID xml=\"" + datarow[2] + "\" />");
                }
            }
            sw.WriteLine("</InPostScan>");

            sagCount = xmlFilPathListeFiltered.Count;
            return sagCount;
        }

        // xml filer med exDocID=tiff fil, hvor tiff filen mangler ?
        // SkanningsId overføres til afstemningsfil for indgående post
        public int SagerBehandletCI(string dato, DataGridView data)
        {
            StreamWriter sw = FindAfstemningsFil(dato, false);
            int sagCount = 0;
            // Directory for C og I med fejlfordelinger og skattecentrer
            DirectoryInfo dir = new DirectoryInfo(GetPath("/PostFordelerKonfiguration/Systemer/System[@id='C og I']", "rodmappe"));

            List<string> xmlFilPathListe = FindFiler(new List<string>(), dir, "*.xml",10);

            List<string> xmlFilPathListeFiltered = new List<string>();
            // For hver xml fil skal vi udsøge modtagetdato og exDocId (SkanningsId)
            sw.WriteLine("<InPostScan type=\"behandlet\" >");
            foreach (string xmlFil in xmlFilPathListe)
            {
                // Load xml in i post object
                Post p = new Post();
                p.Load(xmlFil, k);

                // Hent modtager dato og skanningsId
                string modtagetdato = p.HentInformation(Post.postinfotype.modtagerdato);

                datarow[0] = xmlFil;
                datarow[1] = modtagetdato;
                datarow[2] = p.HentInformation(Post.postinfotype.scanningID);

                // Bestem om der skal tælles
                string urlTiffFile = Path.GetFullPath(xmlFil) + @"\" + Path.GetFileName(xmlFil).Replace(".xml", ".tif");
                if (dato.Equals(modtagetdato.Trim()) && !File.Exists(urlTiffFile))
                {
                    xmlFilPathListeFiltered.Add(xmlFil);
                    sw.WriteLine("<SkanningsID xml=\"" + datarow[2] + "\" />");
                }
            }
            sw.WriteLine("</InPostScan>");

            // Gem denne struktur som sammenligningsgrundlag for behandlet post
            xmlInPostBehandlet = xmlFilPathListeFiltered;

            sagCount = xmlFilPathListeFiltered.Count;
            return sagCount;
        }

        // xml filer i CLASSIFY_INDEX (HOVED) mappen, med tilhørende tiff fil, som også eksisterer
        public int SagerUbehandletPostFordeler(string dato, DataGridView data)
        {
            StreamWriter sw = FindAfstemningsFil(dato, false);
            int sagCount = 0;
            // Directory for PostFordeler
            DirectoryInfo dir = new DirectoryInfo(GetPath("/PostFordelerKonfiguration/Indbakker/Indbakke[@id='Hoved']", "mappe"));

            List<string> xmlFilPathListe = FindFiler(new List<string>(), dir, "*.xml", 0);
            xmlInPostUBehandletFuld = xmlFilPathListe;

            List<string> xmlFilPathListeFiltered = new List<string>();
            // For hver xml fil skal vi udsøge modtagetdato og exDocId (SkanningsId)
            sw.WriteLine("<OutPostScan type=\"ubehandlet\" >");
            foreach (string xmlFil in xmlFilPathListe)
            {
                // Load xml in i post object
                Post p = new Post();
                p.Load(xmlFil, k);

                // Hent modtager dato og skanningsId
                string modtagetdato = p.HentInformation(Post.postinfotype.modtagerdato);

                datarow[0] = xmlFil;
                datarow[1] = modtagetdato;
                datarow[2] = p.HentInformation(Post.postinfotype.scanningID);

                // Bestem om der skal tælles
                string urlTiffFile = Path.GetFullPath(xmlFil) + @"\" + Path.GetFileName(xmlFil).Replace(".xml", ".tif");
                if (dato.Equals(modtagetdato.Trim()) && File.Exists(urlTiffFile))
                {
                    xmlFilPathListeFiltered.Add(xmlFil);
                    sw.WriteLine("<SkanningsID xml=\"" + datarow[2] + "\" />");
                }
            }
            sw.WriteLine("</OutPostScan>");

            sagCount = xmlFilPathListeFiltered.Count;

            return sagCount;
        }

        public int SagerFejlbehandletPostFordeler(string dato, DataGridView data)
        {
            StreamWriter sw = FindAfstemningsFil(dato, false);
            int sagCount = 0;
            // Directory for C og I med fejlfordelinger og skattecentrer
            string path = GetPath("/PostFordelerKonfiguration/Systemer/System[@id='C og I']", "rodmappe");
            path += "/" + GetPath("/PostFordelerKonfiguration/Routninger/Routning[@id='FIL_MANUEL']", "undermappe");
            DirectoryInfo dir = new DirectoryInfo(path);

            List<string> xmlFilPathListe = FindFiler(new List<string>(), dir, "*.xml", 10);

            List<string> xmlFilPathListeFiltered = new List<string>();
            // For hver xml fil skal vi udsøge modtagetdato og exDocId (SkanningsId)
            sw.WriteLine("<OutPostScan type=\"fejlet\" >");
            foreach (string xmlFil in xmlFilPathListe)
            {
                // Load xml in i post object
                Post p = new Post();
                p.Load(xmlFil, k);

                // Hent modtager dato og skanningsId
                string modtagetdato = p.HentInformation(Post.postinfotype.modtagerdato);

                datarow[0] = xmlFil;
                datarow[1] = modtagetdato;
                datarow[2] = p.HentInformation(Post.postinfotype.scanningID);

                // Bestem om der skal tælles
                if (dato.Equals(modtagetdato.Trim()))
                {
                    xmlFilPathListeFiltered.Add(xmlFil);
                    sw.WriteLine("<SkanningsID xml=\"" + datarow[2] + "\" />");
                }
            }
            sw.WriteLine("</OutPostScan>");

            // Gem denne struktur som sammenligningsgrundlag for behandlet post
            xmlInPostFejlet = xmlFilPathListeFiltered;

            sagCount = xmlFilPathListeFiltered.Count;
            return sagCount;
        }


        // xml filer undermappe Behandlet til CLASSIFY_INDEX (HOVED) mappen, medtilhørende tiff fil, som også eksisterer
        // SkanningsId overføres til afstemningsfil for udgående post
        public int SagerBehandletPostFordeler(string dato, DataGridView data)
        {
            StreamWriter sw = FindAfstemningsFil(dato, false);
            int sagCount = 0;
            // Directory for PostFordeler
            DirectoryInfo dir = new DirectoryInfo(GetPath("/PostFordelerKonfiguration/Indbakker/Indbakke[@id='Hoved']", "mappe") + @"/" + "Behandlet");

            List<string> xmlFilPathListe = FindFiler(new List<string>(), dir, "*.xml", 10);

            List<string> xmlFilPathListeFiltered = new List<string>();
            // For hver xml fil skal vi udsøge modtagetdato og exDocId (SkanningsId)
            sw.WriteLine("<OutPostScan type=\"behandlet\" >");
            foreach (string xmlFil in xmlFilPathListe)
            {
                // Load xml in i post object
                Post p = new Post();
                p.Load(xmlFil, k);

                // Hent modtager dato og skanningsId
                string modtagetdato = p.HentInformation(Post.postinfotype.modtagerdato);

                datarow[0] = xmlFil;
                datarow[1] = modtagetdato;
                datarow[2] = p.HentInformation(Post.postinfotype.scanningID);

                // Bestem om der skal tælles
                string urlTiffFile = Path.GetFullPath(xmlFil) + @"\" + Path.GetFileName(xmlFil).Replace(".xml", ".tif");
                if (dato.Equals(modtagetdato.Trim()))
                {
                    if (File.Exists(urlTiffFile))
                    {
                        xmlFilPathListeFiltered.Add(xmlFil);
                        sw.WriteLine("<SkanningsID xml=\"" + datarow[2] + "\" />");

                        for (int i = 0; i < xmlInPostBehandlet.Count; i++)
                        {
                            if (xmlInPostBehandlet.ElementAt(i).EndsWith(Path.GetFileName(xmlFil)))
                                xmlInPostBehandlet.RemoveAt(i);
                        }
                    }
                    else
                    {
                        // Tilføj dette til fejliste
                        xmlOutPostBehandletFejl.Add(xmlFil);
                    }
                }
            }
            sw.WriteLine("</OutPostScan>");

            // Opdater differencelisten med de beskeder som udestår som behandlet af postfordeleren
            for (int i = 0; i < xmlInPostBehandlet.Count; i++)
            {
                datarow[0] = dato;
                datarow[1] = xmlInPostBehandlet.ElementAt(i);
                datarow[2] = "Sag endnu ikke fordelt";

                // Load xml in i post object
                Post p = new Post();
                p.Load(xmlInPostBehandlet.ElementAt(i), k);
                // Hent skanningsId                
                datarow[3] = p.HentInformation(Post.postinfotype.scanningID);

                data.Rows.Add(datarow);
            }

            for (int i = 0; i < xmlOutPostBehandletFejl.Count; i++)
            {
                datarow[0] = dato;
                datarow[1] = xmlOutPostBehandletFejl.ElementAt(i);
                datarow[2] = "Fordelt sag mangler tiff";

                // Load xml in i post object
                Post p = new Post();
                p.Load(xmlInPostBehandlet.ElementAt(i), k);
                // Hent skanningsId                
                datarow[3] = p.HentInformation(Post.postinfotype.scanningID);

                data.Rows.Add(datarow);
            }

            // Hvis en behandlet postfordeler sag er fundet i postfordeler indbakke, så rapporteres 
            for (int i = 0; i < xmlInPostBehandlet.Count; i++)
            {
                datarow[0] = dato;
                datarow[1] = xmlInPostBehandlet.ElementAt(i);
                datarow[2] = "Fordelt sag er ikke ryddet op";

                // Load xml in i post object
                Post p = new Post();
                p.Load(xmlInPostBehandlet.ElementAt(i), k);
                // Hent skanningsId                
                datarow[3] = p.HentInformation(Post.postinfotype.scanningID);
                
                for (int j=0; j<xmlInPostUBehandletFuld.Count; j++)
                    if (xmlInPostUBehandletFuld.ElementAt(j).Equals(xmlInPostBehandlet.ElementAt(i)))
                        data.Rows.Add(datarow);
            }

            // Rapporter fejlet postsager 
            for (int i = 0; i < xmlInPostFejlet.Count; i++)
            {
                datarow[0] = dato;
                datarow[1] = xmlInPostFejlet.ElementAt(i);
                datarow[2] = "Fordelt sag er fejlet";

                // Load xml in i post object
                Post p = new Post();
                p.Load(xmlInPostBehandlet.ElementAt(i), k);
                // Hent skanningsId                
                datarow[3] = p.HentInformation(Post.postinfotype.scanningID);

                data.Rows.Add(datarow);

                datarow[2] = "Fejlet sag ikke ryddet op";
                for (int j = 0; j < xmlInPostUBehandletFuld.Count; j++)
                    if (xmlInPostUBehandletFuld.ElementAt(j).Equals(xmlInPostFejlet.ElementAt(i)))
                        data.Rows.Add(datarow);

            }
            

            sagCount = xmlFilPathListeFiltered.Count;
            return sagCount;
        }

        public void finish()
        {
            sw.Close();
        }
    }
}
