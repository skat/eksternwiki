﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;

/*
 * Ændringer:
 * 
 * Post objectet er udvidet med muligheden for at sende fejlfordelt post tilbage til C&I. Dette betyder, at
 * XML'en skal rettes således at C_I_dokumenttype´elementet fjernes før posten omfordeles.
 */
namespace PostFordelerLib
{
    // repræsenterer et stykke post (input XML og TIF fil)
    public class Post
    {
        // Combobox teksten. Bruges til at smage på om xml skal kopieres til fejlbehandlet
        private string valgtRoutning;

        // xml objekt for den XML fil der skal behandles
        private XmlDocument xmlP;

        // konfiguration
        private Konfiguration mk;

        // de forskellige informationselementer, man kan få ud af XML filen
        // vigtigst er modtageradresse, dokumenttype og akttype 
        public enum postinfotype
        {            
            // routbare
            modtageradresse,    // streng
            dokumenttype,       // streng 
            akttype,            // streng => akttype

            // information - kopieres over i captia dokumentets følgeseddel når der routes til captia
            modtagerdato,       // dd-mm-yyyy
            afsenderadresse,    // streng
            medie,              // streng => medietype
            originalreturneres, // JA/NEJ
            modtagetfysisk,     // JA/NEJ
            genscanning,        // JA/NEJ
            scanningID,         // streng
            indscanpers,        // streng
            indscantid,         // ?
            indscanside,        // heltal
            oprindelse,         // streng
            opretbruger         // streng
        }

        // mulige medietyper
        public enum medietype
        {
            DE,
            E
        }

        // mulige akttyper
        public enum akttype
        {
            værdipost, //"V"
            almindeligpost //"I"
        }

        // container til informationer fra input XML
        private SortedList<postinfotype, string> postinformationer;

        // 
        public string HentInformation(postinfotype pit)
        {
            // check container først!
            if (postinformationer.ContainsKey(pit)) return postinformationer[pit];

            // opslag i input XML
            string xpathudtryk = null;
            string s;
            switch (pit)
            {
                case postinfotype.afsenderadresse:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:field[@name='Afsenderopl']";
                    break;
                case postinfotype.modtageradresse:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:field[@name='Modtageropl']";
                    break;
                case postinfotype.dokumenttype:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/C_I_dokumenttype";
                    break;
                case postinfotype.modtagerdato:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:group[@name='dato']/sj:field[@name='dato']";
                    break;
                case postinfotype.akttype:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:field[@name='akttype']";
                    break;
                case postinfotype.medie:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:field[@name='medie']";
                    break;
                case postinfotype.originalreturneres:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:group/sj:field[@name='ledetxt'][.='Dok_Returne']/../sj:field[@name='opl']";
                    break;
                case postinfotype.modtagetfysisk:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:group/sj:field[@name='ledetxt'][.='Modtaget fysisk']/../sj:field[@name='opl']";
                    break;
                case postinfotype.genscanning:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:group/sj:field[@name='ledetxt'][.='Genskanning']/../sj:field[@name='opl']";
                    break;
                case postinfotype.scanningID:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:group/sj:field[@name='ledetxt'][.='Skannings-Id']/../sj:field[@name='opl']";
                    //xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:group/sj:field[@name='ledetxt'][.='Skannings-Id']/../sj:field[@name='opl']";
                    break;
                case postinfotype.indscanpers:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:group/sj:field[@name='ledetxt'][.='IndScanPers']/../sj:field[@name='opl']";
                    //xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:field[@name='IndScanPers']";
                    break;
                case postinfotype.indscantid:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:group/sj:field[@name='ledetxt'][.='IndScanTid']/../sj:field[@name='opl']";
                    //xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:field[@name='IndScanTid']";
                    break;
                case postinfotype.indscanside:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:group/sj:field[@name='ledetxt'][.='IndScanSide']/../sj:field[@name='opl']";
                    //xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:field[@name='IndScanSide']";
                    break;
                case postinfotype.oprindelse:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:field[@name='oprindelse']";
                    break;
                case postinfotype.opretbruger:
                    xpathudtryk = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/sj:metadata/sj:field[@name='opretbruger']";
                    break;
            }

            // hvis ikke fundet eller ved fejl, sæt til "ukendt" dit og dat.
            try
            {
                XmlNode n = Common.XPathSelect(xmlP, xpathudtryk);
                if (n != null)
                    s = n.InnerText.Trim();
                else
                    s = "ukendt " + pit.ToString();

                postinformationer.Add(pit, s);
                return s;
            }
            catch (Exception)
            {
                s = "ukendt " + pit.ToString();
                postinformationer.Add(pit, s);
                return s;
            }
        }

        // hent akttype - hvis ikke sat, sæt til "almindelig"
        public akttype HentAktType()
        {
            string s=HentInformation(postinfotype.modtageradresse);
            if (s.Trim() == "V")
                return akttype.værdipost;
            else
                return akttype.almindeligpost;
        }

        // hent modtageradresse (simpel overbygning på generel funktion)
        public string HentModtagerAdresse()
        {
            return HentInformation(postinfotype.modtageradresse);
        }

        // hent dokumenttype (simpel overbygning på generel funktion)
        // TODO NB Bemærk "hack" med at sætte "/" bagpå
        // skyldes at konfiguration (fra SKAT) er uden "/"
        // mens opsætning til C&I (fra SKAT) er med "/" (!)
        public string HentDokumentType()
        {
            return HentInformation(postinfotype.dokumenttype)+"/";
            
        }

        // fuld sti til input XML
        private string mXMLURL;

        // fuld sti til input TIF fil
        private string mTIFURL = "";

        public string TIFURL
        {
            get { return mTIFURL; }
        }

        public string XMLURL
        {
            get { return mXMLURL; }
        }

        private string mFejlTekst = null;

        public string FejlTekst
        {
            get { return mFejlTekst; }
        }

        // Overloaded for at holde resten af Load kaldene intakte
        public string Load(string URL, Konfiguration k)
        {
            return Load(URL, k, "");
        }

        // loader post objekt fra input XML fil og checker om XML skal modificeres
        public string Load(string URL, Konfiguration k, string valgtRoutning)
        {
            this.valgtRoutning = valgtRoutning;
            // opret container til information, der er trukket ud af input XML filen
            postinformationer = new SortedList<postinfotype, string>();

            mTIFURL = null;
            mXMLURL = URL;
            mFejlTekst = null;

            // gem konfiguration til senere.
            mk = k;

            // Kontroller om vi står med en særlig routning som skal modificeres indholdet før det flyttes
            if (valgtRoutning.Equals("FIL_MANUEL"))
            {                
                // Remove documenttype from XML
                // dokumenttypeXPathRef = "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/C_I_dokumenttype";
                xmlP = new XmlDocument();

                // hent henvisning til TIF fil i XML-filen
                try
                {
                    xmlP.Load(mXMLURL);
                }
                catch (Exception)
                {
                    mFejlTekst = "ikke velformet";
                    return mFejlTekst;
                }

                XmlNodeList nl = xmlP.GetElementsByTagName("C_I_dokumenttype");
                if (nl.Count == 0)
                {
                    mFejlTekst = "fandt ikke elementet C_I_dokumenttype";
                    return mFejlTekst;
                }

                try
                {
                    for (int i = 0; i < nl.Count; i++)
                    {
                        XmlNode n = nl.Item(i);
                        n.ParentNode.RemoveChild(n);
                        xmlP.Save(mXMLURL);
                    }
                }
                catch (System.Xml.XmlException e)
                {
                    mFejlTekst = "fejl ved fjernelse af C_I_dokumenttype";
                    return mFejlTekst;
                }
            }

            xmlP = new XmlDocument();

            // hent henvisning til TIF fil i XML-filen
            try
            {
                xmlP.Load(mXMLURL);
            }
            catch (Exception)
            {
                mFejlTekst= "ikke velformet";
                return mFejlTekst;
            }
            try
            {
                XmlNode n = Common.XPathSelect(xmlP, "/sj:SJ_FESDpacket/sj:SJ_FESDPacketPart/fesd:Document/@exDocID");
                if (n != null)
                    mTIFURL = Common.GetPath(mXMLURL) + @"\" + n.Value;
                else
                {
                    mFejlTekst = "Kan ikke finde henvisning til TIF";
                    return mFejlTekst;
                }
            }
            catch (Exception)
            {
                mFejlTekst = "Kan ikke finde henvisning til TIF";
                return mFejlTekst;
            }
            if (!File.Exists(mTIFURL))
            {
                mFejlTekst = "TIF fil findes ikke";
                return mFejlTekst;
            }
            return null;
        }

        // find routninger ved at benytte konfigurationsobjektet
        public Routning[] FindRoutninger()
        {
            return mk.BestemRoutninger(HentModtagerAdresse(), HentDokumentType(), HentAktType());
        }

        // fastlæg output TIF fil navn 
        // skal det manipuleres?
        public string BestemtOutputTIF(Routning r)
        {
            // check for om output navn skal manipuleres!
            string outputTIF = null;

            // opdater filnavn, hvis routningen stiller krav herom
            if (r.outputtif != "")
            {
                outputTIF = r.outputtif;
                outputTIF = outputTIF.Replace("$ma$", this.HentModtagerAdresse()).Replace("$dt$", this.HentDokumentType()).Replace("$id$", Path.GetFileNameWithoutExtension(mXMLURL));
                outputTIF = outputTIF.Replace("/", "");
            }
            else
            {
                // ellers brug navnet der er kendt i forvejen.
                outputTIF = Path.GetFileName(mTIFURL);
            }
            return outputTIF;
        }

        // hold styr på om vi har kopieret eller ej...
        private bool mKopieretTIF = false;

        // kopier TIF til fagsystem mappe
        // Særligt for FIL_MANUEL skal xml også kopieres
        // FIL_NANUEL skal også gemme i mappe med navn = skanningsId
        public string KopierTIF(Routning r)
        {
            string mappeFilManuel = "";
            // Konstruer mappenavn
            if (valgtRoutning.Equals("FIL_MANUEL")) 
            {
                mappeFilManuel = Path.GetFileName(mXMLURL);
                int idx = mappeFilManuel.LastIndexOf('.');
                if (idx > 0)
                {
                    mappeFilManuel = mappeFilManuel.Substring(0, idx);
                    if (!Directory.Exists(r.mappe + @"\" + mappeFilManuel))
                        Directory.CreateDirectory(r.mappe + @"\" + mappeFilManuel);
                }
            }

            try
            {
                File.Copy(mTIFURL, r.mappe + @"\" + mappeFilManuel + @"\" + this.BestemtOutputTIF(r));
                mKopieretTIF = true;
            }
            catch (Exception e)
            {
                mKopieretTIF = false;
                return e.Message;
            }

            if (valgtRoutning.Equals("FIL_MANUEL")) 
            {
                try
                {
                    File.Copy(mXMLURL, r.mappe + @"\" + mappeFilManuel + @"\" + Path.GetFileName(mXMLURL));
                }
                catch (Exception e)
                {
                    mKopieretTIF = false;
                    return e.Message;
                }
            }
            return null;
        }

        // slet input XML fil og input TIF Fil
        // (sikkert efter at vi har kopieret den...)
        // check status flag før vi sletter....(!)
        public string SletInput()
        {
            if (mGemtInputXML)
            {
                try
                {
                    File.Delete(mXMLURL);
                }
                catch (Exception e)
                {
                    return e.Message;
                }
            }
            if (mKopieretTIF)
            {
                try
                {
                    File.Delete(mTIFURL);
                }
                catch (Exception e)
                {
                    return e.Message;
                }
            }
            return null;
        }

        private bool mGemtInputXML=false;

        // gem input, dvs. kopier fra indbakke til "Behandlet" undermappe
        public string GemKopiAfInput(bool blnOmplacering)
        {
            string mappe;
            string undermappe;
            if (mFejlTekst != null)
            {
                undermappe = Indbakke.UndermappeFejlet;
            }
            else
            {
                if (blnOmplacering)
                    undermappe = Indbakke.UndermappeOmplaceret;
                else
                    undermappe = Indbakke.UndermappeBehandlet;
            }

            mappe = mk.indbakkeURL + @"\" + undermappe + @"\" + DateTime.Now.ToString("yyyyMMdd") + @"\";
            
            if (!Directory.Exists(mappe)) Directory.CreateDirectory(mappe);

            // undertryk fejlrapport
            try
            {
                File.Copy(mXMLURL, mappe + Path.GetFileName(mXMLURL));
                mGemtInputXML = true;
            }
            catch (Exception)
            {
                mGemtInputXML = false;
                return null;
            }

            // undertryk fejl rapport
            try
            {
                File.Copy(mTIFURL, mappe + Path.GetFileName(mTIFURL));
                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
