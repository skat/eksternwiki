﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;

namespace PostFordelerLib
{

    // Contains simple enhancements for .net functions
    public class Common
    {
        public static string GetAttributeValue(XmlNode n, string name, string defaultvalue, bool mandatory)
        {
            XmlNode a = n.Attributes.GetNamedItem(name);
            if ((a == null) && mandatory) throw new Exception("Fejl - opslag i XML dokument fejler. Attribut: " + name + " mangler! (node er "+ n.Name+")");
            if (a == null) return defaultvalue;
            return a.Value.Trim();
        }

        private static void XPathCommon(XmlNode n, XmlDocument k, string xpathudtryk, out XmlNamespaceManager nsmgr)
        {
            if (n != null)
                nsmgr = new XmlNamespaceManager(n.OwnerDocument.NameTable);
            else
                nsmgr = new XmlNamespaceManager(k.NameTable);
            nsmgr.AddNamespace("sj", "http://rep.oio.dk/scanjour.dk/xml/schemas/2004/");
            nsmgr.AddNamespace("dc", "http://purl.org/dc/elements/1.1/");
            nsmgr.AddNamespace("dkfm", "http://rep.oio.dk/dkfm.dk/xml/schemas/2002/07/");
            nsmgr.AddNamespace("fesd", "http://rep.oio.dk/fesd.dk/xml/schemas/2004/05/");
        }

        public static XmlNode XPathSelect(XmlDocument k, string xpathudtryk)
        {
            XmlNamespaceManager nsmgr = null;
            XPathCommon(null, k, xpathudtryk, out nsmgr);
            nsmgr.AddNamespace("sj", "http://rep.oio.dk/scanjour.dk/xml/schemas/2004/");
            nsmgr.AddNamespace("dc", "http://purl.org/dc/elements/1.1/");
            nsmgr.AddNamespace("dkfm", "http://rep.oio.dk/dkfm.dk/xml/schemas/2002/07/");
            nsmgr.AddNamespace("fesd", "http://rep.oio.dk/fesd.dk/xml/schemas/2004/05/");
            return k.SelectSingleNode(xpathudtryk, nsmgr);
        }

        public static XmlNodeList XPathMultiSelect(XmlNode k, string xpathudtryk)
        {
            XmlNamespaceManager nsmgr = null;
            XPathCommon(k, null, xpathudtryk, out nsmgr);
            nsmgr.AddNamespace("sj", "http://rep.oio.dk/scanjour.dk/xml/schemas/2004/");
            nsmgr.AddNamespace("dc", "http://purl.org/dc/elements/1.1/");
            nsmgr.AddNamespace("dkfm", "http://rep.oio.dk/dkfm.dk/xml/schemas/2002/07/");
            nsmgr.AddNamespace("fesd", "http://rep.oio.dk/fesd.dk/xml/schemas/2004/05/");
            return k.SelectNodes(xpathudtryk, nsmgr);
        }

        public static XmlNodeList XPathMultiSelect(XmlDocument k, string xpathudtryk)
        {
            XmlNamespaceManager nsmgr = null;
            XPathCommon(null, k, xpathudtryk, out nsmgr);
            nsmgr.AddNamespace("sj", "http://rep.oio.dk/scanjour.dk/xml/schemas/2004/");
            nsmgr.AddNamespace("dc", "http://purl.org/dc/elements/1.1/");
            nsmgr.AddNamespace("dkfm", "http://rep.oio.dk/dkfm.dk/xml/schemas/2002/07/");
            nsmgr.AddNamespace("fesd", "http://rep.oio.dk/fesd.dk/xml/schemas/2004/05/");
            return k.SelectNodes(xpathudtryk, nsmgr);
        }

        public static XmlNode XPathSelect(XmlNode n, string xpathudtryk)
        {
            XmlNamespaceManager nsmgr = null;
            XPathCommon(n, null, xpathudtryk, out nsmgr);
            nsmgr.AddNamespace("sj", "http://rep.oio.dk/scanjour.dk/xml/schemas/2004/");
            nsmgr.AddNamespace("dc", "http://purl.org/dc/elements/1.1/");
            nsmgr.AddNamespace("dkfm", "http://rep.oio.dk/dkfm.dk/xml/schemas/2002/07/");
            nsmgr.AddNamespace("fesd", "http://rep.oio.dk/fesd.dk/xml/schemas/2004/05/");
            return n.SelectSingleNode(xpathudtryk, nsmgr);
        }

        // URL = path+file+extension
        // returns path
        public static string GetPath(string URL)
        {
            return URL.Replace(Path.GetFileName(URL), "");
        }

        public static void SortedListAdd(SortedList<string, string> l, string name, string value)
        {
            if (l.ContainsKey(name)) return;
            l.Add(name, value);
        }
        public static void SortedListIncrementCount(SortedList<string, int> l, string name, int increment)
        {
            if (!l.ContainsKey(name))
            {
                l.Add(name, increment);
            }
            else
            {
                int i = l[name];
                i += increment;
                l.Remove(name);
                l.Add(name, i);
            }
        }
    }
}
