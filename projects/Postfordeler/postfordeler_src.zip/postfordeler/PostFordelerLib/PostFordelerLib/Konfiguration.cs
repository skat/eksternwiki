﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace PostFordelerLib
{
    //JTJ: Denne klasser er temmelig uklar i ansvarsområdet. Især BestemRoutning ligger udenfor.
    //     Desuden bør klassen ikke bare være en wrapper om et xml-dok, da det betyder at indhold ikke valideres.
    //     Fejlhåndteringen er elendig.

    /// <summary>
    ///indpakning af XML konfigurationsfil.
    ///TODO GUI delen tager sig hvad angår visning af konfiguration visse friheder 
    ///idet denne går direkte i XML'en når der mangler en funktion her i klassen. 
    /// overvej at lukke det hul på sigt...
    /// </summary>
    public class Konfiguration
    {
        // loader fra stub, der peger videre på den "rigtige" konfiguration
        private const string xmlKonfiguration = @"PostFordelerKonfigurationStub$miljø$.xml";

        // pegepind til XML knude der peger på den valgte indbakke.
        public XmlNode XmlIndbakke;

        private XmlDocument k;

        // Test eller Prod
        private string mMiljoe;

        public Konfiguration(string miljoe)
        {
            mMiljoe = miljoe;
        }

        public XmlDocument LoadStubKonfiguration()
        {
            if (k == null)
            {
                //JTJ dette er helt omlagt så der bruges app.config i stedet for stubbe
                //    Der bruges KonfigurationTest eller KonfigurationProduktion settings
                //    fx: <add key="KonfigurationTest" value="c:\Test.xml"/>

                // load den rigtige konfiguration
                k = new XmlDocument();
                k.Load(System.Configuration.ConfigurationManager.AppSettings["Konfiguration" + mMiljoe]);
                return k;
            }
            else
                return k;
        }

        public void Load(string indbakke)
        {
            LoadStubKonfiguration();

            // find indbakke i konfigurationsfilen
            if (indbakke!=null)
                XmlIndbakke = Common.XPathSelect(k, "/PostFordelerKonfiguration/Indbakker/Indbakke[@id='" + indbakke + "']");

            // nulstil cache over routninger!
            routningcache = new SortedList<string, Routning[]>();
        }

        // Returnerer pegepind til XML knude der peger på applikationsrod
        public XmlNode LoadAfstemning()
        {
            LoadStubKonfiguration();

            // Tilføjet læsning af Afstemningsfolder
            return Common.XPathSelect(k, "/PostFordelerKonfiguration/Afstemning[@id='Afstemning']");
        }

        // cache over routninger!
        private SortedList<string, Routning[]> routningcache;

        // central funktion!
        // bestemmer routninger ud fra modtageradresse, dokumenttype samt akttype
        // slå routninger op i konfiguration
        // special regel: 
        // hvis akttype er værdipost, rout' da 
        // både til den "almindelige" routning og til routning="værdipost"
        public Routning[] BestemRoutninger(
            string modtageradresse, 
            string dokumenttype, 
            Post.akttype at)
        {
            // cachenøgle konstrueres og checkes mod cache!
            string cachenoegle=modtageradresse+"@"+dokumenttype;
            if (routningcache.ContainsKey(cachenoegle)) return routningcache[cachenoegle];

            string routning=null;
            XmlNode routningNode = null; //kan være enten en regel eller en routning

            // find specifik routning
            //  - routningNode er en XML-attribut som indeholder et navn på en routning!
            //match modtageradresse OG dokumenttype
            routningNode = Common.XPathSelect(XmlIndbakke, "Regel[@modtageradresse='" + modtageradresse + "'][@dokumenttype='" + dokumenttype + "']/@routning");

            if (routningNode == null)
            {
                // ...prøv routning med modtager adresse *
                //match modtageradresse * OG dokumenttype
                routningNode = Common.XPathSelect(XmlIndbakke, "Regel[@modtageradresse='*'][@dokumenttype='" + dokumenttype + "']/@routning");
            }
            if (routningNode == null)
            {
               //match modtageradresse OG dokumenttype *
                routningNode = Common.XPathSelect(XmlIndbakke, "Regel[@modtageradresse='" + modtageradresse + "'][@dokumenttype='*']/@routning");
            }
            // ...prøv med dokumenttype = routning
            if (routningNode == null)
            {
                // match dokumenttype = routning
                // lidt mærkeligt, ja, men det bruges hvis scanningsmedarbejder ønsker at overstyre
                // dokumenttypebestemmelse og route direkte
                routningNode = Common.XPathSelect(XmlIndbakke.OwnerDocument,
                    "/PostFordelerKonfiguration/Routninger/Routning/@id[.='" + dokumenttype + "']"); 
                //JTJ: rettet fejl her - der blev søgt på modtageradresse, og Routning-node blev returneret.
                //     rettet til dokumenttype og returnerer nu id-node forudsat at routning eksisterer
            }
            if (routningNode == null)
            {
                // check modtageradresse mod konfiguration - er det overhovedet en gyldig adresse?

                XmlNode n = Common.XPathSelect(XmlIndbakke.OwnerDocument,
                    "/PostFordelerKonfiguration/ModtagerAdresser/Adresse[@id='" + modtageradresse + "']");
                if (n == null)
                    routning = "ukendt-modtageradresse";
                else
                {
                    // check dokumenttype mod konfiguration - er det overhovedet en gyldig dokumenttype?

                    n = Common.XPathSelect(XmlIndbakke.OwnerDocument,
                    "/PostFordelerKonfiguration/DokumentTyper/DokumentType[@id='" + dokumenttype + "']");
                    if (n == null)
                        routning = "ukendt-dokumenttype";
                }
            }
            if (routning == null)
            {
                if (routningNode == null) 
                    routning = "default";
                else
                    routning = routningNode.Value;
            }

            // der kan være flere routninger for en dokumenttypexmodtageadresse kombination 
            // disse adskilles med komma
            List<Routning> l = new List<Routning>();
            foreach (string rs in routning.Split(','))
            {
                XmlNode n2;
                try
                {
                    n2 = Common.XPathSelect(k, "/PostFordelerKonfiguration/Routninger/Routning[@id='" + rs + "']");
                }
                catch (Exception)
                {
                    n2 = Common.XPathSelect(k, "/PostFordelerKonfiguration/Routninger/Routning[@id='default']");
                }
                if (n2 == null)
                {
                    n2 = Common.XPathSelect(k, "/PostFordelerKonfiguration/Routninger/Routning[@id='default']");
                }

                // skab routning og tilføj til resultat
                Routning r = new Routning();
                r.Load(n2);
                l.Add(r);
            }

            // special regel for værdipost
            if (at == Post.akttype.værdipost)
            {
                Routning rv=new Routning();
                XmlNode n3;
                try
                {
                    n3 = Common.XPathSelect(k, "/PostFordelerKonfiguration/Routninger/Routning[@id='Værdipost']");
                    rv.Load(n3);
                    l.Add(rv);
                }
                catch (Exception)
                {
                }
            }
            Routning[] routningListe=l.ToArray<Routning>();

            // opdater cache
            routningcache.Add(cachenoegle, routningListe);
            return routningListe;
        }

        // hent enkelt routning
        public Routning HentRoutning(string ID)
        {
            XmlNode n = Common.XPathSelect(k, "/PostFordelerKonfiguration/Routninger/Routning[@id='" + ID + "']");

            // skab routning og returner
            Routning r = new Routning();
            r.Load(n);
            return r;
        }

        public string HentOutputSkabelon()
        {
            XmlNode n=Common.XPathSelect(k, "/PostFordelerKonfiguration");
            return Common.GetAttributeValue(n, "outputskabelon", "", true);
        }

        public XmlNodeList HentAlleRegler()
        {
            return Common.XPathMultiSelect(XmlIndbakke, "Regel");
        }
        public XmlNodeList HentAlleIndbakker()
        {
            return Common.XPathMultiSelect(k, "/PostFordelerKonfiguration/Indbakker/Indbakke");
        }

        public XmlNodeList HentAlleSystemer()
        {
            return Common.XPathMultiSelect(k, "/PostFordelerKonfiguration/Systemer/System");
        }

        public XmlNodeList HentAlleDokumentTyper()
        {
            return Common.XPathMultiSelect(k, "/PostFordelerKonfiguration/DokumentTyper/DokumentType");
        }

        public XmlNodeList HentAlleModtagerAdresser(bool kunroutbare)
        {
            if (kunroutbare)
            {
                return Common.XPathMultiSelect(k, "/PostFordelerKonfiguration/ModtagerAdresser/Adresse[@routbar='Ja']");
            }
            else
            {
                return Common.XPathMultiSelect(k, "/PostFordelerKonfiguration/ModtagerAdresser/Adresse");
            }
        }

        public Routning[] HentAlleRoutninger()
        {
            XmlNodeList nl = Common.XPathMultiSelect(k, "/PostFordelerKonfiguration/Routninger/Routning");

            List<Routning> l = new List<Routning>();
            foreach (XmlNode n in nl)
            {
                string id = Common.XPathSelect(n, "@id").Value;
                XmlNode n2;
                n2 = Common.XPathSelect(k, "/PostFordelerKonfiguration/Routninger/Routning[@id='" + id + "']");
                Routning r = new Routning();
                r.Load(n2);
                l.Add(r);
            }
            return l.ToArray<Routning>();
        }

        //JTJ 7/12-2010 Tilføjet denne property
        public string DefaultTitel
        {
            get
            {
                XmlNode n = Common.XPathSelect(k, "/PostFordelerKonfiguration/Routninger");
                return Common.GetAttributeValue(n, "defaulttitel", "", true);
            }
        }

        // hvor peger indbakke hen?
        public string indbakkeURL
        {
            get
            {
                try
                {
                    return XmlIndbakke.Attributes.GetNamedItem("mappe").Value;

                }
                catch (Exception)
                {
                    return null;
                }
            }
        }
    }
}
