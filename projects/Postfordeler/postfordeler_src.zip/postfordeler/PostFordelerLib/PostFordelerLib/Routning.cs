﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace PostFordelerLib
{
    // repræsenterer en routning
    // implementer "arv" af visse egenskaber fra det system, der routes til
    public class Routning
    {

        // id på routning
        public string ID;

        // hvilke system router vi til?
        public string system;

        // og hvilken mappe?
        public string mappe;

        // skal vi slette XML følgeseddel?
        public bool sletXML;
        
        // standard CAPTIA "ting"
        public string myndighed;
        public string region;
        public string fagsoejle;
        public string kontor;
        public string sagsbehandler;
        public string indblik;
        public string titel;
        public string dokumentgruppe;
        bool parkering = false;

        public bool Parkering { get { return parkering; }} //JTJ

        // navn på output TIF fil
        public string outputtif;

        /// <summary>
        /// load routningen
        /// </summary>
        /// <param name="n">peger på en konkret routning (xmlnode i konfiguration)</param>
        public void Load(XmlNode n)
        {
            ID = Common.GetAttributeValue(n, "id", "", true);
            system = Common.GetAttributeValue(n, "system", "", true);
            mappe = Common.GetAttributeValue(n, "undermappe", "", false);
            myndighed = Common.GetAttributeValue(n, "myndighed", "", false);
            region = Common.GetAttributeValue(n, "region", "", false);
            fagsoejle = Common.GetAttributeValue(n, "fagsøjle", "", false);
            kontor = Common.GetAttributeValue(n, "kontor", "", false);
            sagsbehandler = Common.GetAttributeValue(n, "sagsbehandler", "", false);
            indblik = Common.GetAttributeValue(n, "indblik", "", false);
            titel = Common.GetAttributeValue(n, "titel", "", false);
            dokumentgruppe = Common.GetAttributeValue(n, "dokumentgruppe", "", false);

            // lookup på egenskaber, der arves fra "<system>"
            XmlNode n1 = Common.XPathSelect(n.OwnerDocument, "/PostFordelerKonfiguration/Systemer/System[@id='" + system + "']");

            Fagsystem sys = new Fagsystem();
            sys.Load(n1);

            if (sys.rodmappe != "") mappe=sys.rodmappe + @"\" + mappe;
            if (myndighed == "") myndighed = sys.myndighed;
            if (titel== "") titel = sys.titel;
            parkering = sys.Parkering; //JTJ
            sletXML = sys.sletXML;
            outputtif = sys.outputtif;
        }
    }
}
