﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;

namespace PostFordelerLib
{
    // repræsenter (CAPTIA) XML Følgeseddel
    public class OutputXML
    {
        // skabelonen hvorefter output skal laves
        private static XmlDocument outputskabelon=null;

        // indhold af skabelon
        // bemærk static 
        private static string outputskabelonXML=null;

        // arbejdskopi af skabelon
        private string outputskabelonXMLKopi;

        // henvisning til post objektet,der skal "outputtes" for
        private Post mP;

        // hvis true, brug XML document objekter, så vi får større sikkerhed at der laves korrekt XML
        private bool mSafemode;

        // JTJ
        private string defaultTitel = "";

        // loader skabelon (hvis ikke loadet før)
        public void Load(Konfiguration k, Post p, bool safemode)
        {
            mP = p;
            mSafemode = safemode;
            if (outputskabelon == null)
            {
                outputskabelon = new XmlDocument();
                outputskabelon.Load(k.HentOutputSkabelon());
                outputskabelonXML = outputskabelon.InnerXml;
            }
            outputskabelonXMLKopi = outputskabelonXML;
            defaultTitel = k.DefaultTitel; //JTJ
        }

        // gem resultat
        public string GemOutputXML(Routning r)
        {
            try
            {
                // skab ikke mappe - mappen skal findes i forvejen!
                //// skab evt. mappe
                //if (!Directory.Exists(r.mappe)) Directory.CreateDirectory(r.mappe);

                // play safe?
                // kør fordi XML objekt
                if (mSafemode)
                {
                    outputskabelon.LoadXml(outputskabelonXMLKopi);
                    outputskabelon.Save(r.mappe + @"\" + Path.GetFileNameWithoutExtension(mP.XMLURL) + ".output.xml");
                }
                else
                {
                    // gem resultat
                    File.WriteAllText(
                        r.mappe + @"\" + Path.GetFileNameWithoutExtension(mP.XMLURL) + ".output.xml",
                        outputskabelonXMLKopi);
                }
                return null;
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }

        // hjælper funktion
        private void OpdaterOutputFraPost(Post.postinfotype pit)
        {
            OpdaterOutput(pit.ToString(), mP.HentInformation(pit));
        }

        // hent information til skabelonen fra routning og fra postobjekt
        public void DanOutputXML(Routning r)
        {
            //TODO: output sættes til input hvis routningsregel for dette er angivet
            OpdaterOutput("myndighed", r.myndighed);
            OpdaterOutput("region", r.region);
            OpdaterOutput("fagsoejle", r.fagsoejle);
            OpdaterOutput("kontor", r.kontor);
            OpdaterOutput("sagsbehandler", r.sagsbehandler);
            OpdaterOutput("titel", (r.titel == "" ? defaultTitel : r.titel)); //JTJ 7/12-2010 tilf. valg
            OpdaterOutput("indblik", r.indblik);
            OpdaterOutput("dokumentgruppe", r.dokumentgruppe);
            OpdaterOutput("exDocID", mP.BestemtOutputTIF(r));
            OpdaterOutput("dokumenttype", mP.HentDokumentType());
            OpdaterOutput("modtageradresse", mP.HentModtagerAdresse());
            
            OpdaterOutputFraPost(Post.postinfotype.modtagerdato);
            OpdaterOutputFraPost(Post.postinfotype.afsenderadresse);
            OpdaterOutputFraPost(Post.postinfotype.akttype);
            OpdaterOutputFraPost(Post.postinfotype.medie);
            OpdaterOutputFraPost(Post.postinfotype.originalreturneres);
            OpdaterOutputFraPost(Post.postinfotype.modtagetfysisk);
            OpdaterOutputFraPost(Post.postinfotype.genscanning);
            OpdaterOutputFraPost(Post.postinfotype.indscanpers);
            OpdaterOutputFraPost(Post.postinfotype.indscantid);
            OpdaterOutputFraPost(Post.postinfotype.indscanside);
            OpdaterOutputFraPost(Post.postinfotype.oprindelse);
            OpdaterOutputFraPost(Post.postinfotype.opretbruger);
            OpdaterOutputFraPost(Post.postinfotype.scanningID);
        }

        // opdatering af skabelon - simpel strengmanipulation
        private void OpdaterOutput(string navn, string vaerdi)
        {
            outputskabelonXMLKopi = 
                outputskabelonXMLKopi.Replace("$" + navn + "$", vaerdi.Replace("&", "&amp;"));
        }
    }
}
