﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PostFordelerKonsol
{
    public partial class PostFordelerKonsolVisPost : Form
    {
        public PostFordelerKonsolVisPost()
        {
            InitializeComponent();
        }

        public string URL;
        public PostFordelerLib.Post p = new PostFordelerLib.Post();
 
        private void PostFordelerKonsolVisPost_Load(object sender, EventArgs e)
        {
            gridPost.Columns.Clear();
            Common.AddColumn(gridPost, "Felt");
            Common.AddColumn(gridPost, "Værdi");
            AddInfo("TIF", p.TIFURL);
            AddInfo(PostFordelerLib.Post.postinfotype.afsenderadresse);
            AddInfo(PostFordelerLib.Post.postinfotype.akttype);
            AddInfo(PostFordelerLib.Post.postinfotype.dokumenttype);
            AddInfo(PostFordelerLib.Post.postinfotype.genscanning);
            AddInfo(PostFordelerLib.Post.postinfotype.indscanpers);
            AddInfo(PostFordelerLib.Post.postinfotype.indscanside);
            AddInfo(PostFordelerLib.Post.postinfotype.indscantid);
            AddInfo(PostFordelerLib.Post.postinfotype.medie);
            AddInfo(PostFordelerLib.Post.postinfotype.modtageradresse);
            AddInfo(PostFordelerLib.Post.postinfotype.modtagerdato);
            AddInfo(PostFordelerLib.Post.postinfotype.modtagetfysisk);
            AddInfo(PostFordelerLib.Post.postinfotype.opretbruger);
            AddInfo(PostFordelerLib.Post.postinfotype.oprindelse);
            AddInfo(PostFordelerLib.Post.postinfotype.originalreturneres);
            AddInfo(PostFordelerLib.Post.postinfotype.scanningID);
        }

        private void AddInfo(PostFordelerLib.Post.postinfotype pit)
        {
            int i = gridPost.Rows.Add();
            gridPost.Rows[i].Cells[0].Value = pit.ToString();
            gridPost.Rows[i].Cells[1].Value = p.HentInformation(pit);
        }

        private void AddInfo(string felt, string vaerdi)
        {
            int i = gridPost.Rows.Add();
            gridPost.Rows[i].Cells[0].Value = felt;
            gridPost.Rows[i].Cells[1].Value = vaerdi;
        }

        private void gridPost_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
