﻿namespace PostFordelerKonsol
{
    partial class PostFordelerKonsolVisPost
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gridPost = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.gridPost)).BeginInit();
            this.SuspendLayout();
            // 
            // gridPost
            // 
            this.gridPost.AllowUserToAddRows = false;
            this.gridPost.AllowUserToDeleteRows = false;
            this.gridPost.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridPost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridPost.Location = new System.Drawing.Point(0, 0);
            this.gridPost.Name = "gridPost";
            this.gridPost.ReadOnly = true;
            this.gridPost.Size = new System.Drawing.Size(464, 439);
            this.gridPost.TabIndex = 1;
            this.gridPost.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridPost_CellContentClick);
            // 
            // PostFordelerKonsolVisPost
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 439);
            this.Controls.Add(this.gridPost);
            this.Name = "PostFordelerKonsolVisPost";
            this.Text = "Vis post";
            this.Load += new System.EventHandler(this.PostFordelerKonsolVisPost_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridPost)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView gridPost;
    }
}