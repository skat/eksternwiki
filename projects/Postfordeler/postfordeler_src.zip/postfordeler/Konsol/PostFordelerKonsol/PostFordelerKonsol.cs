﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml;
using System.IO;
using System.Collections;
using System.Drawing.Imaging;
using System.Drawing.Printing;

/*
 * Project is found at http://versionhost/svn/IP/trunk/PostFordeler/ 
 * i.e. jsvn co http://versionhost/svn/IP/trunk/PostFordeler PostFordelerVersionering
 */
namespace PostFordelerKonsol
{
    public partial class PostFordelerKonsol : Form
    {
        public PostFordelerKonsol()
        {
            InitializeComponent();
        }
        // styrer ">" knappens visning i statistik
        private int StatistikIndex = 0;

        // styrer ">" knappens visning i online statistik
        private int OnlineStatistikIndex = 0;

        private PostFordelerLib.Indbakke indbakke;

        // gem reference til knap
        Button knap;

        // gem den gamle farve på knappen før den skifter til gul
        private Color knapfarve;

        // til tidsmåling
        private int tickcount0;

        // hvor langt er vi kommet med at vise resultat af behandling af indbakke?
        private int antalVist;

        private void cmdBehandlIndbakke_Click(object sender, EventArgs e)
        {
            BehandlIndbakke(false, cmdBehandlIndbakke);
        }
        private void BehandlIndbakke(bool blnProeve, Button kn)
        {
            antalVist = 0;
            tickcount0 = Environment.TickCount;
            knapfarve = kn.BackColor;
            knap = kn;

            gridLog.Columns.Clear();
            gridOnlineStatistik.Rows.Clear();

            Common.AddColumn(gridLog, "Index");
            Common.AddColumn(gridLog, "Status");
            Common.AddColumn(gridLog, "XML");
            Common.AddColumn(gridLog, "TIF");
            Common.AddColumn(gridLog, "DokumentType");
            Common.AddColumn(gridLog, "ModtagerAdresse");
            Common.AddColumn(gridLog, "Routning");

            // hent konfiguration
            PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
            k.Load(comboIndbakke.Text);

            // skab kommunikationsvej mellem indbakkebehandlingen og GUI
            indbakke = new PostFordelerLib.Indbakke();
            indbakke.InKonfiguration = k;

            // sæt optioner

            if (blnProeve)
            {
                indbakke.InKopierTilFagsystemmappe = false;
                indbakke.InRydOpIIndbakke = false;
                indbakke.InKopierTilBehandlet = false;
                indbakke.InGemStatistik = false;
            }
            else
            {
                indbakke.InKopierTilFagsystemmappe = chkKopierTilFagsystemmappe.Checked;
                indbakke.InRydOpIIndbakke = chkRydOpIIndbakke.Checked;
                indbakke.InKopierTilBehandlet = chkKopierTilBehandlet.Checked;
                indbakke.InGemStatistik = true;
            }
            // check og sæt begrænsning på antal filer, der skal behandles pr. gang.

            if (txtMaxAntalFiler.Text != "")
                indbakke.InOutAntalFilerTilbage = int.Parse(txtMaxAntalFiler.Text);
            else
                indbakke.InOutAntalFilerTilbage = int.MaxValue;

            // lås knappen
            knap.Enabled = false;

            // sæt gul farve på knappen.
            if (blnProeve)
                kn.BackColor= Color.Yellow;
            else
                kn.BackColor = Color.Red;

            // start behandling af indbakken på en ny tråd (!)
            MethodInvoker mi = new MethodInvoker(indbakke.BehandlIndbakke);
            mi.BeginInvoke(null, null);

            // start overvågning af behandling af indbakken på en ny tråd (!)
            mi = new MethodInvoker(MonitorBehandling);
            mi.BeginInvoke(null, null);             
        }


        private delegate void OpdaterGUIHandler(
            object sender,
            System.EventArgs e);

        // kaldes af overvågning af behandling af indbakken 
        // opdaterer GUI'en svarende til hvad er sket "siden sidst"
        private void OpdaterGUI(object o, System.EventArgs e) 
        {
            try
            {
                // hvor langt er vi kommet ? (tæller ned til 0)
                int i = indbakke.InOutAntalFilerTilbage;

                // vis fremdrift.
                labelAntal.Text = i.ToString();

                // opdater log linier (nederste grid)
                int jlim=indbakke.OutLoglinier.Count;
                for (int j = antalVist; j < jlim; j++)
                {
                    int jj=gridLog.Rows.Add(((string)indbakke.OutLoglinier[j]).Split('\t'));
                    if ((string)gridLog[1, jj].Value != "OK") gridLog[1, jj].Style.BackColor = Color.LightPink;
                }

                // så har vi vist så langt...
                antalVist=jlim;

                // vis alvorlig fejl!
                if (indbakke.OutFejlTekst != null) MessageBox.Show(indbakke.OutFejlTekst);
                // færdige?
                if (i <= 0)
                {
                    //for (int j = antalVist; j < indbakke.OutLoglines.Count; j++)
                    //{
                    //    int jj = gridLog.Rows.Add(((string)indbakke.OutLoglines[j]).Split('\t'));
                    //    if ((string)gridLog[1, jj].Value != "OK") gridLog[1, jj].Style.BackColor = Color.LightPink;
                    //}
                    // vis online statistik
                    OpdaterMatrixGrid(
                        "DokumentType",
                        indbakke.OutDokumenttyper,
                        indbakke.OutRoutninger,
                        indbakke.OutAntalDTRO,
                        gridOnlineStatistik);
                    OnlineStatistikIndex=1;
                    labelOnlineStatistikType.Text = "DokumentType x Routninger";
                    
                    // genetabler knap 
                    knap.BackColor = knapfarve ;
                    knap.Enabled = true;
                    int tickcountdelta = (Environment.TickCount - tickcount0) / 1000;
                    labelAntal.Text += " (" + tickcountdelta + "s)";
                }
            }
            catch (Exception)
            {

            }
        }

        // overvågning af behandling af indbakken 
        private void MonitorBehandling()
        {
            while (true)
            {
                // sov i ½s
                System.Threading.Thread.Sleep(500);
                try
                {
                    // hvor langt er vi?
                    int i = indbakke.InOutAntalFilerTilbage;

                    // kald opdatering af GUI - på en anden tråd!
                    object[] pList = { this, System.EventArgs.Empty };
                    BeginInvoke(new OpdaterGUIHandler(OpdaterGUI), pList);

                    // færdige!
                    if (i <= 0) break;
                }
                catch (Exception)
                {

                }
            }
        }
       
        // hvilket miljø kører vi i?
        // bruges til at udpege den rigtige konfiguration
        // og til at fjerne options i GUI
        private const string miljoeTest="test";
        private const string miljoeProduktion = "produktion";
        private string miljoe;

        private void PostFordelerKonsol_Load(object sender, EventArgs e)
        {
            string[] parametre= Environment.GetCommandLineArgs();

            // antag at vi kører produktion
            miljoe=miljoeProduktion;

            int i = 0;
            foreach (string parameter in parametre)
            {
                i++;
                if (i==2) miljoe = parameter.ToLower();
            }

            // check miljø
            if ((miljoe != miljoeProduktion) && (miljoe != miljoeTest))
            {
                MessageBox.Show("Programmet kan ikke starte. Ukendt miljø: \"" + miljoe + "\"");
                Close();
            }

            this.Text += " - " + miljoe;

            if (miljoe == miljoeProduktion)
            {
                chkRydOpIIndbakke.Checked = true;
                chkKopierTilFagsystemmappe.Checked = true;
                chkKopierTilBehandlet.Checked = true;
                chkRydOpIIndbakke.Enabled= false;
                chkKopierTilFagsystemmappe.Enabled = false;
                chkKopierTilBehandlet.Enabled = false;
            }
            else
            {
                chkRydOpIIndbakke.Checked = false;
                chkKopierTilFagsystemmappe.Checked = true;
                chkKopierTilBehandlet.Checked = true;
                chkRydOpIIndbakke.Enabled = true;
                chkKopierTilFagsystemmappe.Enabled = true;
                chkKopierTilBehandlet.Enabled = true;
            }
            try
            {
                // fyld comboboks med indbakke-muligheder
                PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
                k.Load(null);

                XmlNodeList nl = k.HentAlleIndbakker();
                foreach (XmlNode n in nl)
                {
                    comboIndbakke.Items.Add(PostFordelerLib.Common.GetAttributeValue(n, "id", "", true).Trim());
                }
                if (comboIndbakke.Items.Count > 0) comboIndbakke.Text = comboIndbakke.Items[0].ToString();

            }
            catch (Exception ee)
            {
                MessageBox.Show("Fejl - programmet kan ikke starte. Fejlen er: \""+ee.Message+ "\"");
                //Close();
            }

            txtStatTilDato.Text = DateTime.Now.ToString("dd-MM-yyyy");
            txtStatFraDato.Text = DateTime.Now.AddMonths(-1).ToString("dd-MM-yyyy");
            SetSplitters();
        }

        
        private void cmdFindPost_Click(object sender, EventArgs e)
        {
            AntalFindPost.Text = "";
            knapfarve = cmdFindPost.BackColor;
            cmdFindPost.BackColor = Color.Yellow;
            
            PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
            k.Load(comboIndbakke.Text);

            gridPostList.Rows.Clear();

            FindPostKonfiguration = k;

            // hvor søger vi henne?
            FindPostIndbakkeNavn = comboIndbakke.Text;

            // hvad søger vi på
            FindPostScanID = txtScanID.Text;

            // er søgningen færdig?
            FindPostAfsluttet = false;

            // start søgning på ny tråd
            MethodInvoker mi = new MethodInvoker(FindPostBaggrund);
            mi.BeginInvoke(null, null);

            // start overvågning af søgning på ny tråd
            mi = new MethodInvoker(MonitorFindPost);
            mi.BeginInvoke(null, null);

            // udfyld combo med alle routningerne
            comboRoutninger.Items.Clear();
            PostFordelerLib.Routning[] r = k.HentAlleRoutninger();
            foreach (PostFordelerLib.Routning rr in r)
            {
                comboRoutninger.Items.Add(rr.ID);
            }

        }

        // opsæt "parametre" til søgning efter post i baggrund
        // læses/skrives af FindPostBaggrund()!

        // konfiguration

        private PostFordelerLib.Konfiguration FindPostKonfiguration;
        // hvilken indbakke søger vi i?
        private string FindPostIndbakkeNavn;
        // hvad søger vi på
        private string FindPostScanID;
        // er søgningen færdig?
        private bool FindPostAfsluttet;
        // hvad er resultat af søgningen
        private ArrayList FindPostResultat;

        // hvor langt er vi kommet med at vise søge resultatet?
        private int FindPostAntalVist;

        // søgning efter post i baggrunden (på egen tråd)
        private void FindPostBaggrund()
        {

            FindPostAfsluttet = false;

            PostFordelerLib.Konfiguration k = FindPostKonfiguration;

            string URL = k.indbakkeURL;

            // find filer
            string[] filer;
            try
            {
                filer = Directory.GetFiles(URL, FindPostScanID + ".xml", SearchOption.AllDirectories);
            }
            catch (Exception)
            {
                return;
            }

            FindPostResultat = new ArrayList();
            FindPostAntalVist = 0;

            int index = 0;
            foreach (string fil in filer)
            {
                // spring alle statistikfilerne over(!)
                if (fil.Contains(@"\Stat\")) continue;

                PostFordelerLib.Post p = new PostFordelerLib.Post();
                p.Load(fil, k);

                FindPostResultat.Add(
                    ++index + "\t" +
                    Path.GetFileNameWithoutExtension(p.XMLURL) + "\t" +
                    Path.GetFullPath(fil).Replace(k.indbakkeURL, "").Replace(Path.GetFileName(p.XMLURL), "") + "\t" +
                    File.GetCreationTime(fil) + "\t" +
                    p.HentDokumentType() + "\t" +
                    p.HentModtagerAdresse() + "\t" +
                    p.XMLURL + "\t" +
                    p.TIFURL);
            }
            FindPostAfsluttet = true;
        }

        // opdater GUI i forbindelse med søgning
        private void OpdaterGUIFindPost(object o, System.EventArgs e) 
        {
            try
            {
                // vis resultatet - so far.
                for (int i=FindPostAntalVist;i<FindPostResultat.Count;i++)
                    gridPostList.Rows.Add(((string)FindPostResultat[i]).Split('\t'));

                // så langt kom vi denne gang...
                FindPostAntalVist=FindPostResultat.Count;

                // er vi færdige?
                if (FindPostAfsluttet) 
                {
                    // vis evt. rest!
                    for (int i = FindPostAntalVist; i < FindPostResultat.Count; i++)
                        gridPostList.Rows.Add(((string)FindPostResultat[i]).Split('\t'));

                    AntalFindPost.Text = "fundet " + FindPostAntalVist;

                    // genetabler knap
                    cmdFindPost.BackColor = knapfarve;
                    cmdFindPost.Enabled = true;
                }
            }
            catch (Exception)
            {

            }
        }

        // overvågning af søgning efter post - på egen tråd.
        private void MonitorFindPost()
        {
            while (true)
            {
                // sov halvt sekund
                System.Threading.Thread.Sleep(500);
                try
                {
                    // kald GUI opdatering på GUI tråden.
                    object[] pList = { this, System.EventArgs.Empty };
                    BeginInvoke(new OpdaterGUIHandler(OpdaterGUIFindPost), pList);

                    // færdig?
                    if (FindPostAfsluttet) break;
                }
                catch (Exception)
                {

                }
            }
        }

        // Kode bag ved knappen "Flyt Post"
        // Hvis FIL_MANUEL er valgt som routning, så skal vi også fjerne dokumenttypen fra XML inden vi flytter dokumentet
        private void cmdOmplacerManuelt_Click(object sender, EventArgs e)
        {
            // Find den valgte række
            DataGridViewRow raekken = null;
            foreach (DataGridViewRow raekke in gridPostList.Rows)
            {
                if (raekke.Selected)
                {
                    raekken = raekke;
                    raekke.Selected = false;
                    break;
                }
            }

            // Check at vi har en valgt række
            if (raekken == null)
            {
                MessageBox.Show("Fejl - post til omplacering er ikke valgt - venligst vælg post til omplacering");
                return;
            }
            
            // Check at vi har en routningsregel
            if (comboRoutninger.Text == "")
            {
                MessageBox.Show("Fejl - kan ikke omplacere uden routning - venligst vælg routning");
                return;
            }

            // Valgte række er raekken
            // Valgte routning er comboRoutninger.Text

            // Instantier Test eller Prod udgave af konfigurationer med udgangspunkt i den valgte indbakke
            PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
            k.Load(comboIndbakke.Text);

            // Repræsenterer et stykke post (input XML og TIF fil)
            PostFordelerLib.Post p = new PostFordelerLib.Post();
            
            // find URL i grid linien - kolonne 6 (absolutte sti og filnavn)
            string URL = (string)raekken.Cells[6].Value;

            // load post objekt
            // Check også om routning foranlediger en XML modification
            string postfejl = p.Load(URL, k, comboRoutninger.Text);
            if (postfejl != null)
            {
                MessageBox.Show(postfejl);
                return;
            }

            // opret indbakkeobjekt så vi kan få reroutet posten.
            PostFordelerLib.Indbakke indbakke = new PostFordelerLib.Indbakke();

            // sæt input standard værdier
            indbakke.InKonfiguration = k;
            indbakke.InKopierTilFagsystemmappe = true;
            indbakke.InKopierTilBehandlet = true;
            indbakke.InRydOpIIndbakke = false;

            // er det en gyldig routning, der er valgt på skærmen?
            PostFordelerLib.Routning r = null;
            try
            {
                r = k.HentRoutning(comboRoutninger.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Fejl - ukendt routning - venligst vælg anden routning til omplacering");
                return;
            }

            // gennemfør reroutningen
            string fejl = null;
            
            // Konfiguration, Post(TIF+XML), Routning, bool, svar
            indbakke.BehandlPost(k, p, r, true, out fejl);

            if (fejl != null)
            {
                raekken.DefaultCellStyle.BackColor = Color.LightPink;               
                MessageBox.Show(fejl);
            }
            else
                // vis at post (række i grid) er behandlet!
                raekken.DefaultCellStyle.BackColor = Color.LawnGreen;
        }

        private void gridPostList_SelectionChanged(object sender, EventArgs e)
        {
            // en og kun en valgt?
            // tillad omplacering!
            int i = 0;
            foreach (DataGridViewRow raekke in gridPostList.Rows)
            {
                if (raekke.Selected) i++;
            }
            cmdOmplacerManuelt.Enabled = (i == 1);
        }


        // vis XML fil for dobbeltklik i celle i kolonne "URL" (6)
        // vis TIF fil for dobbeltklik i celle i kolonne "TIF" (7)
        // vis post information i modalvindue for dobbeltklik i celle i kolonne "" (1)
        private void gridPostList_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = e.RowIndex;
            int j = e.ColumnIndex;
            if (i < 0) return;
            if (j < 0) return;
            string URL;
            
            switch (j)
            {
                case 6: 
                case 7:
                    try
                    {
                        URL = gridPostList[j, i].Value.ToString();
                        System.Diagnostics.Process.Start(URL);
                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.Message);
                    }
                    break;
                case 1:
                    URL = gridPostList[6, i].Value.ToString();
                    PostFordelerLib.Post p=new PostFordelerLib.Post();
                    PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
                    k.Load(comboIndbakke.Text);
                    p.Load(URL, k);
                    PostFordelerKonsolVisPost vp = new PostFordelerKonsolVisPost();
                    vp.p=p;
                    vp.Show();
                    break;
                default:
                    return;
            }
        }

        #region vis statistik

        // knappen ">"

        // opdater statistik grid
        private void OpdaterMatrixGrid(
            string kolonne1overskift, 
            SortedList<string, string> raekker, 
            SortedList<string, string> kolonner, 
            SortedList<string, int> antal, 
            DataGridView grid)
        {
            // nulstil grid
            grid.Rows.Clear();

            // fjern alle kolonner PÅNÆR den første(!)
            while (grid.Columns.Count > 1) grid.Columns.RemoveAt(grid.Columns.Count - 1);

            try
            {
                grid.Columns[0].HeaderText = kolonne1overskift;

                //tilføj kolonner - klon fra den første!

                DataGridViewColumn kolonne;
                foreach (string s in kolonner.Keys)
                {
                    if (grid.Columns[s] == null)
                    {
                        kolonne = (DataGridViewColumn)grid.Columns[0].Clone();
                        kolonne.HeaderText = s;
                        kolonne.Name = s;
                        grid.Columns.Add(kolonne);
                    }
                }
                kolonne = (DataGridViewColumn)grid.Columns[0].Clone();
                kolonne.HeaderText = "Total";
                kolonne.Name = "Total";
                grid.Columns.Add(kolonne);

                // tilføj rækker
                int i;
                foreach (string s in raekker.Keys)
                {
                    i = grid.Rows.Add();
                    grid.Rows[i].Cells[0].Value = s;
                }
                i = grid.Rows.Add();
                grid.Rows[i].Cells[0].Value = "Total";


                // put antal i grid
                foreach (string v in antal.Keys)
                {
                    i = antal[v];
                    string ri = v.Split(',')[0];
                    string ci = v.Split(',')[1];

                    DataGridViewRow raekke = null;

                    // find række!
                    foreach (DataGridViewRow r in grid.Rows)
                    {
                        if (r.Cells[0].Value.ToString() == ri)
                        {
                            raekke = r;
                            break;
                        }
                    }

                    // find kolonne og sæt værdi!
                    raekke.Cells[ci].Value = i;
                    // opdater totaler
                    // kolonne
                    int kolonnetotal=0;
                    if (grid[ci, grid.Rows.Count - 1].Value!=null) 
                        kolonnetotal=(int)grid[ci, grid.Rows.Count - 1].Value;
                    grid[ci, grid.Rows.Count - 1].Value = kolonnetotal+i;
                    // række
                    int raekketotal = 0;
                    if (raekke.Cells[grid.Columns.Count - 1].Value!=null)
                        raekketotal=(int)raekke.Cells[grid.Columns.Count - 1].Value;
                    raekke.Cells[grid.Columns.Count - 1].Value = raekketotal+i;
                    // total-total
                    int totaltotal = 0;
                    if (grid[grid.Columns.Count-1, grid.Rows.Count - 1].Value != null)
                        totaltotal = (int)grid[grid.Columns.Count - 1, grid.Rows.Count - 1].Value;
                    grid[grid.Columns.Count - 1, grid.Rows.Count - 1].Value = totaltotal + i ;
                }
                grid.AutoResizeColumns();
            }
            catch (Exception)
            {
                return;
            }
        }

        #endregion

        #region vis konfiguration

        private void cmdVisSystemer_Click(object sender, EventArgs e)
        {

            // init. grid
            gridKonfiguration.Columns.Clear();
            Common.AddColumn(gridKonfiguration, "Index");
            Common.AddColumn(gridKonfiguration, "System");
            Common.AddColumn(gridKonfiguration, "Rodmappe");
            Common.AddColumn(gridKonfiguration, "Undlad output XML?");
            Common.AddColumn(gridKonfiguration, "Output TIF");
            Common.AddColumn(gridKonfiguration, "Myndighed");
            Common.AddColumn(gridKonfiguration, "Titel");
            Common.AddColumn(gridKonfiguration, "Antal Routninger");

            PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
            k.Load(comboIndbakke.Text);

            // hent systemerne
            XmlNodeList nl = k.HentAlleSystemer();

            // gennemgå systemerne
            foreach (XmlNode n in nl)
            {
                int j = 0;
                int i = gridKonfiguration.Rows.Add();
                gridKonfiguration.Rows[i].Cells[j++].Value = i+1;
                // TODO Overvej at skjule XML model i konfiguration helt
                string systemid = PostFordelerLib.Common.GetAttributeValue(n, "id", "", true).Trim();
                gridKonfiguration.Rows[i].Cells[j++].Value = systemid;
                gridKonfiguration.Rows[i].Cells[j++].Value = PostFordelerLib.Common.GetAttributeValue(n, "rodmappe", "", false).Trim();
                gridKonfiguration.Rows[i].Cells[j++].Value = PostFordelerLib.Common.GetAttributeValue(n, "sletXML", "Nej", false).Trim();
                gridKonfiguration.Rows[i].Cells[j++].Value = PostFordelerLib.Common.GetAttributeValue(n, "outputtif", "", false).Trim();
                gridKonfiguration.Rows[i].Cells[j++].Value = PostFordelerLib.Common.GetAttributeValue(n, "myndighed", "", false).Trim();
                gridKonfiguration.Rows[i].Cells[j++].Value = PostFordelerLib.Common.GetAttributeValue(n, "titel", "", false).Trim();

                // optæl antal routninger der peger på system
                int l = PostFordelerLib.Common.XPathMultiSelect(n.OwnerDocument, "/PostFordelerKonfiguration/Routninger/Routning[@system='" + systemid + "']").Count;
                gridKonfiguration.Rows[i].Cells[j++].Value = l;
            }
        }

        private void cmdVisModtageradresser_Click(object sender, EventArgs e)
        {
            // init. grid
            gridKonfiguration.Columns.Clear();
            Common.AddColumn(gridKonfiguration, "Index");
            Common.AddColumn(gridKonfiguration, "Adresse");
            Common.AddColumn(gridKonfiguration, "Beskrivelse");
            Common.AddColumn(gridKonfiguration, "Antal regler");

            PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
            k.Load(comboIndbakke.Text);

            // hent modtageradresserne
            XmlNodeList nl = k.HentAlleModtagerAdresser(false);

            // gennemgå modtageradresserne
            foreach (XmlNode n in nl)
            {
                int j = 0;
                int i = gridKonfiguration.Rows.Add();
                gridKonfiguration.Rows[i].Cells[j++].Value = i+1;
                // TODO Overvej at skjule XML model i konfiguration helt
                string a = PostFordelerLib.Common.GetAttributeValue(n, "id", "", true).Trim();
                string b = PostFordelerLib.Common.GetAttributeValue(n, "beskrivelse", "", true).Trim();
                gridKonfiguration.Rows[i].Cells[j++].Value = a;
                gridKonfiguration.Rows[i].Cells[j++].Value = b;

                // find antal regler for denne modtageradresse
                int l = PostFordelerLib.Common.XPathMultiSelect(k.XmlIndbakke, "Regel[@modtageradresse='" + a + "']").Count;
                l += PostFordelerLib.Common.XPathMultiSelect(k.XmlIndbakke, "Regel[@modtageradresse='*']").Count;
                gridKonfiguration.Rows[i].Cells[j++].Value = l;
            }
        }

        private void cmdVisDokumentTyper_Click(object sender, EventArgs e)
        {
            // init. grid
            gridKonfiguration.Columns.Clear();
            Common.AddColumn(gridKonfiguration, "Index");
            Common.AddColumn(gridKonfiguration, "DokumentType");
            Common.AddColumn(gridKonfiguration, "Antal regler");

            PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
            k.Load(comboIndbakke.Text);

            // hent alle dokumenttyper
            XmlNodeList nl = k.HentAlleDokumentTyper();

            // gennemgå dokumenttyperne
            foreach (XmlNode n in nl)
            {
                int j = 0;
                int i = gridKonfiguration.Rows.Add();
                gridKonfiguration.Rows[i].Cells[j++].Value = i+1;
                // TODO Overvej at skjule XML model i konfiguration helt
                string t = PostFordelerLib.Common.GetAttributeValue(n, "id", "", true).Trim();
                gridKonfiguration.Rows[i].Cells[j++].Value = t;

                // optæl antal regler, der peger på dokumenttypen
                int l = PostFordelerLib.Common.XPathMultiSelect(k.XmlIndbakke, "Regel[@dokumenttype='" + t + "']").Count;
                l += PostFordelerLib.Common.XPathMultiSelect(k.XmlIndbakke, "Regel[@dokumenttype='*']").Count;
                gridKonfiguration.Rows[i].Cells[j++].Value = l;
            }

        }
        
        private void cmdVisRoutninger_Click(object sender, EventArgs e)
        {
            // init. grid
            gridKonfiguration.Columns.Clear();
            Common.AddColumn(gridKonfiguration, "Index");
            Common.AddColumn(gridKonfiguration, "Routninger");
            Common.AddColumn(gridKonfiguration, "System");
            Common.AddColumn(gridKonfiguration, "Mappe");
            Common.AddColumn(gridKonfiguration, "Myndighed");
            Common.AddColumn(gridKonfiguration, "Region");
            Common.AddColumn(gridKonfiguration, "Fagsøjle");
            Common.AddColumn(gridKonfiguration, "Kontor");
            Common.AddColumn(gridKonfiguration, "Sagsbehandler");
            Common.AddColumn(gridKonfiguration, "Indblik");
            Common.AddColumn(gridKonfiguration, "Titel");
            Common.AddColumn(gridKonfiguration, "Dokumentgruppe");
            Common.AddColumn(gridKonfiguration, "Antal regler");

            PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
            k.Load(comboIndbakke.Text);

            // hent alle routninger 
            PostFordelerLib.Routning []routningliste=k.HentAlleRoutninger();

            // gennemgå routningerne
            foreach (PostFordelerLib.Routning r in routningliste)
            {
                int j = 0;
                int i = gridKonfiguration.Rows.Add();
                gridKonfiguration.Rows[i].Cells[j++].Value = i+1;
                gridKonfiguration.Rows[i].Cells[j++].Value = r.ID;
                gridKonfiguration.Rows[i].Cells[j++].Value = r.system;
                gridKonfiguration.Rows[i].Cells[j++].Value = r.mappe;
                gridKonfiguration.Rows[i].Cells[j++].Value = r.myndighed;
                gridKonfiguration.Rows[i].Cells[j++].Value = r.region;
                gridKonfiguration.Rows[i].Cells[j++].Value = r.fagsoejle;
                gridKonfiguration.Rows[i].Cells[j++].Value = r.kontor;
                gridKonfiguration.Rows[i].Cells[j++].Value = r.sagsbehandler;
                gridKonfiguration.Rows[i].Cells[j++].Value = r.indblik;
                gridKonfiguration.Rows[i].Cells[j++].Value = r.titel;
                gridKonfiguration.Rows[i].Cells[j++].Value = r.dokumentgruppe;

                // optæl antal regler, der peger på routningen
                // TODO Overvej at skjule XML model i konfiguration helt
                int l = PostFordelerLib.Common.XPathMultiSelect(k.XmlIndbakke, "Regel[@routning='" + r.ID + "']").Count;
                gridKonfiguration.Rows[i].Cells[j++].Value = l;
            }
        }

        private void cmdVisregler_Click(object sender, EventArgs e)
        {
            // init. grid
            gridKonfiguration.Columns.Clear();
            Common.AddColumn(gridKonfiguration, "Index");
            Common.AddColumn(gridKonfiguration, "DokumentType");
            Common.AddColumn(gridKonfiguration, "ModtagerAdresse");
            Common.AddColumn(gridKonfiguration, "Routning");
            Common.AddColumn(gridKonfiguration, "System");
            Common.AddColumn(gridKonfiguration, "Mappe");
            Common.AddColumn(gridKonfiguration, "Myndighed");
            Common.AddColumn(gridKonfiguration, "Region");
            Common.AddColumn(gridKonfiguration, "Fagsøjle");
            Common.AddColumn(gridKonfiguration, "Kontor");
            Common.AddColumn(gridKonfiguration, "Sagsbehandler");
            Common.AddColumn(gridKonfiguration, "Indblik");
            Common.AddColumn(gridKonfiguration, "Titel");
            Common.AddColumn(gridKonfiguration, "Dokumentgruppe");

            PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
            k.Load(comboIndbakke.Text);

            // hent alle regler
            XmlNodeList nl = k.HentAlleRegler();

            // gennemgå reglerne 
            foreach (XmlNode n in nl)
            {
                // TODO Overvej at skjule XML model i konfiguration helt
                string dokumenttype = PostFordelerLib.Common.GetAttributeValue(n, "dokumenttype", "", true).Trim();
                string modtageradresse = PostFordelerLib.Common.GetAttributeValue(n, "modtageradresse", "", true).Trim();

                if ((dokumenttype == "") || (modtageradresse == "")) continue;

                int j = 0;
                int i = gridKonfiguration.Rows.Add();
                gridKonfiguration.Rows[i].Cells[j++].Value = i+1;
                gridKonfiguration.Rows[i].Cells[j++].Value = dokumenttype;
                gridKonfiguration.Rows[i].Cells[j++].Value = modtageradresse;
                gridKonfiguration.Rows[i].Cells[j++].Value = PostFordelerLib.Common.GetAttributeValue(n, "routning", "", true).Trim();

                // fold routning ud
                PostFordelerLib.Routning[] rr = k.BestemRoutninger(modtageradresse, dokumenttype, PostFordelerLib.Post.akttype.almindeligpost);
                gridKonfiguration.Rows[i].Cells[j++].Value = rr[0].system;
                gridKonfiguration.Rows[i].Cells[j++].Value = rr[0].mappe;
                gridKonfiguration.Rows[i].Cells[j++].Value = rr[0].myndighed;
                gridKonfiguration.Rows[i].Cells[j++].Value = rr[0].region;
                gridKonfiguration.Rows[i].Cells[j++].Value = rr[0].fagsoejle;
                gridKonfiguration.Rows[i].Cells[j++].Value = rr[0].kontor;
                gridKonfiguration.Rows[i].Cells[j++].Value = rr[0].sagsbehandler;
                gridKonfiguration.Rows[i].Cells[j++].Value = rr[0].indblik;
                gridKonfiguration.Rows[i].Cells[j++].Value = rr[0].titel;
                gridKonfiguration.Rows[i].Cells[j++].Value = rr[0].dokumentgruppe;
            }

        }

        private void cmdVisManglendeRegler_Click(object sender, EventArgs e)
        {
            // init.grid
            gridKonfiguration.Columns.Clear();
            Common.AddColumn(gridKonfiguration, "Index");
            Common.AddColumn(gridKonfiguration, "DokumentType");
            Common.AddColumn(gridKonfiguration, "Adresse");

            PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
            k.Load(comboIndbakke.Text);

            // dokumenttype=dt
            XmlNodeList dtliste = k.HentAlleDokumentTyper();

            // modtageradresse=ma
            XmlNodeList maliste = k.HentAlleModtagerAdresser(true);
            int maantal = maliste.Count;

            // gennemgå "dt"
            foreach (XmlNode dtn in dtliste)
            {
                // findes der en regel "dt" og "ma"=* og hvor routning er sat?
                // gå til næste

                // TODO Overvej at skjule XML model i konfiguration helt
                string dt = PostFordelerLib.Common.GetAttributeValue(dtn, "id", "", true).Trim();
                if (PostFordelerLib.Common.XPathMultiSelect(
                    k.XmlIndbakke,
                    "Regel[@dokumenttype='" + dt + "'][@modtageradresse='*'][@routning!='']").Count > 0)
                    continue;

                // det gjorde der ikke...

                // gennemløb da "ma"
                // først - findes der slet ikke en routning for nogen modtageradresse
                // rapporter med ma="*"
                // ellers - nedenfor - gå igennem alle modtageradresser

                int a = maantal;

                foreach (XmlNode man in maliste)
                // findes der en regel "dt" og "ma" og hvor routning er sat?
                // break da!
                {
                    string ma = PostFordelerLib.Common.GetAttributeValue(man, "id", "", true).Trim();

                    if (PostFordelerLib.Common.XPathMultiSelect(
                        k.XmlIndbakke,
                        "Regel[@dokumenttype='" + dt + "'][@modtageradresse='" + ma + "'][@routning!='']").Count > 0)
                        break;
                    a--;
                }

                if (a == 0)
                {
                    int j = 0;
                    int i = gridKonfiguration.Rows.Add();
                    gridKonfiguration.Rows[i].Cells[j++].Value = i + 1;
                    gridKonfiguration.Rows[i].Cells[j++].Value = dt;
                    gridKonfiguration.Rows[i].Cells[j++].Value = "*";
                }
                else
                {
                    foreach (XmlNode man in maliste)
                    // findes der en regel "dt" og "ma" og hvor routning er sat?
                    // gå til næste
                    {
                        string ma = PostFordelerLib.Common.GetAttributeValue(man, "id", "", true).Trim();

                        if (PostFordelerLib.Common.XPathMultiSelect(
                            k.XmlIndbakke,
                            "Regel[@dokumenttype='" + dt + "'][@modtageradresse='" + ma + "'][@routning!='']").Count > 0)
                            continue;

                        // rapporter manglende routning!
                        int j = 0;
                        int i = gridKonfiguration.Rows.Add();
                        gridKonfiguration.Rows[i].Cells[j++].Value = i + 1;
                        gridKonfiguration.Rows[i].Cells[j++].Value = dt;
                        gridKonfiguration.Rows[i].Cells[j++].Value = ma;
                    }
                }
            }
        }

        #endregion


        private void SetSplitters()
        {
            splitContainer5.SplitterDistance = 100;
            splitContainer5.Refresh();
            splitContainer3.SplitterDistance = 70;
            splitContainer3.Refresh();
            splitContainer1.SplitterDistance = 70;
            splitContainer1.Refresh();
            splitContainer4.SplitterDistance = 70;
            splitContainer4.Refresh();
        }

        private void tabPage1_Resize(object sender, EventArgs e)
        {
            SetSplitters();
        }

        private void tabPage2_Resize(object sender, EventArgs e)
        {
            SetSplitters();
        }

        private void tabPage3_Resize(object sender, EventArgs e)
        {
            SetSplitters();
        }

        private void tabPage4_Resize(object sender, EventArgs e)
        {
            SetSplitters();
        }

        private void gridPostList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmdPrøveBehandling_Click(object sender, EventArgs e)
        {
            BehandlIndbakke(true, cmdPrøveBehandling);
        }

        private void cmdVisStatistik_Click(object sender, EventArgs e)
        {
            DateTime datoFra = DateTime.MinValue ;
            DateTime datoTil= DateTime.MaxValue ;

            try
            {
                datoFra = DateTime.Parse(txtStatFraDato.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Fejl - 'fra' dato er ikke gyldig.");
                return;
            }
            try
            {
                datoTil = DateTime.Parse(txtStatTilDato.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Fejl - 'til' dato er ikke gyldig.");
                return;
            }

            knapfarve = cmdVisStatistik.BackColor;
            cmdVisStatistik.BackColor = Color.Yellow;

            PostFordelerLib.Konfiguration k = new PostFordelerLib.Konfiguration(miljoe);
            k.Load(comboIndbakke.Text);

            // skab kommunikationsvej mellem indbakkebehandlingen og GUI
            indbakke = new PostFordelerLib.Indbakke();
            indbakke.InKonfiguration = k;
            indbakke.InOutAntalFilerTilbage = int.MaxValue;
            indbakke.InStatistikDatoFra = datoFra;
            indbakke.InStatistikDatoTil = datoTil;

            gridStatistik.Rows.Clear();

            // start statistikopsamling på ny tråd
            MethodInvoker mi = new MethodInvoker(indbakke.OpsamlStatistik);
            mi.BeginInvoke(null, null);

            // start overvågning af statistikopsamling på ny tråd
            mi = new MethodInvoker(MonitorStatistik);
            mi.BeginInvoke(null, null);
        }

        // opdater GUI i forbindelse med opsamling af statistik
        private void OpdaterGUIStatistik(object o, System.EventArgs e)
        {
            try
            {
                // er vi færdige?
                if (indbakke.InOutAntalFilerTilbage<=0)
                {
                    cmdVisStatistik.BackColor = knapfarve;
                    cmdVisStatistik.Enabled = true;
                    OpdaterMatrixGrid(
                        "Dato",
                        indbakke.OutDatoer,
                        indbakke.OutRoutninger,
                        indbakke.OutAntalDatoRO,
                        gridStatistik);
                    StatistikIndex = 0;
                    labelStatistikType.Text = "Routninger";
                }
            }
            catch (Exception)
            {

            }
        }

        // overvågning af opsamling af statistik - på egen tråd.
        private void MonitorStatistik()
        {
            while (true)
            {
                // sov halvt sekund
                System.Threading.Thread.Sleep(500);
                try
                {
                    // kald GUI opdatering på GUI tråden.
                    object[] pList = { this, System.EventArgs.Empty };
                    BeginInvoke(new OpdaterGUIHandler(OpdaterGUIStatistik), pList);

                    // færdig?
                    if (indbakke.InOutAntalFilerTilbage<=0) break;
                }
                catch (Exception)
                {

                }
            }
        }

        private void cmdNaesteOnlineStatistik_Click(object sender, EventArgs e)
        {
            // rul rundt igennem de tre visninger
            try
            {
                switch (OnlineStatistikIndex)
                {
                    case 0:
                        OpdaterMatrixGrid(
                            "DokumentType",
                            indbakke.OutDokumenttyper,
                            indbakke.OutRoutninger,
                            indbakke.OutAntalDTRO,
                            gridOnlineStatistik);
                        OnlineStatistikIndex++;
                        labelOnlineStatistikType.Text = "DokumentType x Routninger";
                        break;
                    case 1:
                        OpdaterMatrixGrid(
                            "DokumentType",
                            indbakke.OutDokumenttyper,
                            indbakke.OutModtagerAdresser,
                            indbakke.OutAntalDTMA,
                            gridOnlineStatistik);
                        OnlineStatistikIndex++;
                        labelOnlineStatistikType.Text = "DokumentType x ModtagerAdresse";
                        break;
                    case 2:
                        OpdaterMatrixGrid(
                            "Routning",
                            indbakke.OutRoutninger,
                            indbakke.OutModtagerAdresser,
                            indbakke.OutAntalROMA,
                            gridOnlineStatistik);
                        OnlineStatistikIndex = 0;
                        labelOnlineStatistikType.Text = "Routninger x ModtagerAdresse";
                        break;
                }
            }
            catch (Exception)
            {
            }
        }


        private void cmdNaesteStatistik_Click(object sender, EventArgs e)
        {
            // rul rundt igennem de tre visninger
            try
            {
                switch (StatistikIndex)
                {
                    case 0:
                        OpdaterMatrixGrid(
                            "Dato",
                            indbakke.OutDatoer,
                            indbakke.OutModtagerAdresser,
                            indbakke.OutAntalDatoMA,
                            gridStatistik);
                        StatistikIndex++;
                        labelStatistikType.Text = "Modtageradresser";
                        break;
                    case 1:
                        OpdaterMatrixGrid(
                            "Dato",
                            indbakke.OutDatoer,
                            indbakke.OutDokumenttyper,
                            indbakke.OutAntalDatoDT,
                            gridStatistik);
                        StatistikIndex++;
                        labelStatistikType.Text = "Dokumenttyper";
                        break;
                    case 2:
                        OpdaterMatrixGrid(
                            "Dato",
                            indbakke.OutDatoer,
                            indbakke.OutRoutninger,
                            indbakke.OutAntalDatoRO,
                            gridStatistik);
                        StatistikIndex = 0;
                        labelStatistikType.Text = "Routninger";
                        break;
                }
            }
            catch (Exception)
            {
            }
        }

        private void knapAfstemning_Click(object sender, EventArgs e)
        {
            titelAfstemning.Text = "Afstemningsrapport for central skanning";
            createdAfstemning.Text = "Opgjort per den: " + DateTime.Now.ToString();
            knapAfstemning.UseWaitCursor = true;

            // Nulstil rapportering
            datagridAfstemning.Rows.Clear();
            dataGridDifferenceliste.Rows.Clear();

            // Find dato og konverter til metadata format for C&I
            string dato = datoAfstemning.Text.Trim();
            dato = dato.Replace(" ", "-");
            dato = dato.Replace(".", "");
            dato = dato.Replace("januar", "01");
            dato = dato.Replace("februar", "02");
            dato = dato.Replace("marts", "03");
            dato = dato.Replace("april", "04");
            dato = dato.Replace("maj", "05");
            dato = dato.Replace("juni", "06");
            dato = dato.Replace("juli", "07");
            dato = dato.Replace("august", "08");
            dato = dato.Replace("september", "09");
            dato = dato.Replace("oktober", "10");
            dato = dato.Replace("november", "11");
            dato = dato.Replace("december", "12");

            PostFordelerLib.Afstemning afstem = new PostFordelerLib.Afstemning(new PostFordelerLib.Konfiguration(miljoe));

            string[] datarow = new string[2];
            // Antal skannede sager
            // Manuelt trin og skal udfyldes af sagsbehandler
            datarow[0] = "Antal skannede sager";
            datagridAfstemning.Rows.Add(datarow);

            // Sager behandlet flere gange
            // Det er ikke præcist defineret og vil skulle rettes på baggrund af testen
            // Iæsr bør vi være opmærksom på fejlfordelt post og p-pladser
            datarow[0] = "Sager behandlet flere gange";
            datagridAfstemning.Rows.Add(datarow);

            // Maskinel afstemning
            // Linie 1 : Tæl alle xml og tiff filer under input struktur
            // <System id="C og I" rodmappe="c:\PostFordelerTest\TestProg\Udbakker" />
            datarow[0] = "C&I sager ubehandlet";
            datarow[1] = "" + afstem.SagerUbehandletCI(dato, dataGridDifferenceliste);
            datagridAfstemning.Rows.Add(datarow);

            datarow[0] = "C&I sager behandlet";
            datarow[1] = "" + afstem.SagerBehandletCI(dato, dataGridDifferenceliste);
            datagridAfstemning.Rows.Add(datarow);

            // Rapporter fejlet xml i mappen fejl
            datarow[0] = "Postfordeler sager fejlet";
            datarow[1] = "" + afstem.SagerFejlbehandletPostFordeler(dato, dataGridDifferenceliste);
            datagridAfstemning.Rows.Add(datarow);

            // Rapporter manglende xml / tiff filer
            datarow[0] = "Postfordeler sager ubehandlet";
            datarow[1] = "" + afstem.SagerUbehandletPostFordeler(dato, dataGridDifferenceliste);
            datagridAfstemning.Rows.Add(datarow);
            datarow[0] = "Postfordeler sager behandlet";
            datarow[1] = "" + afstem.SagerBehandletPostFordeler(dato, dataGridDifferenceliste);
            datagridAfstemning.Rows.Add(datarow);

            // Total for dagens afstemning
            // Manuelt trin
            datarow[0] = "Total for dagens afstemning";
            datarow[1] = "";
            datagridAfstemning.Rows.Add(datarow);

            // Difference for dagens afstemning (Dette udgør indholdet til Differencelisten)
            datarow[0] = "Difference for dagens afstemning";
            datagridAfstemning.Rows.Add(datarow);

            afstem.finish();
            knapAfstemning.UseWaitCursor = false;
        }

        // Printer afstemningsskærmbillede ved at klikke på kanppen print
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        private static extern bool BitBlt
        (
            IntPtr hdcDest, // handle to destination DC
            int nXDest, // x-coord of destination upper-left corner
            int nYDest, // y-coord of destination upper-left corner
            int nWidth, // width of destination rectangle
            int nHeight, // height of destination rectangle
            IntPtr hdcSrc, // handle to source DC
            int nXSrc, // x-coordinate of source upper-left corner
            int nYSrc, // y-coordinate of source upper-left corner
            System.Int32 dwRop // raster operation code
        );

        /* Kode til skærmdump på printer
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            System.Drawing.Image image = System.Drawing.Image.FromStream(this.streamToPrint);

            int x = e.MarginBounds.X;
            int y = e.MarginBounds.Y;
            int width = image.Width;
            int height = image.Height;
            if ((width / e.MarginBounds.Width) > (height / e.MarginBounds.Height))
            {
                width = e.MarginBounds.Width;
                height = image.Height * e.MarginBounds.Width / image.Width;
            }
            else
            {
                height = e.MarginBounds.Height;
                width = image.Width * e.MarginBounds.Height / image.Height;
            }

            System.Drawing.Rectangle destRect = new System.Drawing.Rectangle(x, y, width, height);
            e.Graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, System.Drawing.GraphicsUnit.Pixel);
        }

        string streamType;
        private System.IO.Stream streamToPrint;
        public void StartPrint(Stream streamToPrint, string streamType)
        {
            this.printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            this.streamToPrint = streamToPrint;
            this.streamType = streamType;
            System.Windows.Forms.PrintDialog PrintDialog1 = new PrintDialog();
            PrintDialog1.AllowSomePages = true;
            PrintDialog1.ShowHelp = true;
            PrintDialog1.Document = printDocument1;
            DialogResult result = PrintDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                printDocument1.Print();
                //docToPrint.Print();
            }
        }

        private void printAfstemning_Click(object sender, EventArgs e)
        {
            Graphics g1 = this.CreateGraphics();
            Image MyImage = new Bitmap(this.ClientRectangle.Width, this.ClientRectangle.Height, g1);

            Graphics g2 = Graphics.FromImage(MyImage);
            IntPtr dc1 = g1.GetHdc();
            IntPtr dc2 = g2.GetHdc();

            BitBlt(dc2, 0, 0, this.ClientRectangle.Width, this.ClientRectangle.Height, dc1, 0, 0, 13369376);
            g1.ReleaseHdc(dc1);
            g2.ReleaseHdc(dc2);
            MyImage.Save(@"c:\PrintPage.jpg", ImageFormat.Jpeg);

            FileStream fileStream = new FileStream(@"c:\PrintPage.jpg", FileMode.Open, FileAccess.Read);
            StartPrint(fileStream, "Image");
            fileStream.Close();
            if (System.IO.File.Exists(@"c:\PrintPage.jpg"))
            {
                System.IO.File.Delete(@"c:\PrintPage.jpg");
            }
        }*/

        private float linesPerPage = 70;
        private float yPosition = 0;
        private int count = 0;
        private float leftMargin = 0;
        private float topMargin = 0;
        private string line = null;
        private SolidBrush myBrush = new SolidBrush(Color.Black);
        private bool printHeaderDone = false;

        private void printHeader(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            // Sætter stor overskrift font til første linie
            printFont = this.titelAfstemning.Font;

            string strToPrint = "";
            // Titel
            strToPrint += titelAfstemning.Text + "\n\n\n";
            // Undertitel
            strToPrint += createdAfstemning.Text + "\n";

            strToPrint += "---------------------------------------------------------------------\n";

            myReader = new StringReader(strToPrint);

            // Work out the number of lines per page, using the MarginBounds.
            // linesPerPage = e.MarginBounds.Height / printFont.GetHeight(e.Graphics);
            // Iterate over the string using the StringReader, printing each line.
            while (count < linesPerPage && ((line = myReader.ReadLine()) != null))
            {
                // calculate the next line position based on the height of the font according to the printing device
                yPosition = topMargin + (count * printFont.GetHeight(e.Graphics)) + 5;
                // draw the next line in the rich edit control
                e.Graphics.DrawString(line, printFont, myBrush, leftMargin, yPosition, new StringFormat());
                count++;
                // Sætter normal font til efterfølgende data
                printFont = this.createdAfstemning.Font;
            }
            if (line == null) printHeaderDone = true;
        }

        private void printRapport(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            float centerPosition = e.MarginBounds.Width / 2;
            int lineCounter = 0;
            foreach (HashSet<string> rt in rapportListe) 
            {
                if (count >= linesPerPage) break;
                // calculate the next line position based on the height of the font according to the printing device
                yPosition = topMargin + (count * printFont.GetHeight(e.Graphics)) + 5;
                // draw the next line in the rich edit control
                e.Graphics.DrawString(rt.ElementAt(0) , printFont, myBrush, leftMargin, yPosition, new StringFormat());
                e.Graphics.DrawString(rt.ElementAt(1), printFont, myBrush, centerPosition, yPosition, new StringFormat());

                lineCounter++;
                count++;
            }
            while (lineCounter > 0)
                rapportListe.RemoveAt(--lineCounter);
            
            yPosition = topMargin + (count * printFont.GetHeight(e.Graphics)) + 5;
            string strToPrint = "---------------------------------------------------------------------\n";
            e.Graphics.DrawString(strToPrint, printFont, myBrush, leftMargin, yPosition, new StringFormat());
            count++;
        }

        private void printDifference(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            float colSize = e.MarginBounds.Width / 4;
            int lineCounter = 0;
            foreach (HashSet<string> rt in differenceListe)
            {
                if (count >= linesPerPage) break;
                // calculate the next line position based on the height of the font according to the printing device
                yPosition = topMargin + (count * printFont.GetHeight(e.Graphics)) + 20;
                // draw the next line in the rich edit control
                e.Graphics.DrawString(rt.ElementAt(0), printFont, myBrush, leftMargin, yPosition, new StringFormat());
                string str = rt.ElementAt(1);
                if (str.Length>20) 
                {
                    int idx = str.Length-20;
                    str = "..." + str.Substring(idx);
                }
                e.Graphics.DrawString(str, printFont, myBrush, leftMargin + colSize, yPosition, new StringFormat());
                e.Graphics.DrawString(rt.ElementAt(2), printFont, myBrush, leftMargin + 2*colSize, yPosition, new StringFormat());
                e.Graphics.DrawString(rt.ElementAt(3), printFont, myBrush, leftMargin + 3*colSize, yPosition, new StringFormat());

                lineCounter++;
                count++;
            }
            while (lineCounter > 0)
                differenceListe.RemoveAt(--lineCounter);
        }

        private Font printFont;        
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            count = 0;
            leftMargin = e.MarginBounds.Left;
            topMargin = e.MarginBounds.Top;
            //line = null;
            myBrush = new SolidBrush(Color.Black);
            //e.PageSettings.Landscape = true;
            e.HasMorePages = false;            

            if (!printHeaderDone) printHeader(sender, e);
            if (rapportListe.Count > 0) printRapport(sender, e);
            if (differenceListe.Count > 0) printDifference(sender, e);
            
            // If there are more lines, print another page.
            if (!printHeaderDone || rapportListe.Count > 0 || differenceListe.Count > 0)
            {
                e.HasMorePages = true;
                yPosition = 0;
            }
            else
                e.HasMorePages = false;
            myBrush.Dispose();
        }
        
        private StringReader myReader;
        private HashSet<string> rapportTabel;
        private List<HashSet<string>> rapportListe = new List<HashSet<string>>();
        private HashSet<string> differenceTabel;
        private List<HashSet<string>> differenceListe = new List<HashSet<string>>();

        private void printAfstemning_Click(object sender, EventArgs e)
        {
            this.printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);

            int countCols = datagridAfstemning.Columns.Count;

            // Data felter rapport
            for (int i = 0; i<datagridAfstemning.RowCount; i++)
            {
                rapportTabel = new HashSet<string>();
                if (i==0) 
                {
                    for (int j = 0; j < countCols; j++)
                    {
                        rapportTabel.Add("" + datagridAfstemning.Columns[j].HeaderText);
                    }
                    rapportListe.Add(rapportTabel);
                    rapportTabel = new HashSet<string>();
                }
                for (int j = 0; j < countCols; j++)
                {
                    rapportTabel.Add("" + datagridAfstemning.Rows[i].Cells[j].Value); 
                    //strToPrint += datagridAfstemning.Rows[i].Cells[j].Value + "\n";
                }
                rapportListe.Add(rapportTabel);                
            }            

            // Header felter differenceliste
            countCols = dataGridDifferenceliste.Columns.Count;

            // Data felter differenceliste
            for (int i = 0; i < dataGridDifferenceliste.RowCount; i++)
            {
                differenceTabel = new HashSet<string>();
                if (i == 0)
                {
                    for (int j = 0; j < countCols; j++)
                    {
                        differenceTabel.Add("" + dataGridDifferenceliste.Columns[j].HeaderText);
                    }
                    differenceListe.Add(differenceTabel);
                    differenceTabel = new HashSet<string>();
                }
                for (int j = 0; j < countCols; j++)
                {
                    differenceTabel.Add("" + dataGridDifferenceliste.Rows[i].Cells[j].Value);
                    //strToPrint += dataGridDifferenceliste.Rows[i].Cells[j].Value + "\n";
                }
                differenceListe.Add(differenceTabel);
            }
                        
            if (printDialog1.ShowDialog() == DialogResult.OK)
            {
                this.printDocument1.Print();                
            }
        }

    }

    // helper functions for .net functions
    public class Common
    {
        public static DataGridViewColumn AddColumn(DataGridView g, string name)
        {
            g.Columns.Add(name, name);
            g.Columns[name].ReadOnly = true;
            g.Columns[name].DefaultCellStyle.BackColor = Color.LightYellow;
            g.Columns[name].DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopLeft;
            return g.Columns[name];
        }

        public static DataGridViewColumn AddColumn2(DataGridView g, string name, DataGridViewContentAlignment a, Color c)
        {
            g.Columns.Add(name, name);
            g.Columns[name].ReadOnly = true;
            g.Columns[name].DefaultCellStyle.BackColor = c;
            g.Columns[name].DefaultCellStyle.Alignment = a;
            return g.Columns[name];
        }
    }
}
