﻿namespace PostFordelerKonsol
{
    partial class PostFordelerKonsol
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cmdBehandlIndbakke = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.AntalFindPost = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboRoutninger = new System.Windows.Forms.ComboBox();
            this.cmdOmplacerManuelt = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtScanID = new System.Windows.Forms.TextBox();
            this.cmdFindPost = new System.Windows.Forms.Button();
            this.gridPostList = new System.Windows.Forms.DataGridView();
            this.Index = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mappe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dato = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DokumentType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ModtagerAdresse = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.URL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.URLTIF = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chkRydOpIIndbakke = new System.Windows.Forms.CheckBox();
            this.chkKopierTilFagsystemmappe = new System.Windows.Forms.CheckBox();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.cmdPrøveBehandling = new System.Windows.Forms.Button();
            this.txtMaxAntalFiler = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.chkKopierTilBehandlet = new System.Windows.Forms.CheckBox();
            this.labelAntal = new System.Windows.Forms.Label();
            this.labelOnlineStatistikType = new System.Windows.Forms.Label();
            this.cmdNaesteOnlineStatistik = new System.Windows.Forms.Button();
            this.splitContainer5 = new System.Windows.Forms.SplitContainer();
            this.gridOnlineStatistik = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.gridLog = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.comboIndbakke = new System.Windows.Forms.ComboBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.cmdVisRoutninger = new System.Windows.Forms.Button();
            this.cmdVisManglendeRoutninger = new System.Windows.Forms.Button();
            this.cmdVisDokumentTyper = new System.Windows.Forms.Button();
            this.cmdVisModtageradresser = new System.Windows.Forms.Button();
            this.cmdVisSystemer = new System.Windows.Forms.Button();
            this.cmdVisregler = new System.Windows.Forms.Button();
            this.gridKonfiguration = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.splitContainer6 = new System.Windows.Forms.SplitContainer();
            this.labelStatistikType = new System.Windows.Forms.Label();
            this.cmdNaesteStatistik = new System.Windows.Forms.Button();
            this.labelStatistik = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtStatFraDato = new System.Windows.Forms.TextBox();
            this.txtStatTilDato = new System.Windows.Forms.TextBox();
            this.cmdVisStatistik = new System.Windows.Forms.Button();
            this.gridStatistik = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.tabAfstemning = new System.Windows.Forms.TabPage();
            this.splitAfstemning = new System.Windows.Forms.SplitContainer();
            this.printAfstemning = new System.Windows.Forms.Button();
            this.datoAfstemning = new System.Windows.Forms.DateTimePicker();
            this.knapAfstemning = new System.Windows.Forms.Button();
            this.dataGridDifferenceliste = new System.Windows.Forms.DataGridView();
            this.ModtagetDato = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Filnavn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aarsag = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SkanningsId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label7 = new System.Windows.Forms.Label();
            this.createdAfstemning = new System.Windows.Forms.TextBox();
            this.titelAfstemning = new System.Windows.Forms.TextBox();
            this.datagridAfstemning = new System.Windows.Forms.DataGridView();
            this.stedAfstemningKolonne = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xmlAfstemningKolonne = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridPostList)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.tabMain.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.splitContainer5.Panel1.SuspendLayout();
            this.splitContainer5.Panel2.SuspendLayout();
            this.splitContainer5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridOnlineStatistik)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLog)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridKonfiguration)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.splitContainer6.Panel1.SuspendLayout();
            this.splitContainer6.Panel2.SuspendLayout();
            this.splitContainer6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridStatistik)).BeginInit();
            this.tabAfstemning.SuspendLayout();
            this.splitAfstemning.Panel1.SuspendLayout();
            this.splitAfstemning.Panel2.SuspendLayout();
            this.splitAfstemning.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDifferenceliste)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagridAfstemning)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdBehandlIndbakke
            // 
            this.cmdBehandlIndbakke.Location = new System.Drawing.Point(19, 15);
            this.cmdBehandlIndbakke.Margin = new System.Windows.Forms.Padding(4);
            this.cmdBehandlIndbakke.Name = "cmdBehandlIndbakke";
            this.cmdBehandlIndbakke.Size = new System.Drawing.Size(148, 28);
            this.cmdBehandlIndbakke.TabIndex = 0;
            this.cmdBehandlIndbakke.Text = "Behandl indbakke";
            this.cmdBehandlIndbakke.UseVisualStyleBackColor = true;
            this.cmdBehandlIndbakke.Click += new System.EventHandler(this.cmdBehandlIndbakke_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Indbakke";
            // 
            // txtLog
            // 
            this.txtLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLog.Location = new System.Drawing.Point(0, 0);
            this.txtLog.Margin = new System.Windows.Forms.Padding(4);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtLog.Size = new System.Drawing.Size(42, 569);
            this.txtLog.TabIndex = 3;
            this.txtLog.WordWrap = false;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(4, 4);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.AntalFindPost);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.comboRoutninger);
            this.splitContainer1.Panel1.Controls.Add(this.cmdOmplacerManuelt);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.txtScanID);
            this.splitContainer1.Panel1.Controls.Add(this.cmdFindPost);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.gridPostList);
            this.splitContainer1.Size = new System.Drawing.Size(1293, 532);
            this.splitContainer1.SplitterDistance = 85;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 5;
            // 
            // AntalFindPost
            // 
            this.AntalFindPost.AutoSize = true;
            this.AntalFindPost.Location = new System.Drawing.Point(573, 12);
            this.AntalFindPost.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.AntalFindPost.Name = "AntalFindPost";
            this.AntalFindPost.Size = new System.Drawing.Size(0, 17);
            this.AntalFindPost.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 48);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Routning";
            // 
            // comboRoutninger
            // 
            this.comboRoutninger.FormattingEnabled = true;
            this.comboRoutninger.Location = new System.Drawing.Point(105, 44);
            this.comboRoutninger.Margin = new System.Windows.Forms.Padding(4);
            this.comboRoutninger.Name = "comboRoutninger";
            this.comboRoutninger.Size = new System.Drawing.Size(308, 24);
            this.comboRoutninger.TabIndex = 4;
            // 
            // cmdOmplacerManuelt
            // 
            this.cmdOmplacerManuelt.Location = new System.Drawing.Point(423, 42);
            this.cmdOmplacerManuelt.Margin = new System.Windows.Forms.Padding(4);
            this.cmdOmplacerManuelt.Name = "cmdOmplacerManuelt";
            this.cmdOmplacerManuelt.Size = new System.Drawing.Size(143, 28);
            this.cmdOmplacerManuelt.TabIndex = 3;
            this.cmdOmplacerManuelt.Text = "Flyt post";
            this.cmdOmplacerManuelt.UseVisualStyleBackColor = true;
            this.cmdOmplacerManuelt.Click += new System.EventHandler(this.cmdOmplacerManuelt_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 12);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Scanning ID";
            // 
            // txtScanID
            // 
            this.txtScanID.Location = new System.Drawing.Point(105, 9);
            this.txtScanID.Margin = new System.Windows.Forms.Padding(4);
            this.txtScanID.Name = "txtScanID";
            this.txtScanID.Size = new System.Drawing.Size(308, 22);
            this.txtScanID.TabIndex = 1;
            this.txtScanID.Text = "*";
            // 
            // cmdFindPost
            // 
            this.cmdFindPost.Location = new System.Drawing.Point(423, 6);
            this.cmdFindPost.Margin = new System.Windows.Forms.Padding(4);
            this.cmdFindPost.Name = "cmdFindPost";
            this.cmdFindPost.Size = new System.Drawing.Size(143, 28);
            this.cmdFindPost.TabIndex = 0;
            this.cmdFindPost.Text = "Find post";
            this.cmdFindPost.UseVisualStyleBackColor = true;
            this.cmdFindPost.Click += new System.EventHandler(this.cmdFindPost_Click);
            // 
            // gridPostList
            // 
            this.gridPostList.AllowUserToAddRows = false;
            this.gridPostList.AllowUserToDeleteRows = false;
            this.gridPostList.AllowUserToOrderColumns = true;
            this.gridPostList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gridPostList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridPostList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Index,
            this.ID,
            this.Mappe,
            this.Dato,
            this.DokumentType,
            this.ModtagerAdresse,
            this.URL,
            this.URLTIF});
            this.gridPostList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridPostList.Location = new System.Drawing.Point(0, 0);
            this.gridPostList.Margin = new System.Windows.Forms.Padding(4);
            this.gridPostList.Name = "gridPostList";
            this.gridPostList.ReadOnly = true;
            this.gridPostList.RowTemplate.Height = 24;
            this.gridPostList.Size = new System.Drawing.Size(1293, 442);
            this.gridPostList.TabIndex = 5;
            this.gridPostList.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridPostList_CellDoubleClick);
            this.gridPostList.SelectionChanged += new System.EventHandler(this.gridPostList_SelectionChanged);
            this.gridPostList.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridPostList_CellContentClick);
            // 
            // Index
            // 
            this.Index.HeaderText = "Index";
            this.Index.Name = "Index";
            this.Index.ReadOnly = true;
            // 
            // ID
            // 
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            // 
            // Mappe
            // 
            this.Mappe.HeaderText = "Mappe";
            this.Mappe.Name = "Mappe";
            this.Mappe.ReadOnly = true;
            // 
            // Dato
            // 
            this.Dato.HeaderText = "Dato";
            this.Dato.Name = "Dato";
            this.Dato.ReadOnly = true;
            // 
            // DokumentType
            // 
            this.DokumentType.HeaderText = "DokumentType";
            this.DokumentType.Name = "DokumentType";
            this.DokumentType.ReadOnly = true;
            // 
            // ModtagerAdresse
            // 
            this.ModtagerAdresse.HeaderText = "ModtagerAdresse";
            this.ModtagerAdresse.Name = "ModtagerAdresse";
            this.ModtagerAdresse.ReadOnly = true;
            // 
            // URL
            // 
            this.URL.HeaderText = "XML";
            this.URL.Name = "URL";
            this.URL.ReadOnly = true;
            // 
            // URLTIF
            // 
            this.URLTIF.HeaderText = "TIF";
            this.URLTIF.Name = "URLTIF";
            this.URLTIF.ReadOnly = true;
            // 
            // chkRydOpIIndbakke
            // 
            this.chkRydOpIIndbakke.AutoSize = true;
            this.chkRydOpIIndbakke.Location = new System.Drawing.Point(768, 20);
            this.chkRydOpIIndbakke.Margin = new System.Windows.Forms.Padding(4);
            this.chkRydOpIIndbakke.Name = "chkRydOpIIndbakke";
            this.chkRydOpIIndbakke.Size = new System.Drawing.Size(140, 21);
            this.chkRydOpIIndbakke.TabIndex = 6;
            this.chkRydOpIIndbakke.Text = "Ryd op i indbakke";
            this.chkRydOpIIndbakke.UseVisualStyleBackColor = true;
            // 
            // chkKopierTilFagsystemmappe
            // 
            this.chkKopierTilFagsystemmappe.AutoSize = true;
            this.chkKopierTilFagsystemmappe.Checked = true;
            this.chkKopierTilFagsystemmappe.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkKopierTilFagsystemmappe.Location = new System.Drawing.Point(925, 20);
            this.chkKopierTilFagsystemmappe.Margin = new System.Windows.Forms.Padding(4);
            this.chkKopierTilFagsystemmappe.Name = "chkKopierTilFagsystemmappe";
            this.chkKopierTilFagsystemmappe.Size = new System.Drawing.Size(150, 21);
            this.chkKopierTilFagsystemmappe.TabIndex = 7;
            this.chkKopierTilFagsystemmappe.Text = "Kopier til fagsystem";
            this.chkKopierTilFagsystemmappe.UseVisualStyleBackColor = true;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.tabMain);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.txtLog);
            this.splitContainer2.Panel2MinSize = 0;
            this.splitContainer2.Size = new System.Drawing.Size(1356, 569);
            this.splitContainer2.SplitterDistance = 1309;
            this.splitContainer2.SplitterWidth = 5;
            this.splitContainer2.TabIndex = 8;
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabPage1);
            this.tabMain.Controls.Add(this.tabPage2);
            this.tabMain.Controls.Add(this.tabPage3);
            this.tabMain.Controls.Add(this.tabPage4);
            this.tabMain.Controls.Add(this.tabPage5);
            this.tabMain.Controls.Add(this.tabAfstemning);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Margin = new System.Windows.Forms.Padding(4);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(1309, 569);
            this.tabMain.TabIndex = 9;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer3);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1301, 540);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Behandl indbakke";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Resize += new System.EventHandler(this.tabPage1_Resize);
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(4, 4);
            this.splitContainer3.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.cmdPrøveBehandling);
            this.splitContainer3.Panel1.Controls.Add(this.txtMaxAntalFiler);
            this.splitContainer3.Panel1.Controls.Add(this.label4);
            this.splitContainer3.Panel1.Controls.Add(this.chkKopierTilBehandlet);
            this.splitContainer3.Panel1.Controls.Add(this.labelAntal);
            this.splitContainer3.Panel1.Controls.Add(this.labelOnlineStatistikType);
            this.splitContainer3.Panel1.Controls.Add(this.cmdNaesteOnlineStatistik);
            this.splitContainer3.Panel1.Controls.Add(this.cmdBehandlIndbakke);
            this.splitContainer3.Panel1.Controls.Add(this.chkRydOpIIndbakke);
            this.splitContainer3.Panel1.Controls.Add(this.chkKopierTilFagsystemmappe);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.splitContainer5);
            this.splitContainer3.Size = new System.Drawing.Size(1293, 532);
            this.splitContainer3.SplitterDistance = 123;
            this.splitContainer3.SplitterWidth = 5;
            this.splitContainer3.TabIndex = 8;
            // 
            // cmdPrøveBehandling
            // 
            this.cmdPrøveBehandling.Location = new System.Drawing.Point(175, 15);
            this.cmdPrøveBehandling.Margin = new System.Windows.Forms.Padding(4);
            this.cmdPrøveBehandling.Name = "cmdPrøveBehandling";
            this.cmdPrøveBehandling.Size = new System.Drawing.Size(148, 28);
            this.cmdPrøveBehandling.TabIndex = 14;
            this.cmdPrøveBehandling.Text = "Prøvebehandling";
            this.cmdPrøveBehandling.UseVisualStyleBackColor = true;
            this.cmdPrøveBehandling.Click += new System.EventHandler(this.cmdPrøveBehandling_Click);
            // 
            // txtMaxAntalFiler
            // 
            this.txtMaxAntalFiler.Location = new System.Drawing.Point(439, 17);
            this.txtMaxAntalFiler.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaxAntalFiler.Name = "txtMaxAntalFiler";
            this.txtMaxAntalFiler.Size = new System.Drawing.Size(101, 22);
            this.txtMaxAntalFiler.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(331, 21);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 17);
            this.label4.TabIndex = 13;
            this.label4.Text = "Max. antal filer";
            // 
            // chkKopierTilBehandlet
            // 
            this.chkKopierTilBehandlet.AutoSize = true;
            this.chkKopierTilBehandlet.Checked = true;
            this.chkKopierTilBehandlet.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkKopierTilBehandlet.Location = new System.Drawing.Point(1088, 20);
            this.chkKopierTilBehandlet.Margin = new System.Windows.Forms.Padding(4);
            this.chkKopierTilBehandlet.Name = "chkKopierTilBehandlet";
            this.chkKopierTilBehandlet.Size = new System.Drawing.Size(155, 21);
            this.chkKopierTilBehandlet.TabIndex = 12;
            this.chkKopierTilBehandlet.Text = "Kopier til \'behandlet\'";
            this.chkKopierTilBehandlet.UseVisualStyleBackColor = true;
            // 
            // labelAntal
            // 
            this.labelAntal.AutoSize = true;
            this.labelAntal.Location = new System.Drawing.Point(457, 57);
            this.labelAntal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelAntal.Name = "labelAntal";
            this.labelAntal.Size = new System.Drawing.Size(0, 17);
            this.labelAntal.TabIndex = 10;
            // 
            // labelOnlineStatistikType
            // 
            this.labelOnlineStatistikType.AutoSize = true;
            this.labelOnlineStatistikType.Location = new System.Drawing.Point(57, 57);
            this.labelOnlineStatistikType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelOnlineStatistikType.Name = "labelOnlineStatistikType";
            this.labelOnlineStatistikType.Size = new System.Drawing.Size(12, 17);
            this.labelOnlineStatistikType.TabIndex = 9;
            this.labelOnlineStatistikType.Text = " ";
            // 
            // cmdNaesteOnlineStatistik
            // 
            this.cmdNaesteOnlineStatistik.Location = new System.Drawing.Point(19, 50);
            this.cmdNaesteOnlineStatistik.Margin = new System.Windows.Forms.Padding(4);
            this.cmdNaesteOnlineStatistik.Name = "cmdNaesteOnlineStatistik";
            this.cmdNaesteOnlineStatistik.Size = new System.Drawing.Size(31, 28);
            this.cmdNaesteOnlineStatistik.TabIndex = 8;
            this.cmdNaesteOnlineStatistik.Text = ">";
            this.cmdNaesteOnlineStatistik.UseVisualStyleBackColor = true;
            this.cmdNaesteOnlineStatistik.Click += new System.EventHandler(this.cmdNaesteOnlineStatistik_Click);
            // 
            // splitContainer5
            // 
            this.splitContainer5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer5.Location = new System.Drawing.Point(0, 0);
            this.splitContainer5.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer5.Name = "splitContainer5";
            this.splitContainer5.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer5.Panel1
            // 
            this.splitContainer5.Panel1.Controls.Add(this.gridOnlineStatistik);
            // 
            // splitContainer5.Panel2
            // 
            this.splitContainer5.Panel2.Controls.Add(this.gridLog);
            this.splitContainer5.Size = new System.Drawing.Size(1293, 404);
            this.splitContainer5.SplitterDistance = 123;
            this.splitContainer5.SplitterWidth = 5;
            this.splitContainer5.TabIndex = 5;
            // 
            // gridOnlineStatistik
            // 
            this.gridOnlineStatistik.AllowUserToAddRows = false;
            this.gridOnlineStatistik.AllowUserToDeleteRows = false;
            this.gridOnlineStatistik.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gridOnlineStatistik.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridOnlineStatistik.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1});
            this.gridOnlineStatistik.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridOnlineStatistik.Location = new System.Drawing.Point(0, 0);
            this.gridOnlineStatistik.Margin = new System.Windows.Forms.Padding(4);
            this.gridOnlineStatistik.Name = "gridOnlineStatistik";
            this.gridOnlineStatistik.ReadOnly = true;
            this.gridOnlineStatistik.RowTemplate.Height = 24;
            this.gridOnlineStatistik.Size = new System.Drawing.Size(1293, 123);
            this.gridOnlineStatistik.TabIndex = 5;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "DokumentType";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // gridLog
            // 
            this.gridLog.AllowUserToAddRows = false;
            this.gridLog.AllowUserToDeleteRows = false;
            this.gridLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridLog.Location = new System.Drawing.Point(0, 0);
            this.gridLog.Margin = new System.Windows.Forms.Padding(4);
            this.gridLog.Name = "gridLog";
            this.gridLog.ReadOnly = true;
            this.gridLog.RowTemplate.Height = 24;
            this.gridLog.Size = new System.Drawing.Size(1293, 276);
            this.gridLog.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.splitContainer1);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage2.Size = new System.Drawing.Size(1301, 540);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Omplacer post";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Resize += new System.EventHandler(this.tabPage2_Resize);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.comboIndbakke);
            this.tabPage3.Controls.Add(this.label1);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1301, 540);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Skift indbakke";
            this.tabPage3.UseVisualStyleBackColor = true;
            this.tabPage3.Resize += new System.EventHandler(this.tabPage3_Resize);
            // 
            // comboIndbakke
            // 
            this.comboIndbakke.FormattingEnabled = true;
            this.comboIndbakke.Location = new System.Drawing.Point(88, 11);
            this.comboIndbakke.Margin = new System.Windows.Forms.Padding(4);
            this.comboIndbakke.Name = "comboIndbakke";
            this.comboIndbakke.Size = new System.Drawing.Size(160, 24);
            this.comboIndbakke.TabIndex = 4;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.splitContainer4);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1301, 540);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Vis konfiguration";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Resize += new System.EventHandler(this.tabPage4_Resize);
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer4.Name = "splitContainer4";
            this.splitContainer4.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.cmdVisRoutninger);
            this.splitContainer4.Panel1.Controls.Add(this.cmdVisManglendeRoutninger);
            this.splitContainer4.Panel1.Controls.Add(this.cmdVisDokumentTyper);
            this.splitContainer4.Panel1.Controls.Add(this.cmdVisModtageradresser);
            this.splitContainer4.Panel1.Controls.Add(this.cmdVisSystemer);
            this.splitContainer4.Panel1.Controls.Add(this.cmdVisregler);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.gridKonfiguration);
            this.splitContainer4.Size = new System.Drawing.Size(1301, 540);
            this.splitContainer4.SplitterDistance = 85;
            this.splitContainer4.SplitterWidth = 5;
            this.splitContainer4.TabIndex = 0;
            // 
            // cmdVisRoutninger
            // 
            this.cmdVisRoutninger.Location = new System.Drawing.Point(595, 14);
            this.cmdVisRoutninger.Margin = new System.Windows.Forms.Padding(4);
            this.cmdVisRoutninger.Name = "cmdVisRoutninger";
            this.cmdVisRoutninger.Size = new System.Drawing.Size(164, 28);
            this.cmdVisRoutninger.TabIndex = 10;
            this.cmdVisRoutninger.Text = "Vis routninger";
            this.cmdVisRoutninger.UseVisualStyleBackColor = true;
            this.cmdVisRoutninger.Click += new System.EventHandler(this.cmdVisRoutninger_Click);
            // 
            // cmdVisManglendeRoutninger
            // 
            this.cmdVisManglendeRoutninger.Location = new System.Drawing.Point(767, 14);
            this.cmdVisManglendeRoutninger.Margin = new System.Windows.Forms.Padding(4);
            this.cmdVisManglendeRoutninger.Name = "cmdVisManglendeRoutninger";
            this.cmdVisManglendeRoutninger.Size = new System.Drawing.Size(164, 28);
            this.cmdVisManglendeRoutninger.TabIndex = 9;
            this.cmdVisManglendeRoutninger.Text = "Vis mgl. regler";
            this.cmdVisManglendeRoutninger.UseVisualStyleBackColor = true;
            this.cmdVisManglendeRoutninger.Click += new System.EventHandler(this.cmdVisManglendeRegler_Click);
            // 
            // cmdVisDokumentTyper
            // 
            this.cmdVisDokumentTyper.Location = new System.Drawing.Point(423, 14);
            this.cmdVisDokumentTyper.Margin = new System.Windows.Forms.Padding(4);
            this.cmdVisDokumentTyper.Name = "cmdVisDokumentTyper";
            this.cmdVisDokumentTyper.Size = new System.Drawing.Size(164, 28);
            this.cmdVisDokumentTyper.TabIndex = 7;
            this.cmdVisDokumentTyper.Text = "Vis dokumenttyper";
            this.cmdVisDokumentTyper.UseVisualStyleBackColor = true;
            this.cmdVisDokumentTyper.Click += new System.EventHandler(this.cmdVisDokumentTyper_Click);
            // 
            // cmdVisModtageradresser
            // 
            this.cmdVisModtageradresser.Location = new System.Drawing.Point(251, 14);
            this.cmdVisModtageradresser.Margin = new System.Windows.Forms.Padding(4);
            this.cmdVisModtageradresser.Name = "cmdVisModtageradresser";
            this.cmdVisModtageradresser.Size = new System.Drawing.Size(164, 28);
            this.cmdVisModtageradresser.TabIndex = 6;
            this.cmdVisModtageradresser.Text = "Vis modtageradresser";
            this.cmdVisModtageradresser.UseVisualStyleBackColor = true;
            this.cmdVisModtageradresser.Click += new System.EventHandler(this.cmdVisModtageradresser_Click);
            // 
            // cmdVisSystemer
            // 
            this.cmdVisSystemer.Location = new System.Drawing.Point(143, 14);
            this.cmdVisSystemer.Margin = new System.Windows.Forms.Padding(4);
            this.cmdVisSystemer.Name = "cmdVisSystemer";
            this.cmdVisSystemer.Size = new System.Drawing.Size(100, 28);
            this.cmdVisSystemer.TabIndex = 5;
            this.cmdVisSystemer.Text = "Vis systemer";
            this.cmdVisSystemer.UseVisualStyleBackColor = true;
            this.cmdVisSystemer.Click += new System.EventHandler(this.cmdVisSystemer_Click);
            // 
            // cmdVisregler
            // 
            this.cmdVisregler.Location = new System.Drawing.Point(11, 14);
            this.cmdVisregler.Margin = new System.Windows.Forms.Padding(4);
            this.cmdVisregler.Name = "cmdVisregler";
            this.cmdVisregler.Size = new System.Drawing.Size(124, 28);
            this.cmdVisregler.TabIndex = 0;
            this.cmdVisregler.Text = "Vis regler";
            this.cmdVisregler.UseVisualStyleBackColor = true;
            this.cmdVisregler.Click += new System.EventHandler(this.cmdVisregler_Click);
            // 
            // gridKonfiguration
            // 
            this.gridKonfiguration.AllowUserToAddRows = false;
            this.gridKonfiguration.AllowUserToDeleteRows = false;
            this.gridKonfiguration.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridKonfiguration.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridKonfiguration.Location = new System.Drawing.Point(0, 0);
            this.gridKonfiguration.Margin = new System.Windows.Forms.Padding(4);
            this.gridKonfiguration.Name = "gridKonfiguration";
            this.gridKonfiguration.ReadOnly = true;
            this.gridKonfiguration.RowTemplate.Height = 24;
            this.gridKonfiguration.Size = new System.Drawing.Size(1301, 450);
            this.gridKonfiguration.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.splitContainer6);
            this.tabPage5.Controls.Add(this.splitter1);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1301, 540);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Vis statistik";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // splitContainer6
            // 
            this.splitContainer6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer6.Location = new System.Drawing.Point(4, 0);
            this.splitContainer6.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer6.Name = "splitContainer6";
            this.splitContainer6.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer6.Panel1
            // 
            this.splitContainer6.Panel1.Controls.Add(this.labelStatistikType);
            this.splitContainer6.Panel1.Controls.Add(this.cmdNaesteStatistik);
            this.splitContainer6.Panel1.Controls.Add(this.labelStatistik);
            this.splitContainer6.Panel1.Controls.Add(this.label6);
            this.splitContainer6.Panel1.Controls.Add(this.label5);
            this.splitContainer6.Panel1.Controls.Add(this.txtStatFraDato);
            this.splitContainer6.Panel1.Controls.Add(this.txtStatTilDato);
            this.splitContainer6.Panel1.Controls.Add(this.cmdVisStatistik);
            // 
            // splitContainer6.Panel2
            // 
            this.splitContainer6.Panel2.Controls.Add(this.gridStatistik);
            this.splitContainer6.Size = new System.Drawing.Size(1297, 540);
            this.splitContainer6.SplitterDistance = 83;
            this.splitContainer6.SplitterWidth = 5;
            this.splitContainer6.TabIndex = 1;
            // 
            // labelStatistikType
            // 
            this.labelStatistikType.AutoSize = true;
            this.labelStatistikType.Location = new System.Drawing.Point(51, 50);
            this.labelStatistikType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelStatistikType.Name = "labelStatistikType";
            this.labelStatistikType.Size = new System.Drawing.Size(12, 17);
            this.labelStatistikType.TabIndex = 12;
            this.labelStatistikType.Text = " ";
            // 
            // cmdNaesteStatistik
            // 
            this.cmdNaesteStatistik.Location = new System.Drawing.Point(12, 44);
            this.cmdNaesteStatistik.Margin = new System.Windows.Forms.Padding(4);
            this.cmdNaesteStatistik.Name = "cmdNaesteStatistik";
            this.cmdNaesteStatistik.Size = new System.Drawing.Size(31, 28);
            this.cmdNaesteStatistik.TabIndex = 11;
            this.cmdNaesteStatistik.Text = ">";
            this.cmdNaesteStatistik.UseVisualStyleBackColor = true;
            this.cmdNaesteStatistik.Click += new System.EventHandler(this.cmdNaesteStatistik_Click);
            // 
            // labelStatistik
            // 
            this.labelStatistik.AutoSize = true;
            this.labelStatistik.Location = new System.Drawing.Point(51, 57);
            this.labelStatistik.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelStatistik.Name = "labelStatistik";
            this.labelStatistik.Size = new System.Drawing.Size(12, 17);
            this.labelStatistik.TabIndex = 10;
            this.labelStatistik.Text = " ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 17);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Datointerval";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(205, 17);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "-";
            // 
            // txtStatFraDato
            // 
            this.txtStatFraDato.Location = new System.Drawing.Point(101, 14);
            this.txtStatFraDato.Margin = new System.Windows.Forms.Padding(4);
            this.txtStatFraDato.Name = "txtStatFraDato";
            this.txtStatFraDato.Size = new System.Drawing.Size(95, 22);
            this.txtStatFraDato.TabIndex = 3;
            // 
            // txtStatTilDato
            // 
            this.txtStatTilDato.Location = new System.Drawing.Point(227, 14);
            this.txtStatTilDato.Margin = new System.Windows.Forms.Padding(4);
            this.txtStatTilDato.Name = "txtStatTilDato";
            this.txtStatTilDato.Size = new System.Drawing.Size(95, 22);
            this.txtStatTilDato.TabIndex = 2;
            // 
            // cmdVisStatistik
            // 
            this.cmdVisStatistik.Location = new System.Drawing.Point(331, 11);
            this.cmdVisStatistik.Margin = new System.Windows.Forms.Padding(4);
            this.cmdVisStatistik.Name = "cmdVisStatistik";
            this.cmdVisStatistik.Size = new System.Drawing.Size(124, 28);
            this.cmdVisStatistik.TabIndex = 1;
            this.cmdVisStatistik.Text = "Vis statistik";
            this.cmdVisStatistik.UseVisualStyleBackColor = true;
            this.cmdVisStatistik.Click += new System.EventHandler(this.cmdVisStatistik_Click);
            // 
            // gridStatistik
            // 
            this.gridStatistik.AllowUserToAddRows = false;
            this.gridStatistik.AllowUserToDeleteRows = false;
            this.gridStatistik.AllowUserToOrderColumns = true;
            this.gridStatistik.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gridStatistik.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridStatistik.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5});
            this.gridStatistik.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridStatistik.Location = new System.Drawing.Point(0, 0);
            this.gridStatistik.Margin = new System.Windows.Forms.Padding(4);
            this.gridStatistik.Name = "gridStatistik";
            this.gridStatistik.ReadOnly = true;
            this.gridStatistik.RowTemplate.Height = 24;
            this.gridStatistik.Size = new System.Drawing.Size(1297, 452);
            this.gridStatistik.TabIndex = 6;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopRight;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewTextBoxColumn5.HeaderText = "DokumentType";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Margin = new System.Windows.Forms.Padding(4);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(4, 540);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // tabAfstemning
            // 
            this.tabAfstemning.Controls.Add(this.splitAfstemning);
            this.tabAfstemning.Location = new System.Drawing.Point(4, 25);
            this.tabAfstemning.Name = "tabAfstemning";
            this.tabAfstemning.Padding = new System.Windows.Forms.Padding(3);
            this.tabAfstemning.Size = new System.Drawing.Size(1301, 540);
            this.tabAfstemning.TabIndex = 5;
            this.tabAfstemning.Text = "Afstemning";
            this.tabAfstemning.UseVisualStyleBackColor = true;
            // 
            // splitAfstemning
            // 
            this.splitAfstemning.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitAfstemning.Location = new System.Drawing.Point(3, 3);
            this.splitAfstemning.Name = "splitAfstemning";
            this.splitAfstemning.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitAfstemning.Panel1
            // 
            this.splitAfstemning.Panel1.Controls.Add(this.printAfstemning);
            this.splitAfstemning.Panel1.Controls.Add(this.datoAfstemning);
            this.splitAfstemning.Panel1.Controls.Add(this.knapAfstemning);
            // 
            // splitAfstemning.Panel2
            // 
            this.splitAfstemning.Panel2.Controls.Add(this.dataGridDifferenceliste);
            this.splitAfstemning.Panel2.Controls.Add(this.label7);
            this.splitAfstemning.Panel2.Controls.Add(this.createdAfstemning);
            this.splitAfstemning.Panel2.Controls.Add(this.titelAfstemning);
            this.splitAfstemning.Panel2.Controls.Add(this.datagridAfstemning);
            this.splitAfstemning.Size = new System.Drawing.Size(1295, 534);
            this.splitAfstemning.SplitterDistance = 64;
            this.splitAfstemning.TabIndex = 0;
            // 
            // printAfstemning
            // 
            this.printAfstemning.Location = new System.Drawing.Point(1121, 21);
            this.printAfstemning.Name = "printAfstemning";
            this.printAfstemning.Size = new System.Drawing.Size(75, 23);
            this.printAfstemning.TabIndex = 3;
            this.printAfstemning.Text = "Print";
            this.printAfstemning.UseVisualStyleBackColor = true;
            this.printAfstemning.Click += new System.EventHandler(this.printAfstemning_Click);
            // 
            // datoAfstemning
            // 
            this.datoAfstemning.Location = new System.Drawing.Point(15, 21);
            this.datoAfstemning.Name = "datoAfstemning";
            this.datoAfstemning.Size = new System.Drawing.Size(200, 22);
            this.datoAfstemning.TabIndex = 2;
            // 
            // knapAfstemning
            // 
            this.knapAfstemning.Location = new System.Drawing.Point(230, 21);
            this.knapAfstemning.Name = "knapAfstemning";
            this.knapAfstemning.Size = new System.Drawing.Size(152, 23);
            this.knapAfstemning.TabIndex = 0;
            this.knapAfstemning.Text = "Dan afstemning";
            this.knapAfstemning.UseVisualStyleBackColor = true;
            this.knapAfstemning.Click += new System.EventHandler(this.knapAfstemning_Click);
            // 
            // dataGridDifferenceliste
            // 
            this.dataGridDifferenceliste.AllowUserToAddRows = false;
            this.dataGridDifferenceliste.AllowUserToDeleteRows = false;
            this.dataGridDifferenceliste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridDifferenceliste.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ModtagetDato,
            this.Filnavn,
            this.aarsag,
            this.SkanningsId});
            this.dataGridDifferenceliste.Location = new System.Drawing.Point(24, 332);
            this.dataGridDifferenceliste.Name = "dataGridDifferenceliste";
            this.dataGridDifferenceliste.ReadOnly = true;
            this.dataGridDifferenceliste.RowTemplate.Height = 24;
            this.dataGridDifferenceliste.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridDifferenceliste.Size = new System.Drawing.Size(1247, 131);
            this.dataGridDifferenceliste.TabIndex = 5;
            // 
            // ModtagetDato
            // 
            this.ModtagetDato.HeaderText = "Modtaget dato";
            this.ModtagetDato.Name = "ModtagetDato";
            this.ModtagetDato.ReadOnly = true;
            // 
            // Filnavn
            // 
            this.Filnavn.HeaderText = "Filnavn";
            this.Filnavn.Name = "Filnavn";
            this.Filnavn.ReadOnly = true;
            // 
            // aarsag
            // 
            this.aarsag.HeaderText = "Årsag";
            this.aarsag.Name = "aarsag";
            this.aarsag.ReadOnly = true;
            // 
            // SkanningsId
            // 
            this.SkanningsId.HeaderText = "SkanningsId";
            this.SkanningsId.Name = "SkanningsId";
            this.SkanningsId.ReadOnly = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 308);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 17);
            this.label7.TabIndex = 4;
            this.label7.Text = "Differenceliste";
            // 
            // createdAfstemning
            // 
            this.createdAfstemning.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.createdAfstemning.Location = new System.Drawing.Point(24, 52);
            this.createdAfstemning.Name = "createdAfstemning";
            this.createdAfstemning.Size = new System.Drawing.Size(671, 22);
            this.createdAfstemning.TabIndex = 2;
            this.createdAfstemning.Text = "Opgjort per den: ";
            // 
            // titelAfstemning
            // 
            this.titelAfstemning.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.titelAfstemning.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.titelAfstemning.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titelAfstemning.Location = new System.Drawing.Point(24, 3);
            this.titelAfstemning.Name = "titelAfstemning";
            this.titelAfstemning.Size = new System.Drawing.Size(1247, 45);
            this.titelAfstemning.TabIndex = 1;
            this.titelAfstemning.Text = "Afstemningsrapport";
            // 
            // datagridAfstemning
            // 
            this.datagridAfstemning.AllowUserToAddRows = false;
            this.datagridAfstemning.AllowUserToDeleteRows = false;
            this.datagridAfstemning.AllowUserToOrderColumns = true;
            this.datagridAfstemning.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.datagridAfstemning.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridAfstemning.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stedAfstemningKolonne,
            this.xmlAfstemningKolonne});
            this.datagridAfstemning.Location = new System.Drawing.Point(24, 80);
            this.datagridAfstemning.Name = "datagridAfstemning";
            this.datagridAfstemning.ReadOnly = true;
            this.datagridAfstemning.RowTemplate.Height = 24;
            this.datagridAfstemning.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.datagridAfstemning.Size = new System.Drawing.Size(1247, 221);
            this.datagridAfstemning.TabIndex = 0;
            this.datagridAfstemning.UseWaitCursor = true;
            // 
            // stedAfstemningKolonne
            // 
            this.stedAfstemningKolonne.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.stedAfstemningKolonne.HeaderText = "Kilde";
            this.stedAfstemningKolonne.Name = "stedAfstemningKolonne";
            this.stedAfstemningKolonne.ReadOnly = true;
            this.stedAfstemningKolonne.Width = 64;
            // 
            // xmlAfstemningKolonne
            // 
            this.xmlAfstemningKolonne.HeaderText = "XML";
            this.xmlAfstemningKolonne.Name = "xmlAfstemningKolonne";
            this.xmlAfstemningKolonne.ReadOnly = true;
            // 
            // printDialog1
            // 
            this.printDialog1.Document = this.printDocument1;
            this.printDialog1.UseEXDialog = true;
            // 
            // PostFordelerKonsol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1356, 569);
            this.Controls.Add(this.splitContainer2);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "PostFordelerKonsol";
            this.Text = "PostFordeler v1.4.2";
            this.Load += new System.EventHandler(this.PostFordelerKonsol_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridPostList)).EndInit();
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            this.splitContainer2.ResumeLayout(false);
            this.tabMain.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer5.Panel1.ResumeLayout(false);
            this.splitContainer5.Panel2.ResumeLayout(false);
            this.splitContainer5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridOnlineStatistik)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLog)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridKonfiguration)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.splitContainer6.Panel1.ResumeLayout(false);
            this.splitContainer6.Panel1.PerformLayout();
            this.splitContainer6.Panel2.ResumeLayout(false);
            this.splitContainer6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridStatistik)).EndInit();
            this.tabAfstemning.ResumeLayout(false);
            this.splitAfstemning.Panel1.ResumeLayout(false);
            this.splitAfstemning.Panel2.ResumeLayout(false);
            this.splitAfstemning.Panel2.PerformLayout();
            this.splitAfstemning.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridDifferenceliste)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagridAfstemning)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cmdBehandlIndbakke;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.CheckBox chkRydOpIIndbakke;
        private System.Windows.Forms.CheckBox chkKopierTilFagsystemmappe;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button cmdOmplacerManuelt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtScanID;
        private System.Windows.Forms.Button cmdFindPost;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.DataGridView gridPostList;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboRoutninger;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.DataGridView gridKonfiguration;
        private System.Windows.Forms.Button cmdVisregler;
        private System.Windows.Forms.Button cmdNaesteOnlineStatistik;
        private System.Windows.Forms.Label labelOnlineStatistikType;
        private System.Windows.Forms.Button cmdVisSystemer;
        private System.Windows.Forms.Button cmdVisModtageradresser;
        private System.Windows.Forms.Button cmdVisDokumentTyper;

        private System.Windows.Forms.SplitContainer splitContainer5;
        private System.Windows.Forms.DataGridView gridOnlineStatistik;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridView gridLog;
        private System.Windows.Forms.Label labelAntal;
        private System.Windows.Forms.CheckBox chkKopierTilBehandlet;
        private System.Windows.Forms.Button cmdVisManglendeRoutninger;
        private System.Windows.Forms.ComboBox comboIndbakke;
        private System.Windows.Forms.TextBox txtMaxAntalFiler;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label AntalFindPost;
        private System.Windows.Forms.Button cmdPrøveBehandling;
        private System.Windows.Forms.DataGridViewTextBoxColumn Index;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mappe;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dato;
        private System.Windows.Forms.DataGridViewTextBoxColumn DokumentType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ModtagerAdresse;
        private System.Windows.Forms.DataGridViewTextBoxColumn URL;
        private System.Windows.Forms.DataGridViewTextBoxColumn URLTIF;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.SplitContainer splitContainer6;
        private System.Windows.Forms.TextBox txtStatFraDato;
        private System.Windows.Forms.TextBox txtStatTilDato;
        private System.Windows.Forms.Button cmdVisStatistik;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView gridStatistik;
        private System.Windows.Forms.Label labelStatistik;
        private System.Windows.Forms.Button cmdVisRoutninger;
        private System.Windows.Forms.Label labelStatistikType;
        private System.Windows.Forms.Button cmdNaesteStatistik;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.TabPage tabAfstemning;
        private System.Windows.Forms.SplitContainer splitAfstemning;
        private System.Windows.Forms.Button knapAfstemning;
        private System.Windows.Forms.DateTimePicker datoAfstemning;
        private System.Windows.Forms.DataGridView datagridAfstemning;
        private System.Windows.Forms.TextBox titelAfstemning;
        private System.Windows.Forms.TextBox createdAfstemning;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridDifferenceliste;
        private System.Windows.Forms.DataGridViewTextBoxColumn stedAfstemningKolonne;
        private System.Windows.Forms.DataGridViewTextBoxColumn xmlAfstemningKolonne;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Button printAfstemning;
        private System.Windows.Forms.DataGridViewTextBoxColumn ModtagetDato;
        private System.Windows.Forms.DataGridViewTextBoxColumn Filnavn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aarsag;
        private System.Windows.Forms.DataGridViewTextBoxColumn SkanningsId;
    }
}

