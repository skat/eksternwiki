Eksempelfiler mht digitale signaturer i e-TL

Data er primært fiktive, men signaturer er valide.
Hver fil fra b til f er tilført yderligere en underskrift, herunder
tilpasninger i anmelderinformation, uden at de tidligere påførte invalideres.

NB! Reformattering af xml'en kan invalidere signaturene!  


a_anmeldelse_ejerpantebrev.xml

Indeholder et konstrueret eksempel på en anmeldelse til
oprettelse af et ejerpantebrev.


b_fuldmagtssignatur.xml

Anmeldelsen påført en VOCES-signature vha fuldmagt.
Der er tilføjet et element i anmelderordningsamling, som signaturen refererer via ID.


c_anmelderordningsignatur.xml

Tilføjet yderligere en VOCES-signature vha anmelderordning
Der er tilføjet et element i fuldmagtordningsamling, som signaturen refererer via ID.


d_s2s_disponeringsignatur.xml

Tilføjet yderligere en VOCES-signature, hvor S2S-anmelder selv disponerer
Der er ellers ikke tilføjet nye elementer i anmeldelsen.


e_opensignsignatur.xml

Tilføjet en konstrueret UnderskriftmappeSignatur, som signaturen refererer via ID.
Komplet indlejret ligger OpenSign-signeringsblokken Base64-encode (taget fra opensign-signature.xml)
Heri ligger igen bla. XSLT-ref, samt pt den komplette XML-anmeldelse Base64-encoded


f_anmeldersignatur.xml

Sidste trin er påførsel af en anmeldersignatur


opensign-signature.xml

Eksempel konstrueret med OpenSign applet v1.6, underskrevet med POCES, PIDTestBruger2.pfx.
Denne er inlejret i e_opensignsignatur.xml's UnderskriftsmappeSignatur-element


PIDTestBruger2.pfx

POCES-test-certifikat fra http://www.certifikat.dk/developer


TestVOCES1.pfx

VOCES-test-certifikat fra http://www.certifikat.dk/developer
