OIOXML Schema for eTL
til brug for System-til-system snitflade

Generelt
....

Versionering

Se separat beskrivelse for eTL-S2S.
Major-version - første tal i versionsnumre - er lig med nummeret i namespace, fx ../tingbog/1/.
Minor vedrører mindre justeringer, som ikke har krævet nyt namespace.
Build-nummer anvendes højst til bugfixes i test. Der er ikke umiddelbart nogen garanti for ændringens
omgang, i det fuld
XSD-versionering ikke altid honoreres i testfasen.


Folder-struktur

schema - domænedelen af eTL, dvs datamodellen - eller de mest stabile dele af OIO for tinglysning.
 - anmeldelse - schemaer specifikt for anmeldelser
 - berigelse - vedr. udveksling af berigelsesinformation
 - model - centrale elementer for eTL
 - old - pt at opfatte som deprecated, men vil blive flyttet til over i takt med at operationerne kommer på plads i servicekataloget.
service - WSDL, interfaces og messageformater til e-TL services i S2S-snitfladen
 - binding - her kommer WSDL-filer med endpoint bindings, pt kun et enkelt eksempel (WSDL)
 - interface - beskrivelse af operationer i snitfladen (WSDL)
 - message - beskrivelse af messages til snitfladen, dvs requests og responses
 - policy - kopi af RASP-policy
svarservice - WSDL, interfaces og messageformater til svarservices i S2S-snitfladen
 - binding - her kommer WSDL-filer med endpoint bindings, pt kun et enkelt eksempel (WSDL)
 - interface - beskrivelse af operationer i snitfladen (WSDL)
 - message - beskrivelse af messages til snitfladen, dvs requests og responses

Service-folderne er yderligere underopdelt i bøger jf separat beskrivelse af servicekatalog.
I interface ligger også en folder ved navn 'external'. Denne indeholder snitfladebeskrivelse af den
RASP-service, som eksterne systemer skal implementere for at kunne modtage svar fra eTL.

Folderstrukturen er direkte afspejlet i namespace-navne, således at fx schema->model, major 
version 1 hedder 'http://rep.oio.dk/tinglysning.dk/schema/model/1/' og ligger i isb/schema/model/1-folder

Dette giver mulighed for at bruge XML catalog-rewrite-regler i XML-parser. Efterfølgende releases 
forventes at få erstatet schemalocations med relative stier til fuld OIO-ISB-sti + et medfølgende
eksempel på et XML-catalog.



