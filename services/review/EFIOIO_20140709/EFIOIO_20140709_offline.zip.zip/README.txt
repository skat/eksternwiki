README/CHANGELOG
=======================================================================================================
Denne leverance er en korrektion til leverancen 20140225 og indeholder udelukkende en
rettelse til dokumentationen.

�ndring:
 OIO_Elementer.docx, afsnit 1.67 FordringAfskrivningAarsagKode: Uklarhed om koderne for d�dsboer og for�ldelse er rettet. 
