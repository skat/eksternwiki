README/CHANGELOG 1.4 (patch)
=======================================================================================================
DMIIndberetterOpretStruktur.xsd er nu tom, da indberetteroplysninger findes i kontekst. 