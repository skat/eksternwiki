README/CHANGELOG
=======================================================================================================
Denne leverance indeholder �ndringer til b�de beskrivelser og XML schemaer.

�ndringer i schemaer:
 - HovedFordringTilbagekaldAarsagKode: Koder er �ndret
 - EFIAlternativKontaktStruktur: Optionalitet PersonGenderCode (k�n) tilf�jet, fjernet optionalitet p� CountryIdentificationCode (landekode)
 - MFUnderretAfregnStruktur: Tilf�jet DMIUdbetalingReference
 - OpretAendrKvitteringStruktur: Udvidet med AlternativKontaktReferenceStruktur
 
