#!/usr/bin/env bash

# Ideer:
# - Lave HELP
#
#

SWAP_DIRECTION=$1

#if [ "$SWAP_DIRECTION" == "GO_LIVE" -o "$SWAP_DIRECTION" == "GO_OUT_OF_SERVICE" ] ; then
if [ "$SWAP_DIRECTION" == "GO_LIVE" ] ; then
  echo 'Bogføringsguiden sættes i drift!'
  mv index.html index_out_of_service.html
  mv index_live.html index.html
elif  [  "$SWAP_DIRECTION" == "GO_OUT_OF_SERVICE" ] ; then
  echo 'Bogføringsguiden sættes ud af drift.'
  mv index.html index_live.html
  mv index_out_of_service.html index.html
  echo 'Forsiden er nu skiftet!'
else
  echo '***** Du mangler at angive om BFG skal sættes ud af drift eller i drift!'
  echo '***** Angiv GO_OUT_OF_SERVICE såfremt BFG skal ud af drift'.
  echo '***** Angiv GO_LIVE såfremt BFG skal i drift.'
  echo 'Script afsluttes....'
  exit 0
fi

#if [[ ($1 != "GO_LIVE") || $1 != "GO_OUT_OF_SERVICE" ]] ; then
#    echo 'Du har ikke angivet GO_OUT_OF_SERVICE eller GO_LIVE!'
#    echo 'Script afsluttes....'
#fi
