# json format beskrivelse, spørgetræ

Dette dokument beskriver kort ændringer i formatet.
Beskrivelse af de enkelte felter hører ikke hjemme her, men i selve schema beskrivelserne.

### Kommende version (ikke publiceret)


## Historiske ændringer nedenfor

### Version http://bfg.skat.dk/spoergetrae/v3.0
Navngivningen af schema versionerne er ændret, således der åbnes op for både et schema for spørgetræer samt et schema for kataloger.

### Version http://bfg.skat.dk/v2.0
Version hvor konklusioner er flyttet ud af hvert spørgsmål og i stedet bor som en liste på lige fod med spørgsmålene.

### Version http://bfg.skat.dk/v1.0
Første, interne schema version
