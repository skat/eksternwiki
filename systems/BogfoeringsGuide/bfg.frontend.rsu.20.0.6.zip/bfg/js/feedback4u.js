// version 1.0
// Til feedback4u/bogføringsguiden - opmærkning (bemærk at id="guid" også skal defineres med valid guid):
//
// <div class="feedback4u">
// <div class="header">Fik du svar på dine spørgsmål?</div>
// <div class="btn-group" data-toggle="buttons">
// <label class="btn btn-primary" id="feedback4ulabelYes">
// <input type="radio" name="options" id="option1" onclick="return false;"> Ja</label>
// <label class="btn btn-primary" id="feedback4ulabelNo">
// <input type="radio" name="options" id="option2" onclick="return false;"> Nej</label></div>
// <div class="feedbackComment" style="display:none">
// <div class="commentHeader">Hvordan kan vi forbedre indholdet?</div>
// <div class="commentInput"><textarea id="feedback4uTxt" cols="40" rows="5"></textarea></div>
// <div class="btn-group" role="group" aria-label="Send">
// <button id="feedback4uButton" type="button" class="btn btn-default">SEND</button></div></div></div>
//
// feedback4uUrlprefix = '//www.skat.dk/'

// deactivated via dap with web.config: <add key="userfeedback4uJS" value="0"/>

/*
* TEST
// var feedback4uUrlprefix = '//www.skat.dk.sktpinf01iis03.skat.dk/test/WEbsrv/ratehandler.ashx?lang=da';
*/
/*
* PROD
* */
var feedback4uUrlprefix = '//www.skat.dk/WEBsrv/ratehandler.ashx?lang=da';

function feedback4uprocess(parms, comment) {

  var url = feedback4uUrlprefix + parms;

  console.log('Feedback url: ' + url);

  $.ajax({
    url: url
    , dataType: 'jsonp'
    , success: function (response) {
      // console.log('success!!! =D', response);
      if (response != undefined) { // ok repsonse:
        if (response.message != '') {
          // if (comment) {
            //$('.feedback4uOutput').html(response.message);
            //$('.feedback4u').hide();
          // } else {
            //$('.feedbackComment').show(); // Display the whole comment session (initially hidden)
          // }

        } else {
          console.log('success but bad', response);
          feedback4ubad();
        }
      } else {
        console.log('success but bad', response);
        feedback4ubad();
      }
    }
    , error: function (response) {

      console.log('error', response);

      if (response.status == 404) {
        feedback4ubad()
      } else {
        $('.feedback4uOutput').html('Der gik noget galt, så vi har desværre ikke modtaget beskeden. Vær sikker på at beskeden ikke indeholder specialtegn, status: ' + response.status + ', statusText: ' + response.statusText);
      }
    }
  });
}

function feedback4ubad() {
  $('.feedback4uOutput').html('Kommentaren må ikke indeholde specialtegn. Fjern venligst dem og prøv igen!');
}

function feedback4udisable() {

  $('#feedback4ulabelYes').prop('disabled', true).addClass('disabled');

  $('#feedback4ulabelYes input').prop('disabled', true).addClass('disabled');

  $('#feedback4ulabelNo').prop('disabled', true).addClass('disabled');

  $('#feedback4ulabelNo input').prop('disabled', true).addClass('disabled');
}

function feedback4showcomment() {
  $('.feedbackComment').show(); // Display the whole comment session (initially hidden)
}

function feedback4commentsent() {
  $('.feedback4uOutput').html("<div class='reply'>Tak for dit svar.</div>");
  $('.feedback4u').hide();
}


